package com.realestate.squareyards.service;

import com.realestate.squareyards.core.FirebaseMessagingService;
import com.realestate.squareyards.models.Entity.FirebaseNote;
import com.realestate.squareyards.models.request.ImpressionBasedListingRequest;
import com.realestate.squareyards.models.request.dealgenie.DGReadRequirement;
import com.realestate.squareyards.service.listing.ImpressionBasedListingService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;

@Slf4j
@SpringBootTest
@RunWith(SpringRunner.class)
public class DGRequirementServiceTest {

    @Autowired
    RequirementsService requirementsService;

    @Autowired
    FirebaseMessagingService firebaseMessagingService;

    @Autowired
    ImpressionBasedListingService impressionBasedListingService;

    @Test
    public void readTest() {
        try {
            DGReadRequirement DGReadRequirement = new DGReadRequirement();
            DGReadRequirement.setAgentId("1234");
            DGReadRequirement.setPageNumber(1);
            DGReadRequirement.setPageSize(10);
            log.info(requirementsService.readRequirement(DGReadRequirement).toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testNotification() {
        try {
            FirebaseNote note = new FirebaseNote("sub", "content", new HashMap(), "img");
            log.info(firebaseMessagingService.sendNotification(note, "2282285117414704507"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void UrlElasticRepositoryTest() {
        try {

            impressionBasedListingService.getProperties(new ImpressionBasedListingRequest(
                    "https://www.squareyards.com/resale/search?propertyTypeName=&cityId=6&bedrooms=1%20BHK&propertyType=4&buildingType=1&minPrice=500000&maxPrice=1000000&postedBy=1%2C3&furnishing=Furnished&minArea=100&maxArea=200",
                    null,
                    "rent"
            ));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
