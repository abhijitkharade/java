CREATE TABLE `product_grouping` (
  `group_id` varchar(100) NOT NULL,
  `variant_id` varchar(100) NOT NULL,
  `low_product_image` text,
  `outdated_data` text,
  `product_id` json DEFAULT NULL,
  `solr_tags` json DEFAULT NULL,
  `status` text,
  `taxonomy_id` int DEFAULT NULL,
  `tko_tags` json DEFAULT NULL,
  `created_ts` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified_ts` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`group_id`,`variant_id`)
) ;
