-- realestate_squareyards.listing_boosting definition

CREATE TABLE realestate_squareyards.listing_boosting (
    sqy_project_id text,
    agentpremium text,
    atreainsqft text,
    avgimpression text,
    avgleads text,
    avglistingscore text,
    beatsleadcount text,
    beatsprojectid text,
    buildingtype text,
    buildingtypeid text,
    category_id text,
    cityid text,
    cityname text,
    cplus text,
    createdby text,
    dotcomprojectid text,
    furnishingstatus text,
    group_id text,
    impressioncounter text,
    listingscore text,
    price text,
    propertytype text,
    propertytypeid text,
    solr_query text,
    sublocalityid text,
    sublocalityname text,
    unittype text,
    PRIMARY KEY (sqy_project_id)
) WITH read_repair = 'BLOCKING'
    AND gc_grace_seconds = 864000
    AND additional_write_policy = '99PERCENTILE'
    AND bloom_filter_fp_chance = 0.01
    AND caching = { 'keys' : 'ALL', 'rows_per_partition' : 'NONE' }
    AND comment = ''
    AND compaction = { 'class' : 'org.apache.cassandra.db.compaction.SizeTieredCompactionStrategy', 'max_threshold' : 32, 'min_threshold' : 4 }
    AND compression = { 'chunk_length_in_kb' : 64, 'class' : 'org.apache.cassandra.io.compress.LZ4Compressor' }
    AND default_time_to_live = 0
    AND speculative_retry = '99PERCENTILE'
    AND min_index_interval = 128
    AND max_index_interval = 2048
    AND crc_check_chance = 1.0
    AND cdc = false
    AND memtable_flush_period_in_ms = 0;

CREATE CUSTOM INDEX realestate_squareyards_listing_boosting_solr_query_index ON realestate_squareyards.listing_boosting (solr_query) USING 'com.datastax.bdp.search.solr.Cql3SolrSecondaryIndex' ;