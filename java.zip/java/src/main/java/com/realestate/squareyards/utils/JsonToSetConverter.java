package com.realestate.squareyards.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import java.io.IOException;
import java.util.LinkedHashSet;
import java.util.Set;

@Converter
@Slf4j
public class JsonToSetConverter implements AttributeConverter<Set<Object>, String> {

    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public String convertToDatabaseColumn(Set<Object> attribute) {

        if (attribute == null) {
            return null;
        }
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.writeValueAsString(attribute);
        } catch (IOException e) {
            log.info(this.getClass().getName(), "json to Set error ", e);
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public Set<Object> convertToEntityAttribute(String jsonString) {

        if (jsonString == null) {
            return new LinkedHashSet<>(0);
        }
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.readValue(jsonString, LinkedHashSet.class);
        } catch (IOException e) {
            log.info(this.getClass().getName(), "json to Set error ", e);
        }
        return new LinkedHashSet<>(0);

    }
}
