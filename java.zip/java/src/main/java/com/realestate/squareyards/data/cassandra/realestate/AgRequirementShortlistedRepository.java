package com.realestate.squareyards.data.cassandra.realestate;

import com.realestate.squareyards.models.table.cassandra.AgRequirementShortlisted;
import com.realestate.squareyards.models.table.cassandra.AgRequirementShortlistedKey;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface AgRequirementShortlistedRepository extends CassandraRepository<AgRequirementShortlisted, AgRequirementShortlistedKey> {

    @Query(value = "select * from realestate_squareyards.ag_requirement_shortlisted where agent_id = :agent_id AND requirement_id= :requirement_id AND status= :status limit 1000")
    List<AgRequirementShortlisted> findByRequirementId(@Param("agent_id") String agentId, @Param("requirement_id") String requirementId, @Param("status") String status);

    @Query(value = "select count(1) from realestate_squareyards.ag_requirement_shortlisted where agent_id = :agent_id AND requirement_id= :requirement_id")
    int countByRequirementId(@Param("agent_id") String agentId, @Param("requirement_id") String requirementId);
}
