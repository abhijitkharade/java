package com.realestate.squareyards.models.response.trending_properties;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Slf4j
@NoArgsConstructor
public class TrendingKeywordsResponse {

    @ApiModelProperty(example = "13")
    @JsonProperty("cityid")
    String cityid;

    @ApiModelProperty(example = "Borivali West, Mumbai")
    @JsonProperty("keyword")
    String keyword;

    @ApiModelProperty(example = "https://www.squareyards.com/search?cityId=13&subLocationId=941")
    @JsonProperty("searchUrl")
    String searchUrl;

    @ApiModelProperty(example = "New Projects")
    @JsonProperty("type")
    String type;

}
