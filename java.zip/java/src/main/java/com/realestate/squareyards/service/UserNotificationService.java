package com.realestate.squareyards.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

public interface UserNotificationService {

}

@Slf4j
@Service
class IUserNotificationService implements UserNotificationService {

}

