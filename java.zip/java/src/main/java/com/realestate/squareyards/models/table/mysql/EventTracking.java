package com.realestate.squareyards.models.table.mysql;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Data
@Entity
@Table(name = Constants.EVENT_TRACKING_TABLE)
@AllArgsConstructor
@NoArgsConstructor
public class EventTracking implements Serializable {

    @Id
    @Column(name = Constants.COLUMN_ID)
    private Integer id;

    @Column(name = Constants.COLUMN_VISIT_ID)
    private String visitId;

    @Column(name = Constants.COLUMN_PRODUCT_ID)
    private String productId;

    @Column(name = Constants.COLUMN_GROUP_ID)
    private String groupId;

    @Column(name = Constants.COLUMN_VARIANT_ID)
    private String variantId;

    @Column(name = Constants.COLUMN_EVENT_TYPE)
    private String eventType;

    @Column(name = Constants.COLUMN_CLICK_TYPE)
    private String clickTtype;

    @Column(name = Constants.COLUMN_CREATED_TS)
    private Date createdTs;

    @Column(name = Constants.COLUMN_EVENT_TS)
    private Date eventTs;

    @Column(name = Constants.COLUMN_CATEGORY_NAME)
    private String categoryName;
}
