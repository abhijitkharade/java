package com.realestate.squareyards.models.table.cassandra;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyClass;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;

@PrimaryKeyClass
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EventCounterTrendingPropertyKey {

    @PrimaryKeyColumn(name = Constants.COLUMN_EVENT_DATE, ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String eventDate;

    @PrimaryKeyColumn(name = Constants.COLUMN_CATEGORY_NAME, ordinal = 1, type = PrimaryKeyType.PARTITIONED)
    private String categoryName;

    @PrimaryKeyColumn(name = Constants.COLUMN_CITY, ordinal = 2, type = PrimaryKeyType.PARTITIONED)
    private String city;

    @PrimaryKeyColumn(name = Constants.COLUMN_GROUP_ID, ordinal = 3, type = PrimaryKeyType.PARTITIONED)
    private String groupId;
}
