package com.realestate.squareyards.data.mysql.realestate;

import com.realestate.squareyards.models.table.mysql.NotificationCounter;
import com.realestate.squareyards.models.table.mysql.NotificationCounterKey;
import org.springframework.data.repository.CrudRepository;

public interface NotificationCounterRepository extends CrudRepository<NotificationCounter, NotificationCounterKey> {
}
