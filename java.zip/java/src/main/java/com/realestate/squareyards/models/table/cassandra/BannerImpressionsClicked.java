package com.realestate.squareyards.models.table.cassandra;

import com.realestate.squareyards.models.request.notification.BannerInappOpenedRequest;
import com.realestate.squareyards.models.request.notification.BannerInappUpdateRequest;
import com.realestate.squareyards.utils.Constants;
import com.realestate.squareyards.utils.Helper;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import java.text.SimpleDateFormat;
import java.util.Date;

@Table(Constants.BANNER_IMPRESSIONS_CLICKED_TABLE)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BannerImpressionsClicked {

    @PrimaryKey
    BannerImpressionsClickedKey key;

    @Column("created_ts")
    private Date createdTs;

    @Column("event_ts")
    private Date eventTs;

    @Column("event_date")
    private String eventDate;

    @Column("goal_uuid")
    private String goalUuid;

    @Column("goal_id")
    private String goalId;

    @Column("event_type")
    private String eventType;

    public BannerImpressionsClicked(BannerInappUpdateRequest request, String type, SimpleDateFormat formatter) {
        BannerImpressionsClickedKey bannerKey = new BannerImpressionsClickedKey();
        bannerKey.setId(request.getId());
        bannerKey.setVisitorId(request.getVisitorId());
        bannerKey.setUuid(Helper.getUUId());

        this.key = bannerKey;
        this.createdTs = new Date();
        this.eventTs = new Date();
        this.eventDate = formatter.format(new Date());
        this.goalUuid = request.getGoalUUID();
        this.goalId = request.getGoalId();
        this.eventType = type;
    }

    public BannerImpressionsClicked(BannerInappOpenedRequest request, String type, SimpleDateFormat formatter) {
        BannerImpressionsClickedKey bannerKey = new BannerImpressionsClickedKey();
        bannerKey.setId(request.getId());
        bannerKey.setVisitorId(request.getVisitorId());
        bannerKey.setUuid(Helper.getUUId());

        this.key = bannerKey;
        this.createdTs = new Date();
        this.eventTs = new Date();
        this.eventDate = formatter.format(new Date());
        this.goalUuid = request.getGoalUUID();
        this.goalId = request.getGoalId();
        this.eventType = type;
    }
}
