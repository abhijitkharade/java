package com.realestate.squareyards.models.response.recent_activity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Slf4j
@NoArgsConstructor
public class ProductCountResponse {

    @ApiModelProperty(example = "45")
    @JsonProperty("recordCount")
    private String recordCount;

    @ApiModelProperty(example = "45")
    @JsonProperty("id")
    private String id;

}
