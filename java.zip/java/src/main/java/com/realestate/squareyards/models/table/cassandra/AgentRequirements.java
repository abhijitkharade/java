package com.realestate.squareyards.models.table.cassandra;

import com.datastax.driver.core.DataType;
import com.realestate.squareyards.models.request.dealgenie.DGInsert;
import com.realestate.squareyards.utils.Helper;
import com.realestate.squareyards.utils.Types;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Transient;
import org.springframework.data.cassandra.core.mapping.CassandraType;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Table("agent_requirements")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AgentRequirements {

    @PrimaryKey
    private AgentRequirementsKey agentRequirementsKey;

    @Column("created_ts")
    private Date createdTs;

    @Column("modified_ts")
    private Date modifiedTs;

    @Column("status")
    private String status;

    @CassandraType(type = DataType.Name.MAP, typeArguments = {DataType.Name.TEXT, DataType.Name.TEXT})
    @Column("filters")
    private Map<String, String> filters;

    @Column("category_id")
    private Integer categoryId;

    @Column("requirement_name")
    private String requirementName;

    @Transient
    private Long newPropertyCount;

    @Transient
    private int shortListedCount;

    public AgentRequirements(DGInsert DGInsert) {

        agentRequirementsKey = new AgentRequirementsKey();
        agentRequirementsKey.setRequirementId(Helper.generateReqId(String.valueOf(DGInsert.getCategoryId())));
        agentRequirementsKey.setAgentId(DGInsert.getAgentId());
        filters = new HashMap<>();
        DGInsert.getFilters().forEach((k, v) -> filters.put(k, v.toString()));
        requirementName = DGInsert.getRequirementName();
        categoryId = DGInsert.getCategoryId();
        createdTs = new Date();
        modifiedTs = new Date();
        status = Types.Statuses.ACTIVE.name();
    }
}
