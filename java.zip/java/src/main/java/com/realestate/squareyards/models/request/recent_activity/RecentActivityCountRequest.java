package com.realestate.squareyards.models.request.recent_activity;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class RecentActivityCountRequest {

    @ApiModelProperty(example = "1", required = true)
    @JsonProperty("categoryId")
    private String categoryId;

    @ApiModelProperty(example = "2233445577", required = true)
    @JsonProperty("phoneNumber")
    private String phoneNumber;

    @ApiModelProperty(example = "2233445577", required = true)
    @JsonProperty("visitorId")
    private String visitorId;
}
