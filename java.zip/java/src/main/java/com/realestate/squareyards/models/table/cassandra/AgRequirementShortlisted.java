package com.realestate.squareyards.models.table.cassandra;

import com.realestate.squareyards.models.request.dealgenie.DGSaveProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import java.util.Date;

@Table("ag_requirement_shortlisted")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AgRequirementShortlisted {

    @PrimaryKey
    private AgRequirementShortlistedKey agRequirementShortlistedKey;

    @Column("created_ts")
    private Date createdTs;

    @Column("modified_ts")
    private Date modifiedTs;

    @Column("status")
    private String status;

    public AgRequirementShortlisted(DGSaveProperty save) {

        agRequirementShortlistedKey = new AgRequirementShortlistedKey();
        agRequirementShortlistedKey.setAgentId(save.getAgentId());
        agRequirementShortlistedKey.setRequirementId(save.getRequirementId());
        agRequirementShortlistedKey.setShortlistedId(save.getPropertyId());
        createdTs = new Date();
        modifiedTs = new Date();
        status = save.getStatus().name();

    }
}
