package com.realestate.squareyards.models.table.mysql;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Data
@Embeddable
@AllArgsConstructor
@NoArgsConstructor
public class SyFiltersDetailskey implements Serializable {

    @Column(name = Constants.COLUMN_CATEGORY_ID)
    private int categoryId;

    @Column(name = Constants.COLUMN_FILTER_ID)
    private String filterId;

    @Column(name = Constants.COLUMN_FILTER_NAME)
    private String filterName;

    @Column(name = Constants.COLUMN_CITY_ID)
    private String cityId;
}
