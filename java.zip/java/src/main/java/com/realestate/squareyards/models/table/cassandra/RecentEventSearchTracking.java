package com.realestate.squareyards.models.table.cassandra;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import java.util.Date;

@Table(Constants.RECENT_EVENT_SEARCH_TRACKING_TABLE)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RecentEventSearchTracking {

    @PrimaryKey
    private RecentEventSearchTrackingKey recentEventSearchTrackingKey;

    @Column(Constants.COLUMN_EVENT_TS)
    private Date eventTs;

    @Column(Constants.COLUMN_SEARCH_ID)
    private String searchId;
}
