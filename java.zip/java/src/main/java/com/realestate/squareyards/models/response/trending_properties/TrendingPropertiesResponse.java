package com.realestate.squareyards.models.response.trending_properties;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.realestate.squareyards.utils.Types;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Slf4j
@NoArgsConstructor
public class TrendingPropertiesResponse {

    @ApiModelProperty(example = "['12','213','3']")
    @JsonProperty("projectIds")
    List<String> projectIds;

    @ApiModelProperty(example = "['12','213','3']")
    @JsonProperty("propertyIds")
    List<String> propertyIds;

    @ApiModelProperty(example = "['12','213','3']")
    @JsonProperty("userIds")
    List<String> userIds;

    public TrendingPropertiesResponse(List<String> idsList, String categoryName) {
        if (categoryName.equalsIgnoreCase(Types.CATEGORIES.NEW_PROJECTS.getCategoryType())) {
            this.projectIds = idsList;
        } else if (categoryName.equalsIgnoreCase(Types.CATEGORIES.RENTAL.getCategoryType()) || categoryName.equalsIgnoreCase(Types.CATEGORIES.RESALE.getCategoryType())) {
            this.propertyIds = idsList;
        } else if (categoryName.equalsIgnoreCase(Types.CATEGORIES.AGENTS.getCategoryType())) {
            this.userIds = idsList;
        }
    }
}
