package com.realestate.squareyards.core.elastic;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.search.SearchResponse;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;

public interface ElasticExtractor {

    JSONArray extractJsonDoc(SearchResponse searchResponse);

    <T> List<T> extract(SearchResponse searchResponse, Class<T> type);
}

@Component
@Slf4j
class IElasticExtractor implements ElasticExtractor {

    @Autowired
    private ObjectMapper mapper;

    @Override
    public JSONArray extractJsonDoc(SearchResponse searchResponse) {
        JSONArray resultDocs = new JSONArray();
        try {
            if (searchResponse != null && searchResponse.getHits() != null) {
                searchResponse.getHits().forEach(hits -> {
                    resultDocs.put(new JSONObject(hits.getSourceAsMap()));
                });
            }
        } catch (Exception e) {
            log.error("Unable to deserialize", e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to deserialize", e);
        }
        return resultDocs;
    }

    @Override
    public <T> List<T> extract(SearchResponse searchResponse, Class<T> type) {
        List<T> value = new ArrayList<>();
        try {
            if (searchResponse != null && searchResponse.getHits() != null) {
                searchResponse.getHits().forEach(hits -> {
                    try {
                        value.add(mapper.readValue(hits.getSourceAsString(), type));
                    } catch (JsonProcessingException e) {
                        throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to deserialize", e);
                    }
                });
            }
        } catch (Exception e) {
            log.error("Unable to deserialize", e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to deserialize", e);
        }
        return value;
    }
}
