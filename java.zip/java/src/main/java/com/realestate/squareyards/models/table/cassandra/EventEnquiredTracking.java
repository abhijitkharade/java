package com.realestate.squareyards.models.table.cassandra;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import java.util.Date;

@Table(Constants.EVENT_ENQUIRED_TRACKING_TABLE)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EventEnquiredTracking {

    @PrimaryKey
    private EventEnquiredTrackingKey eventEnquiredTrackingKey;

    @Column(Constants.COLUMN_AGENT_ID)
    private String agentId;

    @Column(Constants.COLUMN_AGENT_NAME)
    private String agentName;

    @Column(Constants.COLUMN_CITY)
    private String city;

    @Column(Constants.COLUMN_CLICK_TYPE)
    private String clickType;

    @Column(Constants.COLUMN_GROUP_ID)
    private String groupId;

    @Column(Constants.COLUMN_PRODUCT_ID)
    private String productId;

    @Column(Constants.COLUMN_SEARCH_ID)
    private String searchId;

    @Column(Constants.COLUMN_STATUS)
    private String status;

    @Column(Constants.COLUMN_VARIANT_ID)
    private String variantId;

    @Column(Constants.COLUMN_VISIT_ID)
    private String visitId;

    @Column(Constants.COLUMN_CREATED_TS)
    private Date createdTs;

    @Column(Constants.COLUMN_EVENT_TS)
    private Date eventTs;
}
