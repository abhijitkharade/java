package com.realestate.squareyards.core;

public class BaseService {

}
