package com.realestate.squareyards.models.response.recent_activity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.realestate.squareyards.models.table.cassandra.EventClickTracking;
import com.realestate.squareyards.models.table.cassandra.EventEnquiredTracking;
import com.realestate.squareyards.models.table.cassandra.EventShortlistedTracking;
import com.realestate.squareyards.utils.Types;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.text.SimpleDateFormat;
import java.util.TimeZone;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Slf4j
@NoArgsConstructor
public class ActivityResponse {

    @ApiModelProperty(example = "Rental")
    @JsonProperty("categoryName")
    String categoryName;

    @ApiModelProperty(example = "45")
    @JsonProperty("unitId")
    String unitId;

    @ApiModelProperty(example = "45")
    @JsonProperty("projectId")
    String projectId;

    @ApiModelProperty(example = "45")
    @JsonProperty("eventTs")
    String eventTs;

    @ApiModelProperty(example = "45")
    @JsonProperty("propertyId")
    String propertyId;

    @ApiModelProperty(example = "45")
    @JsonProperty("userId")
    String userId;

    public ActivityResponse(EventClickTracking records, String datePattern) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(datePattern);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("IST"));
        this.categoryName = records.getEventClickTrackingKey().getCategoryName();
        if (Types.CATEGORIES.NEW_PROJECTS.getCategoryType().equals(records.getEventClickTrackingKey().getCategoryName())) {
            this.unitId = records.getProductId();
            this.projectId = records.getGroupId();
        } else if (Types.CATEGORIES.RESALE.getCategoryType().equals(records.getEventClickTrackingKey().getCategoryName()) || Types.CATEGORIES.RENTAL.getCategoryType().equals(records.getEventClickTrackingKey().getCategoryName())) {
            this.propertyId = records.getGroupId();
        } else if (Types.CATEGORIES.AGENTS.getCategoryType().equals(records.getEventClickTrackingKey().getCategoryName())) {
            this.userId = records.getGroupId();
        }
        this.eventTs = simpleDateFormat.format(records.getEventTs());
    }

    public ActivityResponse(EventEnquiredTracking records, String datePattern) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(datePattern);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("IST"));
        this.categoryName = records.getEventEnquiredTrackingKey().getCategoryName();
        if (Types.CATEGORIES.NEW_PROJECTS.getCategoryType().equals(records.getEventEnquiredTrackingKey().getCategoryName())) {
            this.unitId = records.getProductId();
            this.projectId = records.getGroupId();
        } else if (Types.CATEGORIES.RESALE.getCategoryType().equals(records.getEventEnquiredTrackingKey().getCategoryName()) || Types.CATEGORIES.RENTAL.getCategoryType().equals(records.getEventEnquiredTrackingKey().getCategoryName())) {
            this.propertyId = records.getGroupId();
        } else if (Types.CATEGORIES.AGENTS.getCategoryType().equals(records.getEventEnquiredTrackingKey().getCategoryName())) {
            this.userId = records.getGroupId();
        }
        this.eventTs = simpleDateFormat.format(records.getEventTs());
    }

    public ActivityResponse(EventShortlistedTracking records, String datePattern) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(datePattern);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("IST"));
        this.categoryName = records.getEventShortlistedTrackingKey().getCategoryName();
        if (Types.CATEGORIES.NEW_PROJECTS.getCategoryType().equals(records.getEventShortlistedTrackingKey().getCategoryName())) {
            this.unitId = records.getProductId();
            this.projectId = records.getGroupId();
        } else if (Types.CATEGORIES.RESALE.getCategoryType().equals(records.getEventShortlistedTrackingKey().getCategoryName()) || Types.CATEGORIES.RENTAL.getCategoryType().equals(records.getEventShortlistedTrackingKey().getCategoryName())) {
            this.propertyId = records.getGroupId();
        } else if (Types.CATEGORIES.AGENTS.getCategoryType().equals(records.getEventShortlistedTrackingKey().getCategoryName())) {
            this.userId = records.getGroupId();
        }
        this.eventTs = simpleDateFormat.format(records.getEventTs());

    }
}
