package com.realestate.squareyards.models.table.cassandra;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyClass;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;

@PrimaryKeyClass
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WidgetMasterKey {
    @PrimaryKeyColumn(name= Constants.COLUMN_WIDGET,ordinal=0,type= PrimaryKeyType.PARTITIONED)
    private String widget;

    @PrimaryKeyColumn(name=Constants.COLUMN_TAB,ordinal=1,type=PrimaryKeyType.PARTITIONED)
    private String tab;

    @PrimaryKeyColumn(name=Constants.COLUMN_CATEGORY_NAME,ordinal=2,type=PrimaryKeyType.PARTITIONED)
    private String categoryName;

    @PrimaryKeyColumn(name=Constants.COLUMN_AGGREGATION_FROM,ordinal=3,type=PrimaryKeyType.PARTITIONED)
    private String aggregationFrom;

    @PrimaryKeyColumn(name=Constants.COLUMN_CITY,ordinal=4,type=PrimaryKeyType.PARTITIONED)
    private String city ;

    @PrimaryKeyColumn(name=Constants.COLUMN_PRIORITY,ordinal=5,type=PrimaryKeyType.PARTITIONED)
    private Integer priority ;
}
