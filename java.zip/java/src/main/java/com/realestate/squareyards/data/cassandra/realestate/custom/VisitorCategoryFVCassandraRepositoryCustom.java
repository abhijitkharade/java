package com.realestate.squareyards.data.cassandra.realestate.custom;

import com.datastax.driver.core.querybuilder.Clause;
import com.datastax.driver.core.querybuilder.QueryBuilder;
import com.datastax.driver.core.querybuilder.Select;
import com.realestate.squareyards.models.table.cassandra.VisitorCategoryFVCassandra;
import com.realestate.squareyards.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.cassandra.core.CassandraTemplate;

import java.util.List;
import java.util.Set;

public interface VisitorCategoryFVCassandraRepositoryCustom {

    VisitorCategoryFVCassandra getByVisitorId(String taxonomyId, String visitorId);

    List<VisitorCategoryFVCassandra> getByAllVisitorIds(String taxonomyId, Set<String> visitorId, int limit);

}

@Slf4j
class VisitorCategoryFVCassandraRepositoryCustomImpl implements VisitorCategoryFVCassandraRepositoryCustom {

    @Autowired
    @Qualifier("keyspaceSquareyardsCassandraTemplate")
    CassandraTemplate cassandraOperations;

    @Override
    public VisitorCategoryFVCassandra getByVisitorId(String taxonomyId, String visitorId) {

        Select select = QueryBuilder.select().from(Constants.VISITOR_CATEGORY_FV_TAXONOMY_ID_TABLE + taxonomyId);

        Clause visitorIdClause = QueryBuilder.eq(Constants.COLUMN_VISITOR_ID, visitorId);

        select.where(visitorIdClause);

        VisitorCategoryFVCassandra visitor = cassandraOperations.selectOne(select, VisitorCategoryFVCassandra.class);

        return visitor;
    }

    @Override
    public List<VisitorCategoryFVCassandra> getByAllVisitorIds(String taxonomyId, Set<String> visitorId, int limit) {

        Select select = QueryBuilder.select().from(Constants.VISITOR_CATEGORY_FV_TAXONOMY_ID_TABLE + taxonomyId);

        Clause visitorIdInClause = QueryBuilder.in(Constants.COLUMN_VISITOR_ID, visitorId);

        select.where(visitorIdInClause).limit(limit);

        List<VisitorCategoryFVCassandra> visitorList = cassandraOperations.select(select, VisitorCategoryFVCassandra.class);

        return visitorList;

    }
}
