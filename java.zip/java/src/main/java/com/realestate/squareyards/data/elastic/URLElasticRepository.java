package com.realestate.squareyards.data.elastic;

import com.realestate.squareyards.core.elastic.ElasticExtractor;
import com.realestate.squareyards.core.elastic.ElasticRepository;
import com.realestate.squareyards.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.common.Strings;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.TermQueryBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

public interface URLElasticRepository {

    Map<String, String> getFiltersFromUrl(String Url);
}

@Service
@Slf4j
class IURLElasticRepository extends ElasticRepository implements URLElasticRepository {

    @Autowired
    private ElasticExtractor extractor;

    @Override
    public Map<String, String> getFiltersFromUrl(String Url) {
        Map<String, String> filters = new HashMap<>();
        try {
            SearchSourceBuilder queryBuilder = new SearchSourceBuilder();
            queryBuilder.from(0);
            queryBuilder.size(1);
            TermQueryBuilder query = QueryBuilders.termQuery("url.keyword", Url);
            queryBuilder.query(query);

            SearchResponse response = search(Constants.URL_SR_INDEX, queryBuilder);
            JSONArray docs = extractor.extractJsonDoc(response);
            if (docs != null && !docs.isEmpty()) {
                JSONObject filterObject = docs.getJSONObject(0).optJSONObject("filter");
                if (filterObject != null) {
                    filterObject.keySet().forEach(key -> {
                        if (!Strings.isNullOrEmpty(filterObject.optString(key)))
                            filters.put(key, filterObject.optString(key));
                    });
                }
            }
        } catch (Exception e) {
            log.error("error", e);
        }
        return filters;
    }
}
