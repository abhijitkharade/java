package com.realestate.squareyards.service;

import com.realestate.squareyards.data.mysql.realestate.NotificationCounterRepository;
import com.realestate.squareyards.models.table.mysql.NotificationCounter;
import com.realestate.squareyards.models.table.mysql.NotificationCounterKey;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Optional;

public interface NotificationCounterService {

    void update(NotificationCounterKey key, Long opened, Long sent);
}

@Slf4j
@Service
class INotificationCounterService implements NotificationCounterService {

    @Autowired
    private NotificationCounterRepository notificationCounterRepository;

    @Override
    public void update(NotificationCounterKey key, Long opened, Long sent) {

        Optional<NotificationCounter> voOpt = notificationCounterRepository.findById(key);

        if (voOpt.isPresent()) {
            NotificationCounter notificationCounter = voOpt.get();
            notificationCounter.setModifiedTs(new Date());
            if (opened > 0) {
                opened = Math.addExact(opened, notificationCounter.getNotificationsOpened());
                notificationCounter.setNotificationsOpened(opened);
            }
            if (sent > 0) {
                sent = Math.addExact(sent, notificationCounter.getNotificationsSent());
                notificationCounter.setNotificationsSent(sent);
            }
            notificationCounterRepository.save(notificationCounter);

        }
    }
}