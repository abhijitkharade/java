package com.realestate.squareyards.controllers;

import com.realestate.squareyards.models.request.similarity.RTUSInsert;
import com.realestate.squareyards.models.request.similarity.RTUSRead;
import com.realestate.squareyards.models.response.ResponseBuilder;
import com.realestate.squareyards.models.response.realtime_user_similarity.RTUSInsertResponse;
import com.realestate.squareyards.models.response.realtime_user_similarity.RTUSReadResponse;
import com.realestate.squareyards.service.RealTimeUserSimilarityService;
import com.realestate.squareyards.utils.Constants;
import com.realestate.squareyards.utils.Routes;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@Api(tags = "User Similarity")
@RequestMapping(Routes.WEB_B2C + Routes.OPEN + Routes.RECOMMENDATION)
public class RealTimeUserSimilarityController {

    @Autowired
    RealTimeUserSimilarityService realTimeUserSimilarityService;

    @PostMapping(value = Routes.VERSION + Routes.UPDATE_USER_FV,
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    ResponseBuilder<RTUSInsertResponse> updateFV(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable String version,
                                                 @Valid @RequestBody RTUSInsert request) {

        ResponseBuilder builder = new ResponseBuilder();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setObject(realTimeUserSimilarityService.updateRedisFv(request));
        return builder;
    }

    @PostMapping(value = Routes.VERSION + Routes.READ_USER_FV,
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    ResponseBuilder<RTUSReadResponse> readProperties(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable String version,
                                                     @Valid @RequestBody RTUSRead request) {

        ResponseBuilder builder = new ResponseBuilder();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setObject(realTimeUserSimilarityService.readVisitors(request));
        return builder;
    }

}
