package com.realestate.squareyards.models.table.mysql;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Comparator;
import java.util.Date;

@Data
@Entity
@AllArgsConstructor
@Table(name = Constants.SY_FILTER_DETAILS_TABLE)
public class SyFiltersDetails implements Serializable, Comparable<SyFiltersDetails> {

    @EmbeddedId
    @JsonIgnore
    private SyFiltersDetailskey key;

    @Column(name = Constants.COLUMN_FILTER_KEY)
    @JsonProperty("FilterKey")
    private String filterKey;

    @Column(name = Constants.COLUMN_FILTER_PARENT_ID)
    @JsonProperty("FilterParentId")
    private String filterParentId;

    @Column(name = Constants.COLUMN_FILTER_PARENT_NAME)
    @JsonProperty("FilterParentName")
    private String filterParentName;

    @Column(name = Constants.COLUMN_FILTER_COUNT)
    @JsonProperty("FilterCount")
    private int filterCount;

    @Column(name = Constants.COLUMN_URL_KEY)
    @JsonIgnore
    private String urlKey;

    @Column(name = Constants.COLUMN_CREATED_TS)
    @JsonIgnore
    private Date createdTs;

    @Column(name = Constants.COLUMN_MODIFIED_TS)
    @JsonIgnore
    private Date modifiedTs;

    @Column(name = Constants.COLUMN_STATUS)
    @JsonIgnore
    private String status;

    @Column(name = Constants.COLUMN_TATTR_FILTER)
    @JsonIgnore
    private String tattrFilter;

    @Column(name = Constants.COLUMN_LABEL_DISPLAY_NAME)
    @JsonIgnore
    private String labelDisplayName;

    @JsonProperty("FilterId")
    transient String filterId;
    @JsonProperty("FilterName")
    transient String filterName;
    @JsonProperty("CityId")
    transient String cityId;

    public String getFilterName() {

        return key.getFilterName();
    }

    public String getFilterId() {

        return key.getFilterId();
    }

    public String getCityId() {

        return key.getCityId();
    }

    public SyFiltersDetails() {

        key = new SyFiltersDetailskey();
    }

    public void setFilterId(String filterId) {

        key.setFilterId(filterId);
    }

    public void setFilterName(String filterName) {

        key.setFilterName(filterName);
    }

    public void setCategoryId(int categoryId) {

        key.setCategoryId(categoryId);
    }

    public void setCityId(String cityId) {

        key.setCityId(cityId);
    }

    public static class OrderByCount implements Comparator<SyFiltersDetails> {

        @Override
        public int compare(SyFiltersDetails o1, SyFiltersDetails o2) {

            return Integer.compare(o2.getFilterCount(), o1.getFilterCount());
        }
    }

    public static class OrderByName implements Comparator<SyFiltersDetails> {

        @Override
        public int compare(SyFiltersDetails o1, SyFiltersDetails o2) {

            return o1.getFilterName().compareTo(o2.getFilterName());
        }
    }

    @Override
    public int compareTo(SyFiltersDetails o) {
        return 0;
    }
}
