package com.realestate.squareyards.models.response.notification;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
public class BannerResponse {

    @JsonProperty("static")
    @ApiModelProperty
    private List<BannerInappResponse> response;

}
