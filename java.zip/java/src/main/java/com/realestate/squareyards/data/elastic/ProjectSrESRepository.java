package com.realestate.squareyards.data.elastic;

import com.realestate.squareyards.core.elastic.ElasticExtractor;
import com.realestate.squareyards.core.elastic.ElasticRepository;
import com.realestate.squareyards.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.IdsQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.functionscore.FunctionScoreQueryBuilder;
import org.elasticsearch.index.query.functionscore.ScoreFunctionBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

public interface ProjectSrESRepository {

    JSONArray findByIds(List<String> ids);
}

@Slf4j
@Repository
class IProjectSrESRepository extends ElasticRepository implements ProjectSrESRepository {

    @Autowired
    private ElasticExtractor extractor;

    @Value("${elastic.project_sr.include.fields:*}")
    private String sourceFields;

    @Value("${elastic.project_sr.exclude.fields:NA}")
    private String excludeFields;

    @Value("${boosted.result.counts:5}")
    private int rows;

    @Override
    public JSONArray findByIds(List<String> ids) {

        SearchSourceBuilder queryBuilder = new SearchSourceBuilder();
        queryBuilder.from(0);
        queryBuilder.size(rows);

        IdsQueryBuilder idsQuery = QueryBuilders.idsQuery().addIds(ids.toArray(new String[0]));
        FunctionScoreQueryBuilder builder = getBoostFunctionQuery(ids, idsQuery);
        queryBuilder.query(builder);
        String[] source = sourceFields.equals("*") ? null : sourceFields.split(",");
        String[] exclude = excludeFields.equals("NA") ? null : excludeFields.split(",");

        queryBuilder.fetchSource(source, exclude);
        SearchResponse response = search(Constants.PROJECT_SR_INDEX, queryBuilder);
        return extractor.extractJsonDoc(response);
    }

    private FunctionScoreQueryBuilder getBoostFunctionQuery(List<String> ids, IdsQueryBuilder idsQuery) {
        List<FunctionScoreQueryBuilder.FilterFunctionBuilder> filterFunctionBuilders = new ArrayList<>();
        ids.forEach(e -> filterFunctionBuilders.add(
                new FunctionScoreQueryBuilder.FilterFunctionBuilder(QueryBuilders.matchQuery("propertyId", e),
                        ScoreFunctionBuilders.weightFactorFunction(ids.size() - ids.indexOf(e))))

        );
        FunctionScoreQueryBuilder.FilterFunctionBuilder[] builders =
                new FunctionScoreQueryBuilder.FilterFunctionBuilder[filterFunctionBuilders.size()];
        filterFunctionBuilders.toArray(builders);

        FunctionScoreQueryBuilder builder = new FunctionScoreQueryBuilder(idsQuery, builders);
        builder.boost(100);
        return builder;
    }
}
