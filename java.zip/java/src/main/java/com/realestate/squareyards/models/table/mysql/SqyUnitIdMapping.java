package com.realestate.squareyards.models.table.mysql;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Data
@Entity
@Table(name = Constants.SQY_UNIT_ID_MAPPING_TABLE)
@AllArgsConstructor
@NoArgsConstructor
public class SqyUnitIdMapping implements Serializable {

    @EmbeddedId
    private SqyUnitIdMappingKey sqyUnitIdMappingKey;

    @Column(name = Constants.COLUMN_GROUP_ID)
    private String groupId;

    @Column(name = Constants.COLUMN_UNIT_ID)
    private String sqyUnitId;

    @Column(name = Constants.COLUMN_PROJECT_ID)
    private String sqyProjectId;

    @Column(name = Constants.COLUMN_CREATED_TS)
    private Date createdTs;
}
