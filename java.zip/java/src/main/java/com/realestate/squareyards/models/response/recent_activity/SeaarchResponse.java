package com.realestate.squareyards.models.response.recent_activity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.realestate.squareyards.models.table.cassandra.EventSearchTracking;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.text.SimpleDateFormat;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TimeZone;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Slf4j
@NoArgsConstructor
public class SeaarchResponse {

    @ApiModelProperty(example = "powai")
    @JsonProperty("keyword")
    private String keyword;

    @ApiModelProperty(example = "powai")
    @JsonProperty("searchUrl")
    private String searchUrl;

    @ApiModelProperty(example = "powai")
    @JsonProperty("eventTs")
    private String eventTs;

    @ApiModelProperty(example = "powai")
    @JsonProperty("city")
    private String city;

    @ApiModelProperty(example = "powai")
    @JsonProperty("categoryName")
    private String categoryName;

    public SeaarchResponse(EventSearchTracking records, String datePattern) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(datePattern);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("IST"));
        Map<String, String> searchRecords = new LinkedHashMap<>();
        this.keyword = records.getSuggestedKeyword();
        this.searchUrl = records.getSearchUrl();
        this.eventTs = simpleDateFormat.format(records.getEventTs());
        this.city = records.getEventSearchTrackingKey().getCity();
        this.categoryName = records.getEventSearchTrackingKey().getCategoryName();
    }
}
