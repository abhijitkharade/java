package com.realestate.squareyards.data.mysql.realestate;

import com.realestate.squareyards.models.table.mysql.SqyUnitIdMapping;
import com.realestate.squareyards.models.table.mysql.SqyUnitIdMappingKey;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import javax.annotation.Nullable;

public interface SqyUnitIdMappingRepository extends CrudRepository<SqyUnitIdMapping, SqyUnitIdMappingKey> {

    @Nullable
    @Query(value = "select distinct group_id from realestate_squareyards.sqy_unit_id_mapping where sqy_project_id = ?1 and taxonomy_id = ?2 limit 1", nativeQuery = true)
    String findBySqyProjectId(String sqyProjectId, Integer taxonomyId);

}
