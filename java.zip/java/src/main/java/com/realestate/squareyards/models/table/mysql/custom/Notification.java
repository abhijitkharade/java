package com.realestate.squareyards.models.table.mysql.custom;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigInteger;
import java.util.Date;

@Data
@Entity
@Table(name = Constants.MATOMO_LOG_CONVERSION_JOIN)
@AllArgsConstructor
@NoArgsConstructor
public class Notification {

    @Id
    @Column(name = Constants.COLUMN_GOAL_ID)
    private Integer idgoal;

    @Column(name = Constants.COLUMN_GOAL_UUID)
    private BigInteger goalUUID;

    @Column(name = Constants.COLUMN_REDIRECT_URL)
    private String redirectUrl;

    @Column(name = Constants.COLUMN_NOTIFICATION_TITLE)
    private String notificationTitle;

    @Column(name = Constants.COLUMN_VISIT_ID)
    private BigInteger idvisit;

    @Column(name = Constants.COLUMN_NOTIFICATION_TEXT)
    private String notificationText;

    @Column(name = Constants.COLUMN_IMAGEPATH)
    private String imagePath;

    @Column(name = Constants.COLUMN_VISITOR_ID)
    private String visitorId;

    @Column(name = "goal_site_id")
    private String idsite;

    @Column(name = Constants.COLUMN_PLACEMENT_TYPE)
    private String placementType;

    @Column(name = Constants.COLUMN_PLACEHOLDER)
    private String placeholder;

    @Column(name = "priority")
    private String priority;

    @Column(name = "uniqueid")
    private String uniqueid;

    @Column(name = "created_ts")
    private Date createdTs;

    @Column(name = "rnk")
    private String rnk;

    @Column(name = "notification_type")
    private String notificationType;

}
