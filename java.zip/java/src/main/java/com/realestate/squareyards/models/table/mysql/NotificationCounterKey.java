package com.realestate.squareyards.models.table.mysql;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
@Data
@AllArgsConstructor
@NoArgsConstructor
public class NotificationCounterKey implements Serializable {

    @Column(name = Constants.COLUMN_GOAL_ID)
    private String goalId;

    @Column(name = Constants.COLUMN_GOAL_UUID)
    private String goalUUID;
}
