package com.realestate.squareyards.controllers;

import com.realestate.squareyards.models.request.ImpressionBasedListingRequest;
import com.realestate.squareyards.models.response.ImpressionBasedResponse;
import com.realestate.squareyards.models.response.ResponseBuilderV1;
import com.realestate.squareyards.service.listing.ImpressionBasedListingService;
import com.realestate.squareyards.utils.Constants;
import com.realestate.squareyards.utils.Routes;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@Api(tags = "Listing Page Controller")
@RequestMapping(Routes.LISTING + Routes.OPEN)
public class ListingController {

    @Autowired
    private ImpressionBasedListingService impressionBasedListingService;

    @PostMapping(value = Routes.IMPRESSION_BASED + Routes.READ,
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    ResponseBuilderV1<ImpressionBasedResponse> getPropertyByImpression(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable(name = "version") String version,
                                                                       @Valid @RequestBody ImpressionBasedListingRequest request) {

        ResponseBuilderV1 builder = new ResponseBuilderV1();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setResult(impressionBasedListingService.getProperties(request));
        return builder;
    }
}
