package com.realestate.squareyards.models.table.mysql;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Data
@Entity
@Table(name = Constants.USER_DATA_TABLE)
@AllArgsConstructor
@NoArgsConstructor
public class UserData implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "app_type")
    @JsonProperty("applicationType")
    private String appType;

    @Column(name = "site_id")
    @JsonProperty("idSite")
    private String idSite;

    @Id
    @Column(name = "visit_id")
    @JsonProperty("idVisit")
    private String idVisit;

    @Column(name = "visit_ip")
    @JsonProperty("visitIp")
    private String visitIp;

    @Column(name = "visitor_id")
    @JsonProperty("visitorId")
    private String visitorId;

    @Column(name = "goal_conversions")
    @JsonProperty("goalConversions")
    private Integer goalConversions;

    @Column(name = "last_action_ts")
    @JsonProperty("lastActionTimestamp")
    private Long lastActionTimestamp;

    @Column(name = "site_name")
    @JsonProperty("siteName")
    private String siteName;

    @Column(name = "server_ts")
    @JsonProperty("serverTimestamp")
    private Long serverTimestamp;

    @Column(name = "first_action_ts")
    @JsonProperty("firstActionTimestamp")
    private Long firstActionTimestamp;

    @Column(name = "user_id")
    @JsonProperty("userId")
    private String userId;

    @Column(name = "visitor_type")
    @JsonProperty("visitorType")
    private String visitorType;

    @Column(name = "visit_converted")
    @JsonProperty("visitConverted")
    private String visitConverted;

    @Column(name = "visit_count")
    @JsonProperty("visitCount")
    private String visitCount;

    @Column(name = "days_since_first_visit")
    @JsonProperty("daysSinceFirstVisit")
    private String daysSinceFirstVisit;

    @Column(name = "visit_duration")
    @JsonProperty("visitDuration")
    private String visitDuration;

    @Column(name = "searches")
    @JsonProperty("searches")
    private String searches;

    @Column(name = "actions")
    @JsonProperty("actions")
    private String actions;

    @Column(name = "interactions")
    @JsonProperty("interactions")
    private String interactions;

    @Column(name = "referrer_type")
    @JsonProperty("referrerType")
    private String referrerType;

    @Column(name = "referrer_type_name")
    @JsonProperty("referrerTypeName")
    private String referrerTypeName;

    @Column(name = "referrer_name")
    @JsonProperty("referrerName")
    private String referrerName;

    @Column(name = "referrer_keyword")
    @JsonProperty("referrerKeyword")
    private String referrerKeyword;

    @Column(name = "referrer_keyword_position")
    @JsonProperty("referrerKeywordPosition")
    private String referrerKeywordPosition;

    @Column(name = "referrer_url")
    @JsonProperty("referrerUrl")
    private String referrerUrl;

    @Column(name = "referrer_search_engine_url")
    @JsonProperty("referrerSearchEngineUrl")
    private String referrerSearchEngineUrl;

    @Column(name = "language_code")
    @JsonProperty("languageCode")
    private String languageCode;

    @Column(name = "language")
    @JsonProperty("language")
    private String language;

    @Column(name = "device_type")
    @JsonProperty("deviceType")
    private String deviceType;

    @Column(name = "device_brand")
    @JsonProperty("deviceBrand")
    private String deviceBrand;

    @Column(name = "device_model")
    @JsonProperty("deviceModel")
    private String deviceModel;

    @Column(name = "operating_system")
    @JsonProperty("operatingSystem")
    private String operatingSystem;

    @Column(name = "operating_system_name")
    @JsonProperty("operatingSystemName")
    private String operatingSystemName;

    @Column(name = "operating_system_code")
    @JsonProperty("operatingSystemCode")
    private String operatingSystemCode;

    @Column(name = "operating_system_version")
    @JsonProperty("operatingSystemVersion")
    private String operatingSystemVersion;

    @Column(name = "browser_family")
    @JsonProperty("browserFamily")
    private String browserFamily;

    @Column(name = "browser_family_description")
    @JsonProperty("browserFamilyDescription")
    private String browserFamilyDescription;

    @Column(name = "browser")
    @JsonProperty("browser")
    private String browser;

    @Column(name = "browser_name")
    @JsonProperty("browserName")
    private String browserName;

    @Column(name = "browser_code")
    @JsonProperty("browserCode")
    private String browserCode;

    @Column(name = "browser_version")
    @JsonProperty("browserVersion")
    private String browserVersion;

    @Column(name = "events")
    @JsonProperty("events")
    private String events;

    @Column(name = "continent")
    @JsonProperty("continent")
    private String continent;

    @Column(name = "continent_code")
    @JsonProperty("continentCode")
    private String continentCode;

    @Column(name = "country")
    @JsonProperty("country")
    private String country;

    @Column(name = "country_code")
    @JsonProperty("countryCode")
    private String countryCode;

    @Column(name = "region")
    @JsonProperty("region")
    private String region;

    @Column(name = "region_code")
    @JsonProperty("regionCode")
    private String regionCode;

    @Column(name = "city")
    @JsonProperty("city")
    private String city;

    @Column(name = "location")
    @JsonProperty("location")
    private String location;

    @Column(name = "latitude")
    @JsonProperty("latitude")
    private String latitude;

    @Column(name = "longitude")
    @JsonProperty("longitude")
    private String longitude;

    @Column(name = "visit_local_time")
    @JsonProperty("visitLocalTime")
    private String visitLocalTime;

    @Column(name = "visit_local_hour")
    @JsonProperty("visitLocalHour")
    private String visitLocalHour;

    @Column(name = "days_since_last_visit")
    @JsonProperty("daysSinceLastVisit")
    private String daysSinceLastVisit;

    @Column(name = "resolution")
    @JsonProperty("resolution")
    private String resolution;

    @Column(name = "plugins")
    @JsonProperty("plugins")
    private String plugins;

    @Column(name = "dimension1")
    @JsonProperty("dimension1")
    private String dimension1;

    @Column(name = "campaign_id")
    @JsonProperty("campaignId")
    private String campaignId;

    @Column(name = "campaign_content")
    @JsonProperty("campaignContent")
    private String campaignContent;

    @Column(name = "campaign_keyword")
    @JsonProperty("campaignKeyword")
    private String campaignKeyword;

    @Column(name = "campaign_medium")
    @JsonProperty("campaignMedium")
    private String campaignMedium;

    @Column(name = "campaign_name")
    @JsonProperty("campaignName")
    private String campaignName;

    @Column(name = "campaign_source")
    @JsonProperty("campaignSource")
    private String campaignSource;

    @Column(name = "created_ts")
    private Date createdTs;

    @Column(name = "modified_ts")
    private Date modifiedTs;

    @Column(name = "event_ts")
    private Date eventTs;

}
