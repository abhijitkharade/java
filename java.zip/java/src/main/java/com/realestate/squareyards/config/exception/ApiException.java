package com.realestate.squareyards.config.exception;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.time.ZonedDateTime;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record ApiException(String message, String status, int code, ZonedDateTime date) {

}
