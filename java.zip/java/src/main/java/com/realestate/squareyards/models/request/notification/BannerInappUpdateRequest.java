package com.realestate.squareyards.models.request.notification;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class BannerInappUpdateRequest {

    @NotNull
    @ApiModelProperty(example = "210", required = true)
    @JsonProperty("goalId")
    private String goalId;

    @NotNull
    @ApiModelProperty(example = "312", required = true)
    @JsonProperty("goalUUID")
    private String goalUUID;

    @NotNull
    @ApiModelProperty(example = "537AA5BFEB7A8ADC", required = true)
    @JsonProperty("visitorId")
    private String visitorId;

    @NotNull
    @ApiModelProperty(example = "1", required = true)
    @JsonProperty("siteId")
    private String siteId;

    @NotNull
    @ApiModelProperty(example = "15323", required = true)
    @JsonProperty("visitId")
    private String visitId;

    @NotNull
    @ApiModelProperty(example = "1532358476468", required = true)
    @JsonProperty("id")
    private String id;
}
