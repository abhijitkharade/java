package com.realestate.squareyards.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.realestate.squareyards.data.cassandra.realestate.AgRequirementNotIntrestedRepository;
import com.realestate.squareyards.data.cassandra.realestate.AgRequirementShortlistedRepository;
import com.realestate.squareyards.data.cassandra.realestate.AgentRequirementsRepository;
import com.realestate.squareyards.models.request.dealgenie.*;
import com.realestate.squareyards.models.response.dealgenie.DGInsertResponse;
import com.realestate.squareyards.models.response.dealgenie.DGReadProperty;
import com.realestate.squareyards.models.response.dealgenie.DGReadRequirementResponse;
import com.realestate.squareyards.models.table.cassandra.AgRequirementNotIntrested;
import com.realestate.squareyards.models.table.cassandra.AgRequirementShortlisted;
import com.realestate.squareyards.models.table.cassandra.AgentRequirements;
import com.realestate.squareyards.models.table.cassandra.AgentRequirementsKey;
import com.realestate.squareyards.utils.Constants;
import com.realestate.squareyards.utils.Types;
import lombok.extern.slf4j.Slf4j;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrRequest;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.data.cassandra.core.query.CassandraPageRequest;
import org.springframework.data.domain.Slice;
import org.springframework.data.solr.core.SolrTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.PostConstruct;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

public interface RequirementsService {

    DGInsertResponse insertRequirement(DGInsert request);

    Boolean saveProperty(DGSaveProperty request);

    DGInsertResponse update(DGEditRequirement editRequest);

    DGReadRequirementResponse readRequirement(DGReadRequirement request);

    DGReadProperty readPropertyData(DGReadProperties request);
}

@Slf4j
@Service
class IRequirementsService implements RequirementsService {

    @Value("${requirement.page.fetch.size:2000}")
    private Integer FETCH_SIZE;

    @Value("${requirement.page.size:2}")
    private Integer SIZE;

    @Value("${category.id.list:0}")
    private List<Integer> CATEGORYID_LIST;

    @Value("${requirement.boost:attribute_dt_range_sort_updateddate:[NOW-1DAY TO *]^1500 OR attribute_dt_range_sort_updateddate:[NOW-2DAY TO *]^1000 OR attribute_dt_range_sort_updateddate:[NOW-5DAY TO *]^500}")
    private String BOOST;

    @Value("${requirement.new.property.filter:attribute_dt_range_sort_updateddate:[NOW-2DAY TO *]}")
    private String NEW_PROPERTY_FILTER;

    @Autowired
    private Environment environment;

    @Autowired
    @Qualifier("solrTemplate")
    private SolrTemplate solrTemplate;

    @Autowired
    private AgentRequirementsRepository agentRequirementsRepository;

    @Autowired
    private AgRequirementNotIntrestedRepository agRequirementNotIntrestedRepository;

    @Autowired
    private AgRequirementShortlistedRepository agRequirementShortlistedRepository;

    private static Map<String, String> RESALE_MAPPING = new HashMap<>();
    private static Map<String, String> RENTAL_MAPPING = new HashMap<>();
    private static Map<String, String> NEW_PROJECT_MAPPING = new HashMap<>();
    private static final String DATE_PATTERN = "dd-MM-yyyy HH:mm:ss";

    @PostConstruct
    public void readFilterMapping() {

        try {
            for (int i = 1; i <= 3; i++) {
                int loop = i;
                String filterMapping = environment.getProperty("filter.mapping." + i, "");
                if (!Strings.isNullOrEmpty(filterMapping)) {
                    JSONObject filterMappingObj = new JSONObject(filterMapping);
                    filterMappingObj.keySet().forEach(e -> {
                        if (loop == 1) {
                            NEW_PROJECT_MAPPING.put(e, filterMappingObj.get(e).toString());
                        }
                        if (loop == 2) {
                            RESALE_MAPPING.put(e, filterMappingObj.get(e).toString());
                        }
                        if (loop == 3) {
                            RENTAL_MAPPING.put(e, filterMappingObj.get(e).toString());
                        }
                    });
                }
            }
        } catch (Exception e) {
            log.error(this.getClass().getName(), "Error -> ", e);
        }
    }

    @Override
    public Boolean saveProperty(DGSaveProperty request) {

        if ("shortlisted".equals(request.getType().name())) {
            return insertRequirementShortlisted(request);
        } else if ("not_interested".equals(request.getType().name())) {
            return insertRequirementNotIntrested(request);
        }
        return false;
    }

    @Override
    public DGInsertResponse insertRequirement(DGInsert request) {

        if (request.getCategoryId() == 0 || !CATEGORYID_LIST.contains(request.getCategoryId())) {
            log.error(this.getClass().getName(), "invalid category Id ");
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid Caegory Id ");
        }

        AgentRequirements agReq = new AgentRequirements(request);
        AgentRequirements res = agentRequirementsRepository.save(agReq);
        if (res.getAgentRequirementsKey().getRequirementId() != null) {
            return new DGInsertResponse(res.getAgentRequirementsKey().getRequirementId());
        }
        return new DGInsertResponse();
    }

    private Boolean insertRequirementShortlisted(DGSaveProperty request) {

        AgRequirementShortlisted agReq = new AgRequirementShortlisted(request);
        agRequirementShortlistedRepository.save(agReq);
        return Boolean.TRUE;
    }

    private Boolean insertRequirementNotIntrested(DGSaveProperty request) {

        AgRequirementNotIntrested agReq = new AgRequirementNotIntrested(request);
        agRequirementNotIntrestedRepository.save(agReq);
        return Boolean.TRUE;
    }

    @Override
    public DGReadRequirementResponse readRequirement(DGReadRequirement request) {

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DATE_PATTERN);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("IST"));
        List<AgentRequirements> subListVo = new ArrayList<>();
        Boolean isLast = Boolean.FALSE;

        Slice<AgentRequirements> findAll = agentRequirementsRepository.findByStatusAndAgentRequirementsKeyAgentId(Constants.ACTIVE,
                request.getAgentId(), CassandraPageRequest.first(FETCH_SIZE));

        int currPage = 1;
        while (findAll.hasNext() && FETCH_SIZE < request.getPageNumber() * request.getPageSize()) {
            findAll = agentRequirementsRepository.findByStatusAndAgentRequirementsKeyAgentId(Constants.ACTIVE,
                    request.getAgentId(), findAll.nextPageable());
            currPage++;
        }

        List<AgentRequirements> agentRequirementsList = findAll.toList();
        List<AgentRequirements> requirementsCopy = new ArrayList<>();
        requirementsCopy.addAll(agentRequirementsList);
        if (requirementsCopy != null && !requirementsCopy.isEmpty()) {
            requirementsCopy.sort(new Comparator<AgentRequirements>() {
                @Override
                public int compare(AgentRequirements o1, AgentRequirements o2) {
                    return o2.getModifiedTs().compareTo(o1.getModifiedTs());
                }
            });
        }

        if (currPage * FETCH_SIZE > request.getPageNumber() * request.getPageSize()) {
            subListVo = requirementsCopy.subList(request.getPageSize() * (request.getPageNumber() - 1), request.getPageSize() * request.getPageNumber() > requirementsCopy.size() ? requirementsCopy.size() : request.getPageSize() * request.getPageNumber());
            subListVo.forEach(e -> {
                int count = agRequirementShortlistedRepository.countByRequirementId(e.getAgentRequirementsKey().getAgentId(), e.getAgentRequirementsKey().getRequirementId());
                e.setShortListedCount(count);
                e.setNewPropertyCount(getMatchedCount(new DGReadProperty(), new ArrayList<String>(), e, 1, 0, true));
            });
            if (request.getPageSize() * request.getPageNumber() >= requirementsCopy.size()) {
                isLast = Boolean.TRUE;
            } else {
                isLast = Boolean.FALSE;
            }
        }

        return new DGReadRequirementResponse(subListVo, isLast, request.getPageNumber());
    }

    @Override
    public DGInsertResponse update(DGEditRequirement editRequest) {

        DGInsertResponse response = new DGInsertResponse();
        try {
            AgentRequirementsKey reqKey = new AgentRequirementsKey();
            reqKey.setAgentId(editRequest.getAgentId());
            reqKey.setRequirementId(editRequest.getRequirementId());

            Optional<AgentRequirements> voOpt = agentRequirementsRepository.findById(reqKey);
            if (voOpt.isPresent()) {
                AgentRequirements vo = voOpt.get();

                if (!Strings.isNullOrEmpty(editRequest.getStatus().name())) {
                    vo.setStatus(editRequest.getStatus().name());
                }
                if (!Strings.isNullOrEmpty(editRequest.getRequirementName())) {
                    vo.setRequirementName(editRequest.getRequirementName());
                }
                if (editRequest.getFilters() != null) {
                    JSONObject filters = new JSONObject(new ObjectMapper().writeValueAsString(editRequest.getFilters()));
                    Map<String, String> map = new HashMap<>();

                    filters.keySet().forEach(keyStr -> {
                        JSONArray keyValue = filters.getJSONArray(keyStr);
                        map.put(keyStr, keyValue.toString());
                    });

                    if (!map.isEmpty()) {
                        vo.setFilters(map);
                    }
                }
                vo.setModifiedTs(new Date());
                AgentRequirements voRes = agentRequirementsRepository.save(vo);
                if (voRes.getAgentRequirementsKey().getRequirementId() != null) {
                    response.setRequirementId(voRes.getAgentRequirementsKey().getRequirementId());
                    return response;
                }

            }
        } catch (Exception e) {
            log.error("error ->", e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error ", e);
        }
        return new DGInsertResponse();
    }

    private AgentRequirements getAgentRequirement(String agentId, String requirementId) {

        return agentRequirementsRepository.findAgentRequirement(agentId, requirementId, "ACTIVE");
    }

    private List<AgRequirementShortlisted> getShortlistedProperty(String agentId, String requirementId) {

        try {
            return agRequirementShortlistedRepository.findByRequirementId(agentId, requirementId, "ACTIVE");
        } catch (Exception e) {
            log.error(this.getClass().getName(), "Error -> ", e);
        }
        return new ArrayList<>();
    }

    private List<AgRequirementNotIntrested> getNotIntrestedProperty(String agentId, String requirementId) {

        try {
            return agRequirementNotIntrestedRepository.findByRequirementId(agentId, requirementId, "ACTIVE");
        } catch (Exception e) {
            log.error(this.getClass().getName(), "Error -> ", e);
        }
        return new ArrayList<>();
    }

    @Override
    public DGReadProperty readPropertyData(DGReadProperties request) {

        DGReadProperty response = new DGReadProperty();
        boolean isLast = false;
        List<String> propertyId = new ArrayList<>();
        try {
            String type = request.getType().name();
            String agentId = request.getAgentId();
            String requirementId = request.getRequirementId();
            int page = request.getPageNumber() <= 0 ? 1 : request.getPageNumber();
            int size = request.getPropertyCount() > 100 ? 10 : request.getPropertyCount();

            if (Types.DEAL_GENIE_STATUS.shortlisted.name().equalsIgnoreCase(type)) {
                isLast = getShortListedPropertyIds(propertyId, agentId, requirementId, page, size);
            } else if (Types.DEAL_GENIE_STATUS.not_interested.name().equalsIgnoreCase(type)) {
                isLast = getNotInterestedPropertyIds(propertyId, agentId, requirementId, page, size);
            } else if (Types.DEAL_GENIE_STATUS.matched.name().equalsIgnoreCase(type)) {
                getMatchedProperty(response, propertyId, agentId, requirementId, page, size);
            }
        } catch (Exception e) {
            log.error("error ->", e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error ", e);
        }

        if (propertyId.isEmpty()) {
            isLast = true;
        }
        response.setPropertyId(propertyId);
        response.setLast(isLast);
        return response;

    }

    private long getMatchedProperty(DGReadProperty response, List<String> propertyId, String agentId, String requirementId, int page, int size) {

        try {
            AgentRequirements agentRequirement = getAgentRequirement(agentId, requirementId);
            getShortListedPropertyIds(propertyId, agentId, requirementId, 1, 1000);
            getNotInterestedPropertyIds(propertyId, agentId, requirementId, 1, 1000);
            return getMatchedCount(response, propertyId, agentRequirement, page, size, false);
        } catch (Exception e) {
            log.error("error ->", e);
            propertyId.clear();
        }
        return 0;
    }

    private long getMatchedCount(DGReadProperty response, List<String> propertyId, AgentRequirements agentRequirement, int page, int size, boolean isNewProperty) {

        long totalCount = 0;
        boolean isLast = false;
        try {
            if (agentRequirement != null) {
                int categoryId = agentRequirement.getCategoryId();
                SolrQuery query = new SolrQuery("*:*");
                query.setStart(page - 1);
                query.setRows(size);
                query.set("defType", "edismax");
                query.addFilterQuery("taxonomy_id:" + categoryId);
                query.addFilterQuery("{!parent which=\"doc_type:parent\"}");
                if (!propertyId.isEmpty()) {
                    List<String> groupIds = propertyId.stream().map(e -> e + "_" + categoryId + "_group").collect(Collectors.toList());
                    query.addFilterQuery("-group_id:(\"" + String.join("\" OR \"", groupIds) + "\")");
                }
                propertyId.clear();
                setFilters(agentRequirement, categoryId, query);
                query.set("bq", BOOST);
                if (isNewProperty) {
                    query.addFilterQuery(NEW_PROPERTY_FILTER);
                }
                log.info(this.getClass().getName(), " Query -> " + query);
                QueryResponse queryResponse = solrTemplate.getSolrClient().query("squareyards_online", query, SolrRequest.METHOD.POST);
                if (queryResponse != null) {
                    propertyId.addAll(queryResponse.getResults().stream().map(doc -> doc.getFieldValue("group_id").toString().split("_")[categoryId == 4 ? 1 : 0])
                            .distinct().collect(Collectors.toList()));
                    totalCount = queryResponse.getResults().getNumFound();
                    int totalPages = (int) Math.ceil((double) totalCount / size);
                    isLast = totalPages == page;
                    response.setLast(isLast);
                }
            } else {
                propertyId.clear();
            }
        } catch (Exception e) {
            log.error("error ->", e);
            propertyId.clear();
        }
        return totalCount;
    }

    private void setFilters(AgentRequirements agentRequirement, int categoryId, SolrQuery query) {

        JSONObject filters = getFiltersObject(agentRequirement.getFilters());
        StringBuilder fieldList = new StringBuilder();
        filters.keySet().forEach(e -> {
            List<String> filterList = filters.getJSONArray(e).toList().stream().map(Object::toString).collect(Collectors.toList());
            String filterKey = e;
            if (categoryId == 1) {
                filterKey = NEW_PROJECT_MAPPING.getOrDefault(e, e);
            } else if (categoryId == 2) {
                filterKey = RESALE_MAPPING.getOrDefault(e, e);
            } else if (categoryId == 3) {
                filterKey = RENTAL_MAPPING.getOrDefault(e, e);
            }

            if ("price".equalsIgnoreCase(filterKey)) {
                fieldList.append(createPriceRangeQuery(query, filters.getJSONArray(e)));

            } else if (filterKey.contains("attribute_range_")) {
                createRangeFilter(query, filters.getJSONArray(e), filterKey);
            } else if (!Strings.isNullOrEmpty(environment.getProperty(filterKey + ".mapping", ""))) {
                JSONObject mappingObj = new JSONObject(environment.getProperty(filterKey + ".mapping", "{}"));
                List<String> newValues = new ArrayList<>();

                filterList.forEach(fl -> {
                    if (mappingObj.has(fl)) {
                        newValues.add(mappingObj.getString(fl));
                    } else {
                        newValues.add(fl);
                    }
                });

                if (!newValues.isEmpty()) {
                    query.addFilterQuery(filterKey + ":(\"" + String.join("\" OR \"", newValues) + "\")");
                }
            } else if (!filterList.isEmpty()) {
                query.addFilterQuery(filterKey + ":(\"" + String.join("\" OR \"", filterList) + "\")");
            }

        });
        if (categoryId != 1) {
            query.addFilterQuery("attribute_dt_range_expireddate:[NOW TO  *]");
        }
        query.setFields("group_id" + ",[child parentFilter=doc_type:parent " + fieldList.toString() + "]");
    }

    private JSONObject getFiltersObject(Map<String, String> filters) {

        try {
            if (filters != null && !filters.isEmpty()) {
                JSONObject filtersJson = new JSONObject(new ObjectMapper().writeValueAsString(filters));
                JSONObject resultObject = new JSONObject(filtersJson.toString());

                filters.keySet().forEach(e -> {
                    String filterString = resultObject.get(e).toString();
                    if (!Strings.isNullOrEmpty(filterString)) {
                        String filterArray = filterString.substring(0, filterString.length());
                        resultObject.put(e, new JSONArray(filterArray));
                    }
                });
                return resultObject;

            }
        } catch (Exception e) {
            log.error(this.getClass().getName(), "error -> ", e);
        }
        return new JSONObject();
    }

    private void createRangeFilter(SolrQuery similarDocsQuery, JSONArray sizeArray, String filterName) {

        try {
            List<Double> sizeList = new ArrayList<Double>();

            if (sizeArray != null) {
                sizeArray.toList().stream().forEach(e -> sizeList.add(Double.parseDouble(e.toString())));
            }
            Collections.sort(sizeList);
            if (!sizeList.isEmpty()) {
                Double lowSize = sizeList.get(0);
                Double highSize = sizeList.get(sizeList.size() - 1);
                if (lowSize.compareTo(0d) >= 0 && highSize.compareTo(0d) >= 0) {

                    similarDocsQuery.addFilterQuery(filterName + ":[" + lowSize + " TO " + highSize + "]");
                    log.info(this.getClass().getName(), filterName + lowSize + " , " + highSize);

                }
            }
        } catch (Exception e) {
            log.error(this.getClass().getName(), "Error -> ", e);
        }
    }

    private String createPriceRangeQuery(SolrQuery similarDocsQuery, JSONArray priceArray) {

        try {
            List<Double> priceList = new ArrayList<Double>();

            if (priceArray != null) {
                priceArray.toList().stream().forEach(e -> priceList.add(Double.parseDouble(e.toString())));
            }
            Collections.sort(priceList);
            if (!priceList.isEmpty()) {
                Double lowPrice = priceList.get(0);
                Double highPrice = priceList.get(priceList.size() - 1);
                if (lowPrice.compareTo(0d) >= 0 && highPrice.compareTo(0d) >= 0) {

                    similarDocsQuery.addFilterQuery("{!parent which=\"doc_type:parent\"}(retailer_price:[" + lowPrice + " TO " + highPrice + "])");
                    log.info(this.getClass().getName(), "price filter " + lowPrice + " , " + highPrice);
                    return "childFilter=\"retailer_price:[" + lowPrice + " TO " + highPrice + "]\" ";

                }
            }
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "price range query exception ", e);
        }
        return "";
    }

    private boolean getNotInterestedPropertyIds(List<String> propertyId, String agentId, String requirementId, int page, int size) {

        List<AgRequirementNotIntrested> requirements = getNotIntrestedProperty(agentId, requirementId);
        if (requirements != null && !requirements.isEmpty()) {
            requirements.sort(new Comparator<AgRequirementNotIntrested>() {

                @Override
                public int compare(AgRequirementNotIntrested o1, AgRequirementNotIntrested o2) {

                    return o2.getModifiedTs().compareTo(o1.getModifiedTs());
                }
            });

            List<List<AgRequirementNotIntrested>> partition = Lists.partition(requirements, size);
            if (partition.size() >= page) {
                List<AgRequirementNotIntrested> pageRequirement = partition.get(page - 1);
                propertyId.addAll(pageRequirement.stream().filter(e -> e.getAgRequirementNotIntrestedKey().getNotIntrestedId() != null)
                        .map(e -> e.getAgRequirementNotIntrestedKey().getNotIntrestedId()).collect(Collectors.toList()));
            }
            if (partition.size() == 0 || partition.size() == page) {
                return true;
            }
        }
        return false;
    }

    private boolean getShortListedPropertyIds(List<String> propertyId, String agentId, String requirementId, int page, int size) {

        List<AgRequirementShortlisted> requirements = getShortlistedProperty(agentId, requirementId);
        if (requirements != null && !requirements.isEmpty()) {
            requirements.sort((o1, o2) -> o2.getModifiedTs().compareTo(o1.getModifiedTs()));

            List<List<AgRequirementShortlisted>> partition = Lists.partition(requirements, size);
            if (partition.size() >= page) {
                List<AgRequirementShortlisted> pageRequirement = partition.get(page - 1);
                propertyId.addAll(pageRequirement.stream().filter(e -> e.getAgRequirementShortlistedKey().getShortlistedId() != null)
                        .map(e -> e.getAgRequirementShortlistedKey().getShortlistedId()).collect(Collectors.toList()));
            }
            if (partition.size() == 0 || partition.size() == page) {
                return true;
            }
        }
        return false;
    }
}
