package com.realestate.squareyards.data.cassandra.realestate;

import com.realestate.squareyards.models.table.cassandra.AgRequirementNotIntrested;
import com.realestate.squareyards.models.table.cassandra.AgRequirementNotIntrestedKey;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface AgRequirementNotIntrestedRepository extends CassandraRepository<AgRequirementNotIntrested, AgRequirementNotIntrestedKey> {

    @Query(value = "select * from realestate_squareyards.ag_requirement_not_intrested where agent_id = :agent_id AND requirement_id= :requirement_id AND status= :status limit 1000")
    List<AgRequirementNotIntrested> findByRequirementId(@Param("agent_id") String agentId, @Param("requirement_id") String requirementId, @Param("status") String status);

}
