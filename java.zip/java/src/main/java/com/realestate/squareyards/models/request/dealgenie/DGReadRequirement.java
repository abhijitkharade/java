package com.realestate.squareyards.models.request.dealgenie;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class DGReadRequirement {

    @NotNull
    @ApiModelProperty(example = "agent-123", required = true)
    @JsonProperty("agent_id")
    private String agentId;

    @NotNull
    @ApiModelProperty(example = "1", required = true)
    @JsonProperty("page_number")
    private int pageNumber = 1;

    @ApiModelProperty(example = "1", required = false)
    @JsonProperty("page_size")
    private int pageSize = 10;

}
