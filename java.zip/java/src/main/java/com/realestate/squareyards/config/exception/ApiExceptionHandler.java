package com.realestate.squareyards.config.exception;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.server.ResponseStatusException;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.stream.Collectors;

@ControllerAdvice
@Slf4j
public class ApiExceptionHandler {

    @ExceptionHandler(value = ResponseStatusException.class)
    public ResponseEntity<Object> handleException(ResponseStatusException e) {
        String message = e.getReason() != null ? e.getReason() : "oops! something went wrong...";
        String status = e.getStatus() != null ? e.getStatus().name() : HttpStatus.INTERNAL_SERVER_ERROR.name();
        int code = e.getStatus() != null ? e.getStatus().value() : HttpStatus.INTERNAL_SERVER_ERROR.value();
        ApiException exception = new ApiException(message, status, code, ZonedDateTime.now());
        log.error("error ", e);
        return new ResponseEntity<>(exception, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    public ResponseEntity<Object> validationException(MethodArgumentNotValidException e) {

        List<String> errorFields = e.getFieldErrors().stream().map(errors -> errors.getField()).collect(Collectors.toList());
        String message = StringUtils.join(errorFields, " ,") + " must not be null.";
        String status = HttpStatus.BAD_REQUEST.name();
        int code = HttpStatus.BAD_REQUEST.value();
        ApiException exception = new ApiException(message, status, code, ZonedDateTime.now());
        log.error("error " + e.getMessage());
        return new ResponseEntity<>(exception, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(value = Exception.class)
    public ResponseEntity<Object> handleGenericException(Exception e) {

        String message = "oops! something went wrong...";
        String status = HttpStatus.INTERNAL_SERVER_ERROR.name();
        int code = HttpStatus.INTERNAL_SERVER_ERROR.value();
        ApiException exception = new ApiException(message, status, code, ZonedDateTime.now());
        log.error("error ", e);
        return new ResponseEntity<>(exception, HttpStatus.BAD_REQUEST);
    }

}
