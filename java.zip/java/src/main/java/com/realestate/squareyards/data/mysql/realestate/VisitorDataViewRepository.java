package com.realestate.squareyards.data.mysql.realestate;

import com.realestate.squareyards.models.table.mysql.VisitorDataView;
import com.realestate.squareyards.models.table.mysql.VisitorDataViewKey;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface VisitorDataViewRepository extends CrudRepository<VisitorDataView, VisitorDataViewKey> {

    @Query(value = "select * from visitor_data_view where taxonomy_id = :taxonomyId and visitor_id= :visitorId and event_date in :eventDate and product_type= :productType limit :limit", nativeQuery = true)
    List<VisitorDataView> findByVisitorIdAndEventDates(@Param("visitorId") String visitorId, @Param("eventDate") List<Integer> eventDates, @Param("taxonomyId") int taxonomyId,
                                                       @Param("productType") String productType, @Param("limit") int limit);

    @Query(value = "SELECT * FROM visitor_data_view_tmp WHERE JSON_SEARCH(group_id_list, 'all', :group_id) is not null AND " + "taxonomy_id = :taxonomy limit 100", nativeQuery = true)
    List<VisitorDataView> findGroupedVisitorClicks(@Param("group_id") String groupId, @Param("taxonomy") Integer taxonomyId);
}
