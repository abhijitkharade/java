package com.realestate.squareyards.data.mysql.realestate;

import com.realestate.squareyards.models.table.mysql.UserLoginInfo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import javax.annotation.Nullable;
import java.util.List;

public interface UserLoginInfoRepository extends CrudRepository<UserLoginInfo, String> {

    @Nullable
    @Query(value = "select visitor_id from user_login_info where phone_number = ?1", nativeQuery = true)
    List<String> findVisitorIdByPhoneNumber(String phoneNumber);
}
