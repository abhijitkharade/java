package com.realestate.squareyards.utils;

public class Routes {

    // Main Controller
    public static final String DEAL_GENIE = "/deal_genie";
    public static final String WEB_B2C = "/web-b2c";
    public static final String OPEN = "/open";
    public static final String VERSION_1_0 = "/v1.0";
    public static final String VERSION = "/{version}";
    public static final String DEVICE = "/{device}";
    public static final String LISTING = "/listing";

    //common end points
    public static final String INSERT = VERSION + "/insert";
    public static final String READ = VERSION + "/read";
    public static final String EDIT = VERSION + "/edit";
    public static final String SAVE = VERSION + "/save";
    public static final String TOKEN = VERSION + "/token";
    public static final String SEND = DEVICE + "/send";

    //Deal Genie
    public static final String REQUIREMENTS = "/requirements";
    public static final String PROPERTIES = "/properties";
    public static final String NOTIFICATION = "/notification";

    // Notification
    public static final String NOTIFICATION_MSG = VERSION + "/notification_msg";
    public static final String UPDATE_NOTIFICATION = VERSION + "/update_notification";
    public static final String NOTIFICATION_REDIRECT_FLAG = VERSION + "/notification_redirect_flag";

    // Real Time User Similarity
    public static final String RECOMMENDATION = "/recommendation";
    public static final String UPDATE_USER_FV = "/update";
    public static final String READ_USER_FV = "/read";
    public static final String SIMILAR_PROJECTS_URL = "/similar-projects";
    public static final String VISITOR_SIMILAR_URL = "/visitor-similar-projects";

    // Recent Activity
    public static final String RECENT_ACTIVITY_COUNT = VERSION + "/recent-activity-count";
    public static final String CLICK_DATA = VERSION + "/click-data";
    public static final String ENQUIRED_DATA = VERSION + "/enquired-data";
    public static final String SHORTLISTED_DATA = VERSION + "/shortlisted-data";
    public static final String SEARCHED_DATA = VERSION + "/searched-data";
    public static final String TOP_SEARCHED_DATA = VERSION + "/top-searched-data";
    public static final String RECENT_ACTIVITY = VERSION + "/recent-activity";
    public static final String PRODUCT_COUNT_DETAILS_URL = VERSION + "/product-count-details";

    //    trending properties
    public static final String TRENDING_PROPERTIES = VERSION + "/trending-properties";
    public static final String SUB_LOCATION_TRENDING_PROPERTIES = VERSION + "/sub-location-trending-properties";
    public static final String TRENDING_KEYWORDS = VERSION + "/trending_keywords";

    public static final String IMPRESSION_BASED = "impression-based";

    //money control
    public static final String MONEY_CONTROL = "/money-control";
    public static final String WIDGET = "/widget";


}
