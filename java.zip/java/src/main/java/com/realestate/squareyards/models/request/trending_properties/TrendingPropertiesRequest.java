package com.realestate.squareyards.models.request.trending_properties;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class TrendingPropertiesRequest {

    @NotNull
    @ApiModelProperty(example = "mumbai", required = true)
    private String city;

    @NotNull
    @ApiModelProperty(example = "1", required = true)
    private String categoryId;
}
