package com.realestate.squareyards.models.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseBuilderV1<T> {

    @ApiModelProperty(example = "200")
    private int code;

    @ApiModelProperty(example = "OK")
    private String status;

    @ApiModelProperty
    private T result;
}
