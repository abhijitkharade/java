package com.realestate.squareyards.core.dse.solr;

import lombok.extern.slf4j.Slf4j;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrRequest;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.data.solr.core.SolrTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

@NoRepositoryBean
@Slf4j
public abstract class DseSolrBaseRepository {

    @Autowired
    @Qualifier("dseSolrTemplate")
    private SolrTemplate solrTemplate;

    protected QueryResponse search(String collectionName, SolrQuery query) {
        try {
            log.info("Solr Query " + collectionName + " -> " + query);
            return solrTemplate.getSolrClient().query(collectionName, query, SolrRequest.METHOD.POST);
        } catch (Exception e) {
            log.error("error ", e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
