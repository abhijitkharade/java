package com.realestate.squareyards.config.database;

import com.datastax.driver.core.Cluster;
import com.realestate.squareyards.utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.data.cassandra.config.CassandraSessionFactoryBean;
import org.springframework.data.cassandra.config.SchemaAction;
import org.springframework.data.cassandra.core.CassandraTemplate;
import org.springframework.data.cassandra.repository.config.EnableCassandraRepositories;

import javax.annotation.Resource;

@Configuration
@EnableCassandraRepositories(basePackages = "com.realestate.squareyards.data.cassandra.propamcanalytics", cassandraTemplateRef = "keyspacePropamcAnalyticsCassandraTemplate")
@DependsOn("cassandraClusterCustom")
public class CassandraConfigPropamcAnalytics {

    @Autowired
    CassandraConfig cassandraConfig;
    @Resource(name = Constants.CLUSTER_PREFIX + "${propamc_analytics.cluster}")
    Cluster cluster;

    private String keyspace = "propamc_analytics";

    @Bean("keyspacePropamcAnalyticsSession")
    public CassandraSessionFactoryBean session() {

        CassandraSessionFactoryBean session = new CassandraSessionFactoryBean();
        session.setCluster(cluster);
        session.setKeyspaceName(keyspace);
        session.setConverter(cassandraConfig.converter());
        session.setSchemaAction(SchemaAction.NONE);
        return session;
    }

    @Bean("keyspacePropamcAnalyticsCassandraTemplate")
    public CassandraTemplate cassandraTemplate() {

        return new CassandraTemplate(session().getObject());
    }
}
