package com.realestate.squareyards.models.table.cassandra;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import java.time.LocalDate;

@Table("widget_master")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WidgetMaster {
    @PrimaryKey
    private WidgetMasterKey widgetMasterKey;

    @Column("asset_type")
    private String assetType;

    @Column("avg_rate")
    private String avgRate;

    @Column("change_percentage")
    private String changePercentage;

    @Column("created_ts")
    private LocalDate createdTs;

    @Column("location")
    private String location;

    @Column("no_of_transactions")
    private String noOfTransactions;

    @Column("project_id")
    private String projectId;

    @Column("project_name")
    private String projectName;

    @Column("transaction_category")
    private String transactionCategory;

    @Column("transaction_type")
    private String transactionType;






}
