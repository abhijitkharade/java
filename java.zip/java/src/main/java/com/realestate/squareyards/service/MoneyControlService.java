package com.realestate.squareyards.service;

import com.realestate.squareyards.data.cassandra.propamcanalytics.MoneyControlRepository;
import com.realestate.squareyards.models.request.moneycontrol.MoneyControlRequest;
import com.realestate.squareyards.models.response.moneycontrol.MoneyControlResponse;

import com.realestate.squareyards.models.table.cassandra.WidgetMaster;
import com.realestate.squareyards.models.table.cassandra.WidgetMasterKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


public interface MoneyControlService {
    WidgetMaster findByKey(WidgetMasterKey key);
    List findTop(WidgetMasterKey key);

    MoneyControlResponse findAllAggregation(MoneyControlRequest req);
}

@Service
class MoneyControlServiceImpl implements MoneyControlService {

    @Autowired
    MoneyControlRepository moneyControlRepository;
    @Override
    public WidgetMaster findByKey(WidgetMasterKey key) {
        Optional<WidgetMaster> voOpt = moneyControlRepository.findById(key);
        if(voOpt.isPresent()){
            return voOpt.get() ;
        }
        return null ;
    }

    @Override
    public List findTop(WidgetMasterKey key) {
        String widget = key.getWidget();
        String tab = key.getTab();
        String  categoryName=  key.getCategoryName();
        String  aggregationFrom= key.getAggregationFrom();
        Integer priority= key.getPriority();
       List<WidgetMaster>  voOpt = moneyControlRepository.findTop(widget,tab,categoryName,aggregationFrom,priority);

      voOpt.forEach(e-> System.out.println(e));

        if(!voOpt.isEmpty()){
            return voOpt ;
        }
        return null;
    }

    @Override
    public MoneyControlResponse findAllAggregation(MoneyControlRequest req) {

        String city=req.getCity();
        String widget = req.getWidget();
        List<String> tabs= req.getTabs();
        List<String> categories=  req.getCategories();
        List<String> aggregationFromList= req.getAggregationFromList();
        List<Integer> priority=new ArrayList<>(req.getPriority());
                if (req.getPriority()<1)
                    priority.add(1);
                for (int i=1;i<= req.getPriority();i++)
                    priority.add((Integer) i);


        List<WidgetMaster>  voOpt = moneyControlRepository.findByReq(city,widget,tabs,categories,aggregationFromList,priority);


        return new MoneyControlResponse(voOpt,req);
    }

}