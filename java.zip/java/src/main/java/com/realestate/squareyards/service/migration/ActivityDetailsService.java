package com.realestate.squareyards.service.migration;

import com.google.common.base.Strings;
import com.realestate.squareyards.data.cassandra.realestate.*;
import com.realestate.squareyards.data.cassandra.realestate.custom.EnquiryDetailsCustomRepository;
import com.realestate.squareyards.models.request.recent_activity.RecentActivityClickRequest;
import com.realestate.squareyards.models.request.recent_activity.RecentActivityCountRequest;
import com.realestate.squareyards.models.request.recent_activity.RecentActivitySearchRequest;
import com.realestate.squareyards.models.response.recent_activity.ActivityResponse;
import com.realestate.squareyards.models.response.recent_activity.ClickEnquiredShortlistResponse;
import com.realestate.squareyards.models.response.recent_activity.CountResponse;
import com.realestate.squareyards.models.response.recent_activity.SeaarchResponse;
import com.realestate.squareyards.models.table.cassandra.*;
import com.realestate.squareyards.utils.Constants;
import com.realestate.squareyards.utils.Types;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.cassandra.core.query.CassandraPageRequest;
import org.springframework.data.domain.Slice;
import org.springframework.stereotype.Service;

import java.nio.charset.Charset;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

public interface ActivityDetailsService {

    CountResponse getCount(RecentActivityCountRequest request);

    ClickEnquiredShortlistResponse getClickData(RecentActivityClickRequest request);

    ClickEnquiredShortlistResponse getEnquiryData(RecentActivityClickRequest request);

    ClickEnquiredShortlistResponse getShortlistedData(RecentActivityClickRequest request);

    ClickEnquiredShortlistResponse getSearchedData(RecentActivityClickRequest request);

    Map<Object, Object> getTopSearchedData(RecentActivitySearchRequest request);

    boolean isValidKeyword(String searchKeyword, String url);

}

@Slf4j
@Service
class IActivityDetailsService implements ActivityDetailsService {

    @Autowired
    RecentEventTrackingRepository recentEventTrackingRepository;

    @Autowired
    RecentEventSearchTrackingRepository recentEventSearchTrackingRepository;

    @Autowired
    VisitedCitiesRepository visitedCitiesRepository;

    @Autowired
    EventClickTrackingRepository eventClickTrackingRepository;

    @Autowired
    EventEnquiredTrackingRepostiory eventEnquiredTrackingRepostiory;

    @Autowired
    EventShortlistedTrackingRepository eventShortlistedTrackingRepository;

    @Autowired
    EventSearchTrackingRepository eventSearchTrackingRepository;

    @Autowired
    TaxonomyRepository taxonomyRepository;

    @Autowired
    UserLoginInfoPhoneNumberViewRepository userLoginInfoPhoneNumberViewRepository;

    @Autowired
    EnquiryDetailsCustomRepository enquiryDetailsCustomRepository;

    private static final String DATE_PATTERN = "dd-MM-yyyy HH:mm:ss";

    @Value("${page.size:2}")
    private Integer SIZE;

    @Value("${search.limit:5}")
    private Integer SEARCH_LIMIT;

    @Value("${page.fetch.size:2000}")
    private Integer FETCH_SIZE;

    @Value("${piwik.ignore.trending.keywords}")
    private List<String> IGNORE_KEYWORDS;

    @Value("${sy.domain.name}")
    private String DOMAIN;

    @Override
    public CountResponse getCount(RecentActivityCountRequest request) {
        List<String> categories = new ArrayList<>();
        Map<String, Object> responseMap = new LinkedHashMap<>();

        String typeId = request.getCategoryId();

        if (!Strings.isNullOrEmpty(typeId)) {
            Optional<Taxonomy> taxonomyVoOpt = taxonomyRepository.findById(Integer.parseInt(typeId));
            if (!taxonomyVoOpt.isPresent()) {
                return new CountResponse();
            }
            Taxonomy taxonomyVo = taxonomyVoOpt.get();
            categories.add(taxonomyVo.getCategoryName());
        } else {
            categories = getCategories();
        }
        List<String> visitorIdList = getVisitorIdList(request.getVisitorId(), request.getPhoneNumber());

        long clickCount = recentEventTrackingRepository.countByRecentEventTrackingKeyEventTypeAndRecentEventTrackingKeyCategoryNameInAndRecentEventTrackingKeyVisitorIdIn(Constants.CLICK, categories, visitorIdList);
        long shortlistCount = recentEventTrackingRepository.countByRecentEventTrackingKeyEventTypeAndRecentEventTrackingKeyCategoryNameInAndRecentEventTrackingKeyVisitorIdIn(Constants.SHORTLISTED_ADD, categories, visitorIdList);
        long enquiryCount = recentEventTrackingRepository.countByRecentEventTrackingKeyEventTypeAndRecentEventTrackingKeyCategoryNameInAndRecentEventTrackingKeyVisitorIdIn(Constants.ENQUIRED, categories, visitorIdList);

        long searchCount = 0;

        List<String> cityList = getCityList(visitorIdList);

        if (!cityList.isEmpty()) {
            searchCount = recentEventSearchTrackingRepository.countByRecentEventSearchTrackingKeyCategoryNameInAndRecentEventSearchTrackingKeyVisitorIdInAndRecentEventSearchTrackingKeyCityIn(categories, visitorIdList, cityList);
        }
        CountResponse response = new CountResponse(clickCount, enquiryCount, shortlistCount, searchCount);
        return response;
    }

    @Override
    public ClickEnquiredShortlistResponse getClickData(RecentActivityClickRequest request) {
        ClickEnquiredShortlistResponse clickData = new ClickEnquiredShortlistResponse();
        List<ActivityResponse> listVo = new ArrayList<>();
        List<ActivityResponse> subListVo = new ArrayList<>();

        Map<String, Object> mapData;

        String typeId = request.getCategoryId();

        List<String> visitorIdList = getVisitorIdList(request.getVisitorId(), request.getPhoneNumber());

        if (!visitorIdList.isEmpty()) {

            mapData = getCategoryData(visitorIdList, typeId, Constants.CLICK);
            int pageSize = request.getPageSize() < 0 ? SIZE : request.getPageSize();
            int pageFetchSize = FETCH_SIZE;
            int pageNumber = request.getPageNumber();
            Boolean isLast = Boolean.FALSE;

            if (!mapData.isEmpty()) {

                List<Date> eventTs = (List<Date>) mapData.get(Constants.JSON_KEY_EVENT_TS);
                List<String> idList = (List<String>) mapData.get(Constants.JSON_KEY_ID);
                Object cat = mapData.get(Constants.JSON_KEY_CATEGORYNAME);
                List<String> categoriesList = (ArrayList) cat;

                Slice<EventClickTracking> findAll = eventClickTrackingRepository.findByUniqueData(categoriesList, visitorIdList, idList,
                        CassandraPageRequest.first(pageFetchSize));
                int currPage = 1;

                while (findAll.hasNext() && pageFetchSize < pageNumber * pageSize) {
                    findAll = eventClickTrackingRepository.findByUniqueData(categoriesList, visitorIdList, idList, findAll.nextPageable());
                    currPage++;
                }

                if (currPage * pageFetchSize > pageNumber * pageSize) {
                    for (EventClickTracking vo : findAll) {
                        listVo.add(new ActivityResponse(vo, DATE_PATTERN));
                    }

                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_PATTERN);

                    listVo.sort((a, b) -> LocalDateTime.parse(b.getEventTs(), formatter).compareTo(LocalDateTime.parse(a.getEventTs(), formatter)));

                    subListVo = listVo.subList(pageSize * (pageNumber - 1), pageSize * pageNumber > listVo.size() ? listVo.size() : pageSize * pageNumber);
                    if (pageSize * pageNumber >= listVo.size()) {
                        isLast = Boolean.TRUE;
                    } else {
                        isLast = Boolean.FALSE;
                    }
                }

                clickData.setIsLast(isLast);
                clickData.setPageNumber(request.getPageNumber());
                clickData.setClickData(subListVo);

            }
        }
        return clickData;
    }

    @Override
    public ClickEnquiredShortlistResponse getEnquiryData(RecentActivityClickRequest request) {

        ClickEnquiredShortlistResponse clickData = new ClickEnquiredShortlistResponse();
        List<ActivityResponse> listVo = new ArrayList<>();
        List<ActivityResponse> subListVo = new ArrayList<>();
        Map<String, Object> mapData;

        String typeId = request.getCategoryId();

        List<String> visitorIdList = getVisitorIdList(request.getVisitorId(), request.getPhoneNumber());
        if (!visitorIdList.isEmpty()) {

            mapData = getCategoryData(visitorIdList, typeId, Constants.ENQUIRED);
            int pageSize = request.getPageSize() < 0 ? SIZE : request.getPageSize();
            int pageFetchSize = FETCH_SIZE;
            int pageNumber = request.getPageNumber();
            Boolean isLast = Boolean.FALSE;

            if (!mapData.isEmpty()) {

                List<Date> eventTs = (List<Date>) mapData.get(Constants.JSON_KEY_EVENT_TS);
                List<String> idList = (List<String>) mapData.get(Constants.JSON_KEY_ID);
                Object cat = mapData.get(Constants.JSON_KEY_CATEGORYNAME);
                List<String> categoriesList = (ArrayList) cat;

                Slice<EventEnquiredTracking> findAll = eventEnquiredTrackingRepostiory.findByUniqueData(categoriesList, visitorIdList, idList,
                        CassandraPageRequest.first(pageFetchSize));
                int currPage = 1;

                while (findAll.hasNext() && pageFetchSize < pageNumber * pageSize) {
                    findAll = eventEnquiredTrackingRepostiory.findByUniqueData(categoriesList, visitorIdList, idList, findAll.nextPageable());
                    currPage++;
                }
                if (currPage * pageFetchSize > pageNumber * pageSize) {
                    for (EventEnquiredTracking vo : findAll) {
                        listVo.add(new ActivityResponse(vo, DATE_PATTERN));
                    }
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_PATTERN);
                    listVo.sort((a, b) -> LocalDateTime.parse(b.getEventTs(), formatter).compareTo(LocalDateTime.parse(a.getEventTs(), formatter)));
                    subListVo = listVo.subList(pageSize * (pageNumber - 1), pageSize * pageNumber > listVo.size() ? listVo.size() : pageSize * pageNumber);
                    if (pageSize * pageNumber >= listVo.size()) {
                        isLast = Boolean.TRUE;
                    } else {
                        isLast = Boolean.FALSE;
                    }
                }

                clickData.setIsLast(isLast);
                clickData.setPageNumber(request.getPageNumber());
                clickData.setEnquiredData(subListVo);

            }
        }
        return clickData;
    }

    @Override
    public ClickEnquiredShortlistResponse getShortlistedData(RecentActivityClickRequest request) {

        ClickEnquiredShortlistResponse clickData = new ClickEnquiredShortlistResponse();
        List<ActivityResponse> listVo = new ArrayList<>();
        List<ActivityResponse> subListVo = new ArrayList<>();
        Map<String, Object> mapData;
        String typeId = request.getCategoryId();
        List<String> visitorIdList = getVisitorIdList(request.getVisitorId(), request.getPhoneNumber());

        if (!visitorIdList.isEmpty()) {
            mapData = getCategoryData(visitorIdList, typeId, Constants.SHORTLISTED_ADD);
            int pageSize = request.getPageSize() < 0 ? SIZE : request.getPageSize();
            int pageFetchSize = FETCH_SIZE;
            int pageNumber = request.getPageNumber();
            Boolean isLast = Boolean.FALSE;

            if (!mapData.isEmpty()) {

                List<Date> eventTs = (List<Date>) mapData.get(Constants.JSON_KEY_EVENT_TS);
                List<String> idList = (List<String>) mapData.get(Constants.JSON_KEY_ID);
                Object cat = mapData.get(Constants.JSON_KEY_CATEGORYNAME);
                List<String> categoriesList = (ArrayList) cat;

                Slice<EventShortlistedTracking> findAll = eventShortlistedTrackingRepository.findByUniqueData(categoriesList, visitorIdList, idList,
                        CassandraPageRequest.first(pageFetchSize));
                int currPage = 1;

                while (findAll.hasNext() && pageFetchSize < pageNumber * pageSize) {
                    findAll = eventShortlistedTrackingRepository.findByUniqueData(categoriesList, visitorIdList, idList, findAll.nextPageable());
                    currPage++;
                }
                if (currPage * pageFetchSize > pageNumber * pageSize) {
                    for (EventShortlistedTracking vo : findAll) {
                        listVo.add(new ActivityResponse(vo, DATE_PATTERN));
                    }

                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_PATTERN);
                    listVo.sort((a, b) -> LocalDateTime.parse(b.getEventTs(), formatter).compareTo(LocalDateTime.parse(a.getEventTs(), formatter)));

                    subListVo = listVo.subList(pageSize * (pageNumber - 1), pageSize * pageNumber > listVo.size() ? listVo.size() : pageSize * pageNumber);
                    if (pageSize * pageNumber >= listVo.size()) {
                        isLast = Boolean.TRUE;
                    } else {
                        isLast = Boolean.FALSE;
                    }

                }
                clickData.setIsLast(isLast);
                clickData.setPageNumber(request.getPageNumber());
                clickData.setShortlistedData(subListVo);
            }
        }
        return clickData;
    }

    @Override
    public ClickEnquiredShortlistResponse getSearchedData(RecentActivityClickRequest request) {

        List<String> categories = new ArrayList<>();
        ClickEnquiredShortlistResponse clickData = new ClickEnquiredShortlistResponse();
        List<SeaarchResponse> listVo = new ArrayList<>();
        List<SeaarchResponse> subListVo = new ArrayList<>();
        List<RecentEventSearchTracking> voList = new ArrayList<>();
        Map<String, Object> mapData = new HashMap<>();
        String typeId = request.getCategoryId();
        List<String> visitorIdList = getVisitorIdList(request.getVisitorId(), request.getPhoneNumber());
        if (!visitorIdList.isEmpty()) {
            List<String> cityList = getCityList(visitorIdList);
            if (!cityList.isEmpty()) {
                if (!Strings.isNullOrEmpty(typeId)) {
                    Optional<Taxonomy> taxonomyVoOpt = taxonomyRepository.findById(Integer.parseInt(typeId));
                    if (!taxonomyVoOpt.isPresent()) {
                        return clickData;
                    }
                    Taxonomy taxonomyVo = taxonomyVoOpt.get();
                    categories.add(taxonomyVo.getCategoryName());
                    voList = recentEventSearchTrackingRepository.findByRecentEventSearchTrackingKeyCategoryNameInAndRecentEventSearchTrackingKeyVisitorIdInAndRecentEventSearchTrackingKeyCityIn(categories, visitorIdList, cityList);

                    if (voList != null) {
                        mapData = getSearchIdAndEventTs(voList);
                    }
                } else {
                    categories = getCategories();
                    voList = recentEventSearchTrackingRepository.findByRecentEventSearchTrackingKeyCategoryNameInAndRecentEventSearchTrackingKeyVisitorIdInAndRecentEventSearchTrackingKeyCityIn(categories, visitorIdList, cityList);
                    if (voList != null) {
                        mapData = getSearchIdAndEventTs(voList);
                    }
                }

                int pageSize = request.getPageSize() < 0 ? SIZE : request.getPageSize();
                int pageFetchSize = FETCH_SIZE;
                int pageNumber = request.getPageNumber();
                Boolean isLast = Boolean.FALSE;

                if (!mapData.isEmpty()) {

                    List<Date> eventTs = (List<Date>) mapData.get(Constants.JSON_KEY_EVENT_TS);
                    List<String> searchId = (List<String>) mapData.get(Constants.JSON_KEY_SEARCHID);
                    Slice<EventSearchTracking> findAll = eventSearchTrackingRepository.findByUniqueData(categories, visitorIdList, cityList, searchId,
                            CassandraPageRequest.first(pageFetchSize));
                    int currPage = 1;

                    while (findAll.hasNext() && pageFetchSize < pageNumber * pageSize) {
                        findAll = eventSearchTrackingRepository.findByUniqueData(categories, visitorIdList, cityList, searchId, findAll.nextPageable());
                        currPage++;
                    }

                    if (currPage * pageFetchSize > pageNumber * pageSize) {
                        for (EventSearchTracking vo : findAll) {
                            listVo.add(new SeaarchResponse(vo, DATE_PATTERN));
                        }

                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_PATTERN);
                        listVo.sort((a, b) -> LocalDateTime.parse(b.getEventTs(), formatter).compareTo(LocalDateTime.parse(a.getEventTs(), formatter)));
                        subListVo = listVo.subList(pageSize * (pageNumber - 1), pageSize * pageNumber > listVo.size() ? listVo.size() : pageSize * pageNumber);

                        if (pageSize * pageNumber >= listVo.size()) {
                            isLast = Boolean.TRUE;
                        } else {
                            isLast = Boolean.FALSE;
                        }
                    }

                    clickData.setIsLast(isLast);
                    clickData.setPageNumber(request.getPageNumber());
                    clickData.setSearchData(subListVo);
                }
            }
        }
        return clickData;
    }

    private Map<String, Object> getSearchIdAndEventTs(List<RecentEventSearchTracking> voList) {

        Map<String, Object> data = new HashMap<>();

        List<String> searchId = new ArrayList<>();
        List<Date> eventTs = new ArrayList<>();

        for (RecentEventSearchTracking vo : voList) {

            searchId.add(vo.getSearchId());
            eventTs.add(vo.getEventTs());
        }

        data.put(Constants.JSON_KEY_SEARCHID, searchId);
        data.put(Constants.JSON_KEY_EVENT_TS, eventTs);
        return data;
    }

    @Override
    public Map<Object, Object> getTopSearchedData(RecentActivitySearchRequest request) {

        List<String> categories = new ArrayList<>();

        Map<Object, Object> clickData = new HashMap<>();
        List<SeaarchResponse> listVo = new ArrayList<>();
        List<String> cityList = new ArrayList<>();

        String typeId = request.getCategoryId();

        if (!Strings.isNullOrEmpty(typeId)) {
            Optional<Taxonomy> taxonomyVoOpt = taxonomyRepository.findById(Integer.parseInt(typeId));
            if (!taxonomyVoOpt.isPresent()) {
                return clickData;
            }
            Taxonomy taxonomyVo = taxonomyVoOpt.get();
            categories.add(taxonomyVo.getCategoryName());
        } else {
            categories = getCategories();
        }
        List<String> visitorIdList = getVisitorIdList(request.getVisitorId(), request.getPhoneNumber());

        if (!Strings.isNullOrEmpty(request.getCity())) {
            cityList.add(request.getCity());
        } else {
            cityList = getCityList(visitorIdList);

        }
        if (!visitorIdList.isEmpty() && !cityList.isEmpty()) {

            List<EventSearchTracking> findAll = eventSearchTrackingRepository.findByEventSearchTrackingKeyCategoryNameInAndEventSearchTrackingKeyVisitorIdInAndEventSearchTrackingKeyCityIn(categories, visitorIdList, cityList);
            Map<String, EventSearchTracking> resultMap = new HashMap<>();

            for (EventSearchTracking vo : findAll) {
                if (resultMap.size() == SEARCH_LIMIT) {
                    break;
                }
                if (!resultMap.containsKey(vo.getSuggestedKeyword()) && resultMap.size() < SEARCH_LIMIT && isValidKeyword(vo.getSuggestedKeyword(), vo.getSearchUrl())) {
                    resultMap.put(vo.getSuggestedKeyword(), vo);
                    listVo.add(new SeaarchResponse(vo, DATE_PATTERN));
                }
            }

        }
        clickData.put("topSearchedData", listVo);
        return clickData;

    }

    Map<String, Object> getCategoryData(List<String> visitorIdList, String typeId, String eventType) {

        List<String> categories = new ArrayList<>();

        List<RecentEventTracking> voList;
        Map<String, Object> mapData = new HashMap<>();
        if (!Strings.isNullOrEmpty(typeId)) {
            Optional<Taxonomy> taxonomyVoOpt = taxonomyRepository.findById(Integer.parseInt(typeId));
            if (!taxonomyVoOpt.isPresent()) {
                return mapData;
            }
            Taxonomy taxonomyVo = taxonomyVoOpt.get();
            categories.add(taxonomyVo.getCategoryName());
        } else {
            categories = getCategories();
        }
        voList = recentEventTrackingRepository.findByRecentEventTrackingKeyEventTypeAndRecentEventTrackingKeyCategoryNameInAndRecentEventTrackingKeyVisitorIdIn(eventType, categories, visitorIdList);
        if (voList != null) {
            mapData = getIdAndEventTs(voList);
            mapData.put(Constants.JSON_KEY_CATEGORYNAME, categories);
        }

        return mapData;
    }

    private Map<String, Object> getIdAndEventTs(List<RecentEventTracking> voList) {

        Map<String, Object> data = new HashMap<>();

        List<String> id = new ArrayList<>();
        List<Date> eventTs = new ArrayList<>();

        for (RecentEventTracking vo : voList) {

            id.add(vo.getId());
            eventTs.add(vo.getEventTs());
        }

        data.put(Constants.JSON_KEY_ID, id);
        data.put(Constants.JSON_KEY_EVENT_TS, eventTs);
        return data;
    }

    private List<String> getCategories() {

        List<String> categories = new ArrayList<>();
        for (Types.CATEGORIES vo : Types.CATEGORIES.values()) {
            categories.add(vo.getCategoryType());
        }

        return categories;
    }

    private List<String> getVisitorIdList(String visitorId, String phone) {

        Set<String> visitorIdList = new HashSet<>();

        if (!Strings.isNullOrEmpty(phone)) {

            String phoneNumber = phone;
            phoneNumber = phoneNumber.trim();
            phoneNumber = phoneNumber.replaceAll("\\s+", " ");

            visitorIdList.addAll(enquiryDetailsCustomRepository.findEnquiryByPhoneNumber(phoneNumber).stream().map(EnquiryDetailsCustom::getVisitorId).collect(Collectors.toSet()));
            visitorIdList.addAll(enquiryDetailsCustomRepository.findLoginByPhoneNumber(phoneNumber).stream().map(EnquiryDetailsCustom::getVisitorId).collect(Collectors.toSet()));

        }
        if (visitorIdList.isEmpty() && !Strings.isNullOrEmpty(visitorId)) {
            visitorIdList.add(visitorId);
        }
        return visitorIdList.stream().toList();
    }

    private List<String> getCityList(List<String> visitorId) {

        List<String> cities = new ArrayList<>();

        List<VisitedCities> voList = visitedCitiesRepository.findCitiesByVisitorId(visitorId);

        for (VisitedCities vo : voList) {
            cities.addAll(vo.getCities());
        }
        return cities;
    }

    @Override
    public boolean isValidKeyword(String searchKeyword, String url) {

        boolean isValidUrl = false;
        boolean isValidSearchKeyword = !Strings.isNullOrEmpty(searchKeyword);
        if (isValidSearchKeyword) {
            isValidSearchKeyword = !IGNORE_KEYWORDS.contains(searchKeyword.toLowerCase());
        }
        try {
            if (!Strings.isNullOrEmpty(url) && url.contains(DOMAIN)) {
                if (url.split("\\?", 2).length == 2) {
                    String query = url.split("\\?")[1];
                    List<NameValuePair> parse = URLEncodedUtils.parse(query, Charset.defaultCharset());
                    isValidUrl = !parse.stream().anyMatch(e -> "q".equalsIgnoreCase(e.getName()) && !Strings.isNullOrEmpty(e.getValue()));
                } else {
                    isValidUrl = true;
                }
            }
        } catch (Exception e) {
            log.error(this.getClass().getName(), "failed to validate Url " + url, e);
        }
        return isValidUrl && isValidSearchKeyword;
    }
}
