package com.realestate.squareyards.config.logger;

import com.realestate.squareyards.utils.GsonParserUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Service
@Slf4j
public class LoggingService {

    public void logRequest(HttpServletRequest httpServletRequest, Object body) {
        try {
            if (httpServletRequest.getRequestURI().contains("medias")) {
                return;
            }
            StringBuilder data = new StringBuilder();
            data.append("Request URL :" + httpServletRequest.getRequestURI())
                    .append(" Ip :" + httpServletRequest.getRemoteAddr() + " / " + httpServletRequest.getHeader("X-FORWARDED-FOR"))
                    .append(" Request: ")
                    .append(GsonParserUtils.parseObjectToString(body)).append("\n");
            log.info(data.toString());
        } catch (Exception e) {

        }
    }

    public void logResponse(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object body) {
        try {
            if (httpServletRequest.getRequestURI().contains("medias")) {
                return;
            }
            StringBuilder data = new StringBuilder();
            data.append("Response Body:")
                    .append(" Ip :" + httpServletRequest.getRemoteAddr() + " / " + httpServletRequest.getHeader("X-FORWARDED-FOR"))
                    .append(" Response: ")
                    .append(GsonParserUtils.parseObjectToString(body)).append("\n");

            log.info(data.toString());
        } catch (Exception e) {

        }
    }
}
