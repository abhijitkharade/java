package com.realestate.squareyards.models.request.dealgenie;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.realestate.squareyards.utils.Types;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Map;

@Data
public class DGEditRequirement {

    @NotNull
    @ApiModelProperty(example = "agent-123", required = true)
    @JsonProperty("agent_id")
    private String agentId;

    @NotNull
    @ApiModelProperty(example = "ID1234", required = true)
    @JsonProperty("requirement_id")
    private String requirementId;

    @ApiModelProperty(example = "requirement_name", required = false)
    @JsonProperty("requirement_name")
    private String requirementName;

    @ApiModelProperty(example = "{'city':['mumbai']}", required = false)
    private Map<String, List<Object>> filters;

    @ApiModelProperty(required = false)
    private Types.Statuses status = Types.Statuses.ACTIVE;
}
