package com.realestate.squareyards.models.request.trending_properties;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class TrendingPropertiesSubLocationRequest {

    @NotNull
    @ApiModelProperty(example = "309", required = true)
    private String city;

    @NotNull
    @ApiModelProperty(example = "3", required = true)
    private String categoryId;

    @NotNull
    @ApiModelProperty(example = "42711", required = true)
    private String subLocation;

}
