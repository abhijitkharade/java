package com.realestate.squareyards.controllers;

import com.realestate.squareyards.models.response.ResponseBuilderV1;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

@ApiIgnore
@RestController
public class DefaultController {

    //Controller to check spring service
    @GetMapping(value = "/")
    public @ResponseBody
    ResponseBuilderV1 updateRecords() {

        ResponseBuilderV1 builder = new ResponseBuilderV1();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setResult("Service Running");
        return builder;
    }
}
