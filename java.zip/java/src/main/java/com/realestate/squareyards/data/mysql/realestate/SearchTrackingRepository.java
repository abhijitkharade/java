package com.realestate.squareyards.data.mysql.realestate;

import com.realestate.squareyards.models.table.mysql.SearchTracking;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import javax.annotation.Nullable;
import java.util.List;

public interface SearchTrackingRepository extends CrudRepository<SearchTracking, Integer> {
    @Nullable
    @Query(value = "select * from (select search_id,visit_id,typed_keyword,suggested_keyword,city, " + " event_ts,created_ts,category_name,filter_id,search_url, "
            + " rank() over (partition by category_name order by event_ts desc ,search_id desc) as rnk from "
            + " (select * from (select search_id,visit_id,typed_keyword,suggested_keyword,city,event_ts,created_ts, " + " category_name,filter_id,search_url, "
            + " rank() over (partition by category_name,suggested_keyword order by event_ts desc ,search_id desc) as rowno "
            + " from search_tracking where suggested_keyword is not null and visit_id in ?2 ) as t " + " where rowno = 1 ) as t1 "
            + " where suggested_keyword is not null  and visit_id in ?2 ) as t2 " + " where rnk <=?1 order by category_name,event_ts desc", nativeQuery = true)
    List<SearchTracking> findSearchedByVisitIdIn(Integer limit, List<String> visitId);

    @Nullable
    @Query(value = "select city,suggested_keyword,category_name,search_url_last, count(1) as cnt from "
            + "	(select *, first_value(search_url) over (partition by city,suggested_keyword,category_name order by event_ts desc) as search_url_last "
            + " from search_tracking where suggested_keyword is not null and " + " event_ts BETWEEN NOW() - INTERVAL ?2 DAY AND NOW() and city = ?3 and "
            + " category_name = ?4  ) as t " + " group by city,suggested_keyword,search_url_last order by cnt desc limit ?1", nativeQuery = true)
    List<Object[]> findAllByLocation(Integer limit, Integer trending_interval, String location, String categoryName);

}
