package com.realestate.squareyards.data.mysql.realestate;

import com.realestate.squareyards.models.table.mysql.EventTracking;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import javax.annotation.Nullable;
import java.util.List;

public interface EventTrackingRepository extends CrudRepository<EventTracking, Integer> {

    @Nullable
    @Query(value = "SELECT count(1) as count ,e.category_name, e.event_type, case when e.product_id is null then 'project' else 'unit' end as click_type FROM event_tracking AS e left JOIN product_details AS p ON e.product_id = p.product_id	left join product_variant AS v ON e.product_id = v.product_id where event_ts BETWEEN NOW() - INTERVAL ?1 day AND NOW() group by e.category_name, e.event_type,case when e.product_id is null then 'project' else 'unit' end", nativeQuery = true)
    List<Object[]> readTrackingRecords(Integer interval);

    @Nullable
    @Query(value = "SELECT count(e.product_id) as count ,e.category_name FROM event_tracking AS e INNER JOIN product_details AS p ON e.product_id = p.product_id inner join product_variant AS v ON e.product_id = v.product_id where event_ts BETWEEN NOW() - INTERVAL ?1 day AND NOW() and e.event_type in ('shortlisted','enquired') group by e.category_name", nativeQuery = true)
    List<Object[]> readTrendingRecords(Integer interval);

    @Nullable
    @Query(value = "SELECT e.group_id as project_id,e.product_id as unit_id, category_name, click_type,  "
            + "date_format(e.event_ts,'%Y-%m-%d') as event_ts, page_type, COUNT(event_ts)  as `Count(Shortlisted+Enquired)` FROM event_tracking as e   "
            + "WHERE e.event_ts BETWEEN DATE(NOW()) - INTERVAL ?1 DAY AND DATE(NOW()) and event_type in ('shortlisted','enquired')   " + "and category_name = ?2 "
            + "GROUP BY  category_name ,e.group_id,e.product_id,click_type,date_format(e.event_ts,'%Y-%m-%d') , page_type "
            + "HAVING `Count(Shortlisted+Enquired)` > 0 ;", nativeQuery = true)
    List<Object[]> readTrendingRecordsByCategory(Integer interval, String categoryName);

    @Nullable
    @Query(value = "select agent_id, agent_name,group_id as project_id,product_id as unit_id,category_name,event_ts, page_type, sum(if(event_type='click',cnt,null)) as click,  "
            + "sum(if(event_type='enquired',cnt,null)) as enquired, group_concat(if(event_type='shortlisted',cnt,null)) as shortlisted  from    "
            + "(SELECT agent_id, agent_name,e.product_id,e.group_id, category_name,event_type, "
            + "date_format(e.event_ts,'%Y-%m-%d') as event_ts,page_type, COUNT(event_ts) AS cnt FROM  "
            + "event_tracking as e WHERE e.event_ts BETWEEN DATE(NOW()) - INTERVAL ?1 DAY AND DATE(NOW())  and category_name = ?2 "
            + "GROUP BY agent_id, agent_name,event_type , category_name ,e.product_id,e.group_id,date_format(e.event_ts,'%Y-%m-%d') ,page_type HAVING cnt > 0 ) as e  "
            + "GROUP BY agent_id, agent_name,group_id,product_id,category_name,event_ts ,page_type  ", nativeQuery = true)
    List<Object[]> readAgentProperties(Integer interval, String categoryName);

    @Nullable
    @Query(value = "select group_id as agent_id, product_name as agent_name, event_ts,page_type, sum(if(event_type='click',cnt,null)) as click,   "
            + "sum(if(event_type='enquired',cnt,null)) as contact_back from   "
            + "(SELECT product_name,m.sqy_project_id as group_id,e.product_id, e.category_name, click_type,event_type,  "
            + "date_format(e.event_ts,'%Y-%m-%d') as event_ts,page_type, COUNT(event_ts) AS cnt   "
            + "FROM  event_tracking as e   inner join taxonomy as t on e.category_name = t.category_name   "
            + "inner join sqy_unit_id_mapping as m on e.group_id = m.sqy_project_id and t.taxonomy_id = m.taxonomy_id   " + "inner join product_details as d  "
            + "on m.group_id = d.group_id  WHERE e.event_ts BETWEEN DATE(NOW()) - INTERVAL ?1 DAY AND DATE(NOW()) and e.category_name = 'Agents'   "
            + "GROUP BY event_type , e.category_name ,product_name,m.sqy_project_id,e.product_id,click_type,date_format(e.event_ts,'%Y-%m-%d') , page_type HAVING cnt > 0 ) as e   "
            + "GROUP BY group_id,product_name,event_ts, page_type ", nativeQuery = true)
    List<Object[]> readAgentProfiles(Integer interval);

    @Nullable
    @Query(value = "select id, visit_id, product_id, group_id, variant_id, event_type, click_type, created_ts, event_ts, category_name, "
            + " status, search_id, agent_id, agent_name, city, visitor_id, page_type, sub_location_id "
            + " from (select id, visit_id, product_id, group_id, variant_id, event_type, click_type, created_ts, event_ts, "
            + " category_name, status, search_id, agent_id, agent_name, city, visitor_id, page_type, sub_location_id, "
            + " rank() over (partition by event_type order by created_ts,id desc) as row_count from event_tracking "
            + " where event_type in ('click','shortlisted') and visit_id in ?2) as tmp where row_count <= ?1 ", nativeQuery = true)
    List<EventTracking> readTrackingDataVisitorWise(Integer shortlisted_limit, List<String> visitId);

    @Nullable
    @Query(value = "select id, visit_id, product_id, group_id, variant_id, event_type, click_type, created_ts, event_ts, category_name, "
            + " status, search_id, agent_id, agent_name, city, visitor_id, page_type, sub_location_id from event_tracking "
            + "where  visit_id in ?2 and event_type = ?3  and category_name = ?4 "
            + " order by event_ts desc,id desc limit ?1", nativeQuery = true)
    List<EventTracking> readPropertiesActivity(Integer limit, List<String> visitId, String eventType, String categoryType);

    @Nullable
    @Query(value = "select id, visit_id, product_id, group_id, variant_id, event_type, click_type, created_ts, event_ts, category_name, "
            + "status, search_id, agent_id, agent_name, city, visitor_id, page_type, sub_location_id from "
            + " (select id, visit_id, product_id, group_id, variant_id, event_type, click_type, created_ts, event_ts, "
            + "category_name, status, search_id, agent_id, agent_name, city, visitor_id, page_type, sub_location_id , "
            + "rank() over (partition by group_id order by id desc) as r from event_tracking "
            + "where visit_id in ?2 and event_type = ?3   and category_name = ?4  ) d where r = 1 "
            + "order by event_ts desc, id desc limit ?1", nativeQuery = true)
    List<EventTracking> readNewProjectPropertiesActivity(Integer limit, List<String> visitId, String eventType, String categoryType);

    @Nullable
    @Query(value = "select category_name,city,group_id,count from event_counter_trending_property " + " where date(time_interval) = date(date_add(now(),interval - ?4 day)) "
            + " and category_name = ?3 and city = ?2 " + " order by count desc limit ?1", nativeQuery = true)
    List<Object[]> readTrendingProperties(Integer limit, String city, String categoryName, int trendingPropertiesInterval);

    @Nullable
    @Query(value = "select * from (select id,visit_id,product_id,group_id,variant_id,event_type,click_type, "
            + " created_ts,event_ts,category_name,status,search_id,agent_id,agent_name,city, "
            + " rank() over (partition by category_name,event_type order by event_ts desc,id desc) as rnk " + " from "
            + " ( select * from (select id,visit_id,product_id,group_id,variant_id,event_type,click_type,created_ts,event_ts,category_name,"
            + " status,search_id,agent_id,agent_name,city, " + " rank() over (partition by category_name,event_type,group_id order by event_ts desc,id desc ) as rowno "
            + " from event_tracking " + " where  visit_id in ?2 and case when event_type = 'enquired' then status is null or status = 'OTP verified' else true end) as t1 where rowno = 1 and "
            + " event_type in ('click','enquired','shortlisted') and "
            + " category_name in ('New Projects','Rental','Resale','Agents') ) as d " + " where  visit_id in ?2) as t " + " where rnk <=?1 "
            + " order by category_name,event_type,event_ts desc", nativeQuery = true)
    List<EventTracking> readAllPropertiesActivity(Integer limit, List<String> visitId);

    @Nullable
    @Query(value = "select category_name,city,group_id,sub_location_id,count from event_counter_trending_property_sub_location "
            + " where date(time_interval) = date(date_add(now(),interval - ?5 day)) "
            + " and category_name = ?4 and sub_location_id = ?3 and city = ?2 " + " order by count desc limit ?1", nativeQuery = true)
    List<Object[]> readSubLocationTrendingProperties(Integer limit, String city, Integer subLocation, String categoryName, int trendingPropertiesInterval);

}
