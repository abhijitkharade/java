package com.realestate.squareyards.data.redis;

import com.realestate.squareyards.models.table.redis.UserFeatureVectorFv;
import org.springframework.data.repository.CrudRepository;

public interface UserFeatureVectorFvRepository extends CrudRepository<UserFeatureVectorFv, String> {

}
