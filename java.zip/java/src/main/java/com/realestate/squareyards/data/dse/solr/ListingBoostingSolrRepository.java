package com.realestate.squareyards.data.dse.solr;

import com.realestate.squareyards.core.dse.solr.DseExtractor;
import com.realestate.squareyards.core.dse.solr.DseSolrBaseRepository;
import com.realestate.squareyards.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.joda.time.DateTime;
import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Map;

public interface ListingBoostingSolrRepository {
    JSONArray findByFilters(Map<String, String> filters);
}

@Slf4j
@Service
class IListingBoostingSolrRepository extends DseSolrBaseRepository implements ListingBoostingSolrRepository {

    @Autowired
    private DseExtractor extractor;

    @Value("${property.random.frequency:1}")
    private int frequency;

    @Override
    public JSONArray findByFilters(Map<String, String> filters) {
        SolrQuery query = new SolrQuery();
        query.setStart(0);
        query.setRows(8);
        query.setQuery("*:*");
        query.setFields("sqy_project_id");
        addRandomSort(query);
        setAreaQuery(query, filters);
        setPriceQuery(query, filters);
        setFilterQuery(query, filters);
        query.addFilterQuery(String.format("-enquired:\"%s\"", "deactive"));

        //todo - remove filter for all cities
        query.addFilterQuery("cityid:(3 OR 59)");

        QueryResponse response = search(Constants.LISTING_BOOSTING_COLLECTION, query);
        return extractor.extractJsonDoc(response);
    }

    public void setFilterQuery(SolrQuery query, Map<String, String> filters) {
        if (filters != null) {
            filters.forEach((k, v) -> {
                if (v != null && !v.isEmpty())
                    query.addFilterQuery(String.format("%s:(\"%s\")",
                            k, StringUtils.join(v.split(","), "\" OR \"")));
            });
        }
    }

    public void setPriceQuery(SolrQuery query, Map<String, String> filters) {
        Double[] price = {0d, 0d};
        if (filters.containsKey("price")) {
            price[1] = Double.parseDouble(filters.get("price"));
            filters.remove("price");
        }
        if (filters.containsKey("maxPrice")) {
            price[1] = Double.parseDouble(filters.get("maxPrice"));
            filters.remove("maxPrice");

        }
        if (filters.containsKey("minPrice")) {
            price[0] = Double.parseDouble(filters.get("minPrice"));
            filters.remove("minPrice");
        }
        if (price[0] + price[1] > 0) {
            query.addFilterQuery(String.format("price_range:[%f TO %s]", price[0], price[1] == 0 ? "*" : price[1]));
        }
    }

    public void setAreaQuery(SolrQuery query, Map<String, String> filters) {
        Double[] area = {0d, 0d};
        if (filters.containsKey("maxArea")) {
            area[1] = Double.parseDouble(filters.get("maxArea"));
            filters.remove("maxArea");
        }
        if (filters.containsKey("minArea")) {
            area[0] = Double.parseDouble(filters.get("minArea"));
            filters.remove("minArea");
        }
        if (area[0] + area[1] > 0) {
            query.addFilterQuery(String.format("area_range:[%f TO %f]", area[0], area[1]));
        }
    }

    private void addRandomSort(SolrQuery query) {
        int randomSort = new DateTime().getMinuteOfDay() / frequency;
        log.info("Random Sort Number " + randomSort);
        query.addSort("random_" + randomSort, SolrQuery.ORDER.desc);
    }

}
