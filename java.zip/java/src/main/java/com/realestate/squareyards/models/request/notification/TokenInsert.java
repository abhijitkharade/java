package com.realestate.squareyards.models.request.notification;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.realestate.squareyards.utils.Types;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class TokenInsert {

    @NotNull
    @ApiModelProperty(example = "eB5papU2Xdc:APA91bFFvc3dXru1fN5JY8U19oHIpfGhPUx7L", required = true)
    @JsonProperty("token")
    private String Token;

    @NotNull
    @ApiModelProperty(example = "615c1146a1f90240", required = true)
    @JsonProperty("visitor_id")
    private String visitorId;

    @NotNull
    @ApiModelProperty(example = "ACTIVE / DEACTIVE", required = true)
    @JsonProperty("status")
    private Types.Statuses status;

    @ApiModelProperty(example = "Jaideep", required = false)
    @JsonProperty("user_name")
    private String userName;

    @NotNull
    @ApiModelProperty(required = true)
    @JsonProperty("subscription_type")
    private Types.Device subscriptionType;
}
