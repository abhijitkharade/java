package com.realestate.squareyards.utils;

import lombok.extern.slf4j.Slf4j;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.Random;
import java.util.UUID;

@Slf4j
public class Helper {

    public static String generateReqId(String categoryId) {

        int val = (int) new Date().getTime();
        String hexString = Integer.toHexString(val);

        InetAddress ip;
        String ipHex;
        try {
            ip = InetAddress.getLocalHost();
            String[] ipAddress = ip.getHostAddress().split("\\.");
            String lastThreeDigits = ipAddress[ipAddress.length - 1];
            ipHex = Integer.toHexString(Integer.parseInt(lastThreeDigits));
        } catch (UnknownHostException e) {
            log.error("error ", e);
            //todo throw exception
            return null;
        }
        String randomNumber = generateRandomNumber();
        String productId = categoryId + hexString.toUpperCase() + ipHex.toUpperCase() + randomNumber;
        return productId;
    }

    public static String generateRandomNumber() {

        Random rd = new Random();
        int randomNumber = rd.nextInt(999);
        String randomString = Integer.toString(randomNumber);
        if (randomString.length() == 1) {
            return "00" + randomString;
        } else if (randomString.length() == 2) {
            return "0" + randomString;
        } else {
            return randomString;
        }
    }

    public static String getUUId() {

        UUID uuid = UUID.randomUUID();
        return new Date().getTime() + Constants.UUID_DELIMITER + uuid.toString();
    }

}
