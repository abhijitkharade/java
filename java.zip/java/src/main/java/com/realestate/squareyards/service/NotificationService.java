package com.realestate.squareyards.service;

import com.google.common.base.Strings;
import com.realestate.squareyards.core.FirebaseMessagingService;
import com.realestate.squareyards.data.cassandra.realestate.BannerImpressionsClickedRepository;
import com.realestate.squareyards.data.mysql.realestate.PushSubscriptionRepository;
import com.realestate.squareyards.data.mysql.realestate.UserNotificationRepository;
import com.realestate.squareyards.data.mysql.realestate.mysqlJoins.NotificationRepository;
import com.realestate.squareyards.models.Entity.FirebaseNote;
import com.realestate.squareyards.models.request.notification.BannerInappOpenedRequest;
import com.realestate.squareyards.models.request.notification.BannerInappRequest;
import com.realestate.squareyards.models.request.notification.BannerInappUpdateRequest;
import com.realestate.squareyards.models.response.notification.BannerInappResponse;
import com.realestate.squareyards.models.table.cassandra.BannerImpressionsClicked;
import com.realestate.squareyards.models.table.mysql.NotificationCounterKey;
import com.realestate.squareyards.models.table.mysql.PushSubscription;
import com.realestate.squareyards.models.table.mysql.UserNotification;
import com.realestate.squareyards.models.table.mysql.custom.Notification;
import com.realestate.squareyards.utils.Constants;
import com.realestate.squareyards.utils.Types;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public interface NotificationService {

    Boolean sendNotificationBasedOnVisitorId(String device);

    Map<String, Object> readNotificationBannerInapp(BannerInappRequest request);

    Boolean updateNotificationSentBannerInapp(BannerInappUpdateRequest request);

    Boolean incrementNotificationOpened(BannerInappOpenedRequest request);

}

@Slf4j
@Service
class INotificationService implements NotificationService {

    @Autowired
    private UserNotificationRepository userNotificationRepository;

    @Autowired
    private PushSubscriptionRepository pushSubscriptionRepository;

    @Autowired
    private NotificationCounterService notificationCounterService;

    @Autowired
    private FirebaseMessagingService firebaseMessagingService;

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private BannerImpressionsClickedRepository bannerImpressionsClickedRepository;

    @Value("${push.notification.type:push}")
    private String TYPE_PUSH;

    @Value("${push.notification.limit:500}")
    private Integer LIMIT;

    @Value("${notification.types}")
    private String NOTIFICATION_TYPES;

    @Value("${banner.sent.limit}")
    private Integer BANNER_LIMIT;

    @Value("${request.timeout:1000}")
    private int TIMEOUT;

    SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("yyyyMMdd");

    @Override
    public Boolean sendNotificationBasedOnVisitorId(String device) {

        log.info("Sending push notification to " + device);

        List<UserNotification> notificationsList = userNotificationRepository.readPushNotification(TYPE_PUSH, LIMIT, device);
        Map<String, Integer> counterValue = new HashMap<>();
        List<String> qualifiedVisitors = notificationsList.stream().map(push -> push.getUserNotificationKey().getVisitorId()).collect(Collectors.toList());

        Map<String, String> subList = pushSubscriptionRepository.findByVisitorIdInAndSubscriptionType(qualifiedVisitors, device)
                .stream().filter(x -> Types.Statuses.ACTIVE.name().equals(x.getStatus()) && x.getSubscription().containsKey(Constants.TOKEN))
                .collect(Collectors.toMap(PushSubscription::getVisitorid, e -> e.getSubscription().get(Constants.TOKEN)));

        if (notificationsList != null) {
            for (UserNotification userVo : notificationsList) {
                int count = 1;
                String goalIdAndUuid = userVo.getGoalId() + Constants.UNDERSCORE + userVo.getGoalUuid();
                try {
                    String token = subList.getOrDefault(userVo.getUserNotificationKey().getVisitorId(), "");
                    if (!Strings.isNullOrEmpty(token)) {

                        Map<String, String> data = new HashMap<>();
                        data.put(Constants.REDIRECT_URL, userVo.getRedirectUrl());
                        data.put(Constants.COLUMN_GOAL_ID, userVo.getGoalId());
                        data.put(Constants.COLUMN_GOAL_UUID, userVo.getGoalUuid());
                        FirebaseNote note = new FirebaseNote(userVo.getNotificationTitle(),
                                userVo.getMessage(),
                                data,
                                userVo.getImagePath());
                        log.info("Sending notification To " + userVo.getUserNotificationKey().getVisitorId());
                        firebaseMessagingService.sendNotification(note, token);

                        userVo.setNotificationSent(true);
                        userVo.setModifiedTs(new Date());
                        userNotificationRepository.save(userVo);
                        if (counterValue.containsKey(goalIdAndUuid)) {
                            count = Math.addExact(counterValue.get(goalIdAndUuid), count);
                            counterValue.replace(goalIdAndUuid, count);
                        } else {
                            counterValue.put(goalIdAndUuid, count);
                        }
                    } else {
                        updateDeliveryStatus(userVo);
                    }
                } catch (Exception e) {
                    updateDeliveryStatus(userVo);
                    log.error("An error occurred : ", e);
                }
            }
        }
        try {
            for (Map.Entry<String, Integer> vo : counterValue.entrySet()) {

                String[] keyPair = vo.getKey().split(Constants.UNDERSCORE);
                NotificationCounterKey counterKey = new NotificationCounterKey(keyPair[0], keyPair[1]);
                notificationCounterService.update(counterKey, 0L, Long.valueOf(vo.getValue()));
            }
        } catch (Exception e) {
            log.error("An error occurred : ", e);
        }
        return true;
    }

    @Override
    public Map<String, Object> readNotificationBannerInapp(BannerInappRequest request) {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        try {
            Future<Map<String, Object>> futurePriceRange = executorService.submit(() -> getNotificationBannerResponse(request));
            return futurePriceRange.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (Exception e) {
            log.error("error occured ", e.getMessage());
            Map<String, Object> emptyResponse = new HashMap<>();
            for (String type : NOTIFICATION_TYPES.split(",")) {
                if (!TYPE_PUSH.equals(type)) emptyResponse.put(type, new ArrayList<>());
            }
            executorService.shutdown();
            return emptyResponse;
        }
    }

    private Map<String, Object> getNotificationBannerResponse(BannerInappRequest request) {
        Map<String, Object> responseMap = new HashMap<>();
        String[] bannerTypes = NOTIFICATION_TYPES.split(",");
        List<String> bannerList = Arrays.stream(bannerTypes).filter(e -> !TYPE_PUSH.equals(e)).collect(Collectors.toList());
        List<Notification> notificationList = notificationRepository.readBannerInappFromMatomo(request.getVisitorId(), bannerList, BANNER_LIMIT);
        List<String> ids = new ArrayList<>();

        for (String vo : bannerList) {
            String bannerType = vo.trim();
            List<BannerInappResponse> res = new ArrayList<>();
            for (Notification notification : notificationList) {
                if (bannerType.equals(notification.getNotificationType().trim())) {
                    ids.add(notification.getUniqueid());
                    res.add(new BannerInappResponse(notification));
                }
            }
            responseMap.put(bannerType, res);
        }
        notificationRepository.update(request.getVisitorId(), ids);
        return responseMap;
    }

    @Override
    public Boolean updateNotificationSentBannerInapp(BannerInappUpdateRequest request) {

        BannerImpressionsClicked vo = new BannerImpressionsClicked(request, Constants.BANNER_IMPRESSION, DATE_FORMATTER);
        bannerImpressionsClickedRepository.save(vo);

        return true;
    }

    @Override
    public Boolean incrementNotificationOpened(BannerInappOpenedRequest request) {

        BannerImpressionsClicked vo = new BannerImpressionsClicked(request, Constants.BANNER_CLICKED, DATE_FORMATTER);
        bannerImpressionsClickedRepository.save(vo);

        return true;
    }

    private void updateDeliveryStatus(UserNotification userVo) {
        userVo.setDeliveryStatus(true);
        userVo.setModifiedTs(new Date());
        userNotificationRepository.save(userVo);
    }
}
