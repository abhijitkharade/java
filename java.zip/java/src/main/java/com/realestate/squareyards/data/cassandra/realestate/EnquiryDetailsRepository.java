package com.realestate.squareyards.data.cassandra.realestate;

import com.realestate.squareyards.models.table.cassandra.EnquiryDetails;
import com.realestate.squareyards.models.table.cassandra.EnquiryDetailsKey;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import javax.annotation.Nullable;
import java.util.List;

public interface EnquiryDetailsRepository extends CassandraRepository<EnquiryDetails, EnquiryDetailsKey> {

    @Nullable
    @Query(value = "select * from enquiry_details where phone_number = ?0")
    List<EnquiryDetails> findByKeyPhoneNumber(String phoneNumber);

}
