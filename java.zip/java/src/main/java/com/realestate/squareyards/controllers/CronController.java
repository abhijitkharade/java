package com.realestate.squareyards.controllers;

import com.realestate.squareyards.models.response.ResponseBuilderV1;
import com.realestate.squareyards.service.NotificationService;
import com.realestate.squareyards.utils.Routes;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

@ApiIgnore
@RestController
@Api(tags = "Cron")
public class CronController {

    @Autowired
    private NotificationService notificationService;

    @GetMapping(value = Routes.NOTIFICATION + Routes.SEND,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    ResponseBuilderV1<Boolean> sendPushNotification(@PathVariable(name = "device") String device) {

        ResponseBuilderV1 builder = new ResponseBuilderV1();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setResult(notificationService.sendNotificationBasedOnVisitorId(device));
        return builder;
    }
}
