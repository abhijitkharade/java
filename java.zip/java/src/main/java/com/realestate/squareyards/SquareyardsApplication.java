package com.realestate.squareyards;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.cassandra.CassandraDataAutoConfiguration;
import org.springframework.boot.autoconfigure.data.cassandra.CassandraReactiveDataAutoConfiguration;
import org.springframework.boot.autoconfigure.data.elasticsearch.ElasticsearchDataAutoConfiguration;
import org.springframework.context.annotation.PropertySource;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
@PropertySource("file:${firebase.config.path}squareyards_config.properties")
@EnableAutoConfiguration(exclude = {
        CassandraDataAutoConfiguration.class,
        CassandraReactiveDataAutoConfiguration.class,
        ElasticsearchDataAutoConfiguration.class
})
public class SquareyardsApplication {

    public static void main(String[] args) {
        SpringApplication.run(SquareyardsApplication.class, args);
    }

}



