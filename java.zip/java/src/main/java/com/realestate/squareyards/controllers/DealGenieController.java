package com.realestate.squareyards.controllers;

import com.realestate.squareyards.models.request.dealgenie.*;
import com.realestate.squareyards.models.response.ResponseBuilder;
import com.realestate.squareyards.models.response.dealgenie.DGInsertResponse;
import com.realestate.squareyards.models.response.dealgenie.DGReadProperty;
import com.realestate.squareyards.models.response.dealgenie.DGReadRequirementResponse;
import com.realestate.squareyards.service.RequirementsService;
import com.realestate.squareyards.utils.Constants;
import com.realestate.squareyards.utils.Routes;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@Api(tags = "Deal Genie")
@RequestMapping(Routes.OPEN + Routes.DEAL_GENIE)
public class DealGenieController {

    @Autowired
    private RequirementsService requirementsService;

    @PostMapping(value = Routes.REQUIREMENTS + Routes.INSERT,
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    ResponseBuilder<DGInsertResponse> insertRequirements(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable String version,
                                                         @Valid @RequestBody DGInsert request) {

        ResponseBuilder builder = new ResponseBuilder();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setObject(requirementsService.insertRequirement(request));
        return builder;
    }

    @PostMapping(value = Routes.REQUIREMENTS + Routes.READ,
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    ResponseBuilder<DGReadRequirementResponse> readRequirements(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable(name = "version") String version,
                                                                @Valid @RequestBody DGReadRequirement readRequirement) {

        ResponseBuilder builder = new ResponseBuilder();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setObject(requirementsService.readRequirement(readRequirement));
        return builder;
    }

    @PostMapping(value = Routes.REQUIREMENTS + Routes.EDIT,
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    ResponseBuilder<DGInsertResponse> updateRequirements(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable(name = "version") String version,
                                                         @Valid @RequestBody DGEditRequirement request) {

        ResponseBuilder builder = new ResponseBuilder();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setObject(requirementsService.update(request));
        return builder;
    }

    @PostMapping(value = Routes.REQUIREMENTS + Routes.SAVE,
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    ResponseBuilder<Boolean> insertProperty(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable(name = "version") String version,
                                            @Valid @RequestBody DGSaveProperty request) {

        ResponseBuilder builder = new ResponseBuilder();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setObject(requirementsService.saveProperty(request));
        return builder;
    }

    @PostMapping(value = Routes.REQUIREMENTS + Routes.PROPERTIES + Routes.READ,
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    ResponseBuilder<DGReadProperty> getProperty(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable(name = "version") String version,
                                                @Valid @RequestBody DGReadProperties request) {

        ResponseBuilder builder = new ResponseBuilder();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setObject(requirementsService.readPropertyData(request));
        return builder;
    }
}
