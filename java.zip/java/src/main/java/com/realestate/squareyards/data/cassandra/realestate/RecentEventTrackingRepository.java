package com.realestate.squareyards.data.cassandra.realestate;

import com.realestate.squareyards.models.table.cassandra.RecentEventTracking;
import com.realestate.squareyards.models.table.cassandra.RecentEventTrackingKey;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface RecentEventTrackingRepository extends CassandraRepository<RecentEventTracking, RecentEventTrackingKey> {

    long countByRecentEventTrackingKeyEventTypeAndRecentEventTrackingKeyCategoryNameInAndRecentEventTrackingKeyVisitorIdIn(String eventType, List<String> categories,
                                                                                                                           List<String> visitorId);

    List<RecentEventTracking> findByRecentEventTrackingKeyEventTypeAndRecentEventTrackingKeyCategoryNameInAndRecentEventTrackingKeyVisitorIdIn(String eventType,
                                                                                                                                               List<String> categories, List<String> visitorId);
}
