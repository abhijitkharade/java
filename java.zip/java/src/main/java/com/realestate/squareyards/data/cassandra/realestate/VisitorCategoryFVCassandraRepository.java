package com.realestate.squareyards.data.cassandra.realestate;

import com.realestate.squareyards.data.cassandra.realestate.custom.VisitorCategoryFVCassandraRepositoryCustom;
import com.realestate.squareyards.models.table.cassandra.VisitorCategoryFVCassandra;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface VisitorCategoryFVCassandraRepository extends CassandraRepository<VisitorCategoryFVCassandra, String>, VisitorCategoryFVCassandraRepositoryCustom {

}