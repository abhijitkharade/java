package com.realestate.squareyards.data.mysql.realestate.mysqlJoins;

import com.realestate.squareyards.models.table.mysql.custom.Notification;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Nullable;
import java.util.List;

public interface NotificationRepository extends CrudRepository<Notification, Integer> {

//    @Nullable
//    @Query(value = "select * ,row_number() over(partition by notification_type order by  priority asc)as rn  from(SELECT idvisit, priority , idsite,  LPAD(CONV(HEX(idvisitor), 16, 16),16,0) AS visitor_id, idgoal, redirect_url, image_path , goal_uuid , notification_text , notification_title , placeholder ,banner_type as placement_type ,notification_type FROM  matomo.matomo_log_conversion Inner Join realestate_squareyards.goal_master On goal_id = idgoal WHERE  LPAD(CONV(HEX(idvisitor), 16, 16),16,0) = ?1  and notification_type in ?2 and notification_status = 0 )as n1 limit ?3", nativeQuery = true)
//    List<Notification> readBannerInappFromMatomoList(String visitorId, List<String> notificationType , Integer limit);

    @Nullable
    @Query(value = "select * from ( select uniqueid,goal_site_id, visit_id, priority, visitor_id, goal_id, redirect_url, image_path, goal_uuid,   notification_text, notification_title, placeholder, created_ts, placement_type, notification_type, rnk, ROW_NUMBER() over (PARTITION by visitor_id , notification_type order by created_ts desc ) as rnk1 from ( SELECT DISTINCT un.id as uniqueid, un.visit_id , gm.goal_site_id, gm.priority, un.visitor_id , un.goal_id , gm.redirect_url, gm.image_path , gm.goal_uuid , gm.notification_text , gm.notification_title , gm.placeholder  , un.created_ts, gm.banner_type as placement_type, un.notification_type,  ROW_NUMBER() over (PARTITION by un.visitor_id , un.goal_id order by un.created_ts desc ) as rnk FROM realestate_squareyards.goal_master as gm Inner Join realestate_squareyards.user_notification as un on un.goal_id = gm.goal_id WHERE un.visitor_id = ?1 and un.notification_type in ?2 and un.delivery_status = 0 ) as t where rnk = 1 ) as t2 where rnk1 <= ?3", nativeQuery = true)
    List<Notification> readBannerInappFromMatomo(String visitorId, List<String> notificationType, int limit);

    @Modifying
    @Transactional
    @Query(value = "UPDATE realestate_squareyards.user_notification SET delivery_status = 1 WHERE visitor_id = ?1 AND id in ?2", nativeQuery = true)
    void update(String visitorId, List<String> id);
}
