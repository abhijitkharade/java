package com.realestate.squareyards.service.migration;

import com.google.common.base.Strings;
import com.realestate.squareyards.data.cassandra.realestate.TaxonomyRepository;
import com.realestate.squareyards.data.mysql.realestate.*;
import com.realestate.squareyards.models.request.recent_activity.ProductCountRequest;
import com.realestate.squareyards.models.request.recent_activity.RecentActivityRequest;
import com.realestate.squareyards.models.response.recent_activity.ProductCountResponse;
import com.realestate.squareyards.models.table.cassandra.Taxonomy;
import com.realestate.squareyards.models.table.mysql.EventTracking;
import com.realestate.squareyards.models.table.mysql.SearchTracking;
import com.realestate.squareyards.utils.Constants;
import com.realestate.squareyards.utils.Types;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.*;

public interface RecentActivityService {

    Map<String, Object> readRecentActivity(RecentActivityRequest request);

    public Map<Object, ProductCountResponse> readProductCount(ProductCountRequest request);

}

@Slf4j
@Service
class IRecentActivityService implements RecentActivityService {

    @Autowired
    UserLoginInfoRepository userLoginInfoRepository;

    @Autowired
    EnquiryDetailsMysqlRepository enquiryDetailsRepository;

    @Autowired
    UserDataRepository userDataRepository;

    @Autowired
    SearchTrackingRepository searchTrackingRepository;

    @Autowired
    EventTrackingRepository eventTrackingRepository;

    @Autowired
    TaxonomyRepository taxonomyRepository;

    @Autowired
    EventCounterIntervalRepository eventCounterIntervalRepository;

    @Value("${piwik.search.limit:5}")
    private Integer PIWIK_SEARCH_LIMIT;

    @Value("${piwik.shortlisted.activity.limit:5}")
    private Integer SHORTLIST_ACTIVITY_LIMIT;

    @Value("${piwik.ignore.trending.keywords}")
    private List<String> IGNORE_KEYWORDS;

    @Value("${sy.domain.name}")
    private String DOMAIN;
    private static final String NEW_PROJECTS = "New Projects";
    private static final String RENTAL = "Rental";
    private static final String RESALE = "Resale";
    private static final String AGENTS = "Agents";

    @Value("${piwik.events.list}")
    private String[] eventsToTrackArray;

    @Override
    public Map<String, Object> readRecentActivity(RecentActivityRequest request) {

        Map<String, Object> responseMap = new LinkedHashMap<>();
        String visitorId = request.getVisitorId();
        String phoneNumber = request.getPhoneNumber();
        if (!Strings.isNullOrEmpty(phoneNumber)) {
            try {
                phoneNumber = phoneNumber.trim();
                phoneNumber = phoneNumber.replaceAll("\\s+", " ");
                List<String> visitorIds = userLoginInfoRepository.findVisitorIdByPhoneNumber(phoneNumber);
                List<String> visitorIds_enquiry_details = enquiryDetailsRepository.findVisitorId(phoneNumber);
                visitorIds.addAll(visitorIds_enquiry_details);
                if (visitorIds.isEmpty() && !Strings.isNullOrEmpty(visitorId)) {
                    visitorIds.add(visitorId);
                }
                if (visitorIds != null) {
                    List<String> visitIds = userDataRepository.readVisitIds(visitorIds);
                    if (visitIds != null) {
                        responseMap.put("searches", readSearchedKeywordsActivity(visitIds));
                        responseMap.put("views", getCategoriesMysql());
                        responseMap.put("shortlisted", getCategoriesMysql());
                        responseMap.put("enquired", getCategoriesMysql());
                        readPropertiesActivity(responseMap, visitIds);
                        return responseMap;
                    }
                }
            } catch (Exception e) {
                log.error("invalid visitor id", e.toString());
                throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, " Something went wrong", e);
            }
        } else if (!Strings.isNullOrEmpty(visitorId)) {
            try {
                List<String> visitorIds = new ArrayList<>();
                visitorIds.add(visitorId);
                List<String> visitIds = userDataRepository.readVisitIds(visitorIds);
                responseMap.put("searches", readSearchedKeywordsActivity(visitIds));
                responseMap.put("views", getCategoriesMysql());
                responseMap.put("shortlisted", getCategoriesMysql());
                responseMap.put("enquired", getCategoriesMysql());
                readPropertiesActivity(responseMap, visitIds);
                return responseMap;
            } catch (Exception e) {
                log.error("invalid visitor id", e.toString());
                throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, " Something went wrong", e);
            }
        }
        return Collections.emptyMap();
    }

    @Override
    public Map<Object, ProductCountResponse> readProductCount(ProductCountRequest request) {
        String typeId = request.getCategoryId();
        if (!Strings.isNullOrEmpty(typeId)) {
            typeId = typeId.trim();
            typeId = typeId.replaceAll("\\s+", " ");
            Optional<Taxonomy> taxonomyVoOpt = taxonomyRepository.findById(Integer.parseInt(typeId));
            if (!taxonomyVoOpt.isPresent()) {
                return Collections.emptyMap();
            } else {
                Taxonomy taxonomyVo = taxonomyVoOpt.get();
                String categoryName = taxonomyVo.getCategoryName().replaceAll("\\s+", " ");
                if (Integer.valueOf(1).equals(taxonomyVo.getTaxonomyId())) {
                    String projectId = request.getProjectId();
                    String unitId = request.getUnitId();
                    if (!Strings.isNullOrEmpty(projectId)) {
                        return countMap(projectId, eventCounterIntervalRepository.countByGroupId(categoryName, projectId, Arrays.stream(eventsToTrackArray).toList()));
                    } else if (!Strings.isNullOrEmpty(unitId)) {
                        return countMap(unitId, eventCounterIntervalRepository.countByProductId(categoryName, unitId, Arrays.stream(eventsToTrackArray).toList()));
                    } else {
                        log.error(this.getClass().getName(), "either projectId or unit Id is required for this category");
                        throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, " Parameters missing");
                    }
                } else if (Integer.valueOf(2).equals(taxonomyVo.getTaxonomyId()) || Integer.valueOf(3).equals(taxonomyVo.getTaxonomyId())) {
                    String propertyId = request.getPropertyId();
                    if (!Strings.isNullOrEmpty(propertyId)) {
                        return countMap(propertyId, eventCounterIntervalRepository.countByProductId(categoryName, propertyId, Arrays.stream(eventsToTrackArray).toList()));
                    } else {
                        log.error(this.getClass().getName(), "property Id is required for this category");
                        throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, " Parameters missing");
                    }
                } else if (Integer.valueOf(4).equals(taxonomyVo.getTaxonomyId())) {
                    String userId = request.getUserId();

                    if (!Strings.isNullOrEmpty(userId)) {
                        return countMap(userId, eventCounterIntervalRepository.countByProductId(categoryName, userId, Arrays.stream(eventsToTrackArray).toList()));
                    } else {
                        log.error(this.getClass().getName(), "user Id is required for this category");
                        throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, " Parameters missing");
                    }
                } else {
                    log.error(this.getClass().getName(), "user Id is required for this category");
                    throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, " Parameters missing");
                }
            }
        }
        return Collections.emptyMap();

    }

    public Map<String, List<Map<String, String>>> readSearchedKeywordsActivity(List<String> visitIds) {

        Map<String, List<Map<String, String>>> listAllSearchedKeywords = new LinkedHashMap<>();

        try {
            if (visitIds != null) {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                simpleDateFormat.setTimeZone(TimeZone.getTimeZone("IST"));
                List<SearchTracking> searchTracking = searchTrackingRepository.findSearchedByVisitIdIn(PIWIK_SEARCH_LIMIT, visitIds);
                listAllSearchedKeywords.put(NEW_PROJECTS, new ArrayList<>());
                listAllSearchedKeywords.put(RENTAL, new ArrayList<>());
                listAllSearchedKeywords.put(RESALE, new ArrayList<>());
                listAllSearchedKeywords.put(AGENTS, new ArrayList<>());
                if (searchTracking != null) {
                    for (SearchTracking records : searchTracking) {
                        if (isValidKeyword(records.getSuggestedKeyword(), records.getSearchUrl())) {
                            String categoryName = records.getCategoryName();
                            Map<String, String> searchRecords = new LinkedHashMap<>();
                            searchRecords.put(Constants.JSON_KEY_SY_KEYWORD, records.getSuggestedKeyword());
                            searchRecords.put(Constants.JSON_KEY_SEARCH_URL, records.getSearchUrl());
                            searchRecords.put(Constants.JSON_KEY_EVENT_TS, simpleDateFormat.format(records.getEventTs()));
                            listAllSearchedKeywords.get(categoryName).add(searchRecords);
                        }
                    }
                }
            }
            return listAllSearchedKeywords;
        } catch (Exception e) {
            log.error("invalid visitor id", e.toString());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, " Something went wrong", e);
        }
    }

    private boolean isValidKeyword(String searchKeyword, String url) {

        boolean isValidUrl = false;
        boolean isValidSearchKeyword = !Strings.isNullOrEmpty(searchKeyword);
        if (isValidSearchKeyword) {
            isValidSearchKeyword = !IGNORE_KEYWORDS.contains(searchKeyword.toLowerCase());
        }
        try {
            if (!Strings.isNullOrEmpty(url) && url.contains(DOMAIN)) {
                if (url.split("\\?", 2).length == 2) {
                    String query = url.split("\\?")[1];
                    List<NameValuePair> parse = URLEncodedUtils.parse(query, Charset.defaultCharset());
                    isValidUrl = !parse.stream().anyMatch(e -> "q".equalsIgnoreCase(e.getName()) && !Strings.isNullOrEmpty(e.getValue()));
                } else {
                    isValidUrl = true;
                }
            }
        } catch (Exception e) {
            log.error(this.getClass().getName(), "failed to validate Url " + url, e);
        }
        return isValidUrl && isValidSearchKeyword;
    }

    public void readPropertiesActivity(Map<String, Object> properties, List<String> visitIds) {

        try {
            Map<String, Map<String, List<Map<String, String>>>> propertiesActivity = new LinkedHashMap<>();
            // propertiesActivity.putAll((Map<? extends String, ? extends
            // Map<String, List<Map<String, String>>>>) properties);

            if (visitIds != null) {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                simpleDateFormat.setTimeZone(TimeZone.getTimeZone("IST"));
                List<EventTracking> eventTracking = eventTrackingRepository.readAllPropertiesActivity(SHORTLIST_ACTIVITY_LIMIT, visitIds);
                if (eventTracking != null) {
                    for (EventTracking records : eventTracking) {
                        Map<String, String> eventRecords = new LinkedHashMap<>();
                        String categoryName = records.getCategoryName();
                        String eventType = "";
                        if (records.getEventType().equalsIgnoreCase("click")) {
                            eventType = "views";
                        } else {
                            eventType = records.getEventType();
                        }
                        if (records.getCategoryName().equalsIgnoreCase(NEW_PROJECTS)) {
                            eventRecords = readPropertiesNewProjects(records);
                        } else if (records.getCategoryName().equalsIgnoreCase(RENTAL)) {
                            eventRecords = readPropertiesRentalResale(records);
                        } else if (records.getCategoryName().equalsIgnoreCase(RESALE)) {
                            eventRecords = readPropertiesRentalResale(records);
                        } else if (records.getCategoryName().equalsIgnoreCase(AGENTS)) {
                            eventRecords = readPropertiesAgents(records);
                        }
                        ((Map<String, List<Map<String, String>>>) properties.get(eventType)).get(categoryName).add(eventRecords);
                    }
                }
            }

        } catch (Exception e) {
            log.error("invalid visitor id", e.toString());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, " Something went wrong", e);
        }
    }

    public Map<String, String> readPropertiesNewProjects(EventTracking records) {

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("IST"));
        Map<String, String> eventRecords = new LinkedHashMap<>();
        eventRecords.put(Constants.JSON_KEY_SY_UNIT_ID, records.getProductId());
        eventRecords.put(Constants.JSON_KEY_SY_PROJECT_ID, records.getGroupId());
        eventRecords.put(Constants.JSON_KEY_EVENT_TS, simpleDateFormat.format(records.getEventTs()));
        return eventRecords;
    }

    public Map<String, String> readPropertiesRentalResale(EventTracking records) {

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("IST"));
        Map<String, String> eventRecords = new LinkedHashMap<>();
        eventRecords.put(Constants.JSON_KEY_SY_PROPERTY_ID, records.getGroupId());
        eventRecords.put(Constants.JSON_KEY_EVENT_TS, simpleDateFormat.format(records.getEventTs()));
        return eventRecords;
    }

    public Map<String, String> readPropertiesAgents(EventTracking records) {

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("IST"));
        Map<String, String> eventRecords = new LinkedHashMap<>();
        eventRecords.put(Constants.JSON_KEY_SY_AGENT_ID, records.getGroupId());
        eventRecords.put(Constants.JSON_KEY_EVENT_TS, simpleDateFormat.format(records.getEventTs()));
        return eventRecords;
    }

    private Map<String, Object> getCategoriesMysql() {

        Map<String, Object> categories = new LinkedHashMap<>();
        for (Types.CATEGORIES vo : Types.CATEGORIES.values()) {
            categories.put(vo.getCategoryType(), new ArrayList<>());
        }

        return categories;
    }

    private Map<Object, ProductCountResponse> countMap(String id, List<Object[]> values) {

        Map<Object, ProductCountResponse> listData = new HashMap<>();

        if (!values.isEmpty()) {
            for (Object[] vo : values) {
                ProductCountResponse tempMap = new ProductCountResponse();

                tempMap.setId(id);
                tempMap.setRecordCount(vo[2].toString());
                listData.put(vo[1], tempMap);
            }
            return listData;
        }
        return Collections.emptyMap();
    }

}