package com.realestate.squareyards.models.table.cassandra;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import java.util.List;

@Table(Constants.VISITED_CITIES_TABLE)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class VisitedCities {

    @PrimaryKey(Constants.COLUMN_VISITOR_ID)
    private String visitorId;

    @Column(Constants.COLUMN_CITIES)
    private List<String> cities;
}
