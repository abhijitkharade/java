package com.realestate.squareyards.models.request.recent_activity;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class ProductCountRequest {

    @ApiModelProperty(example = "10457", required = true)
    @JsonProperty("categoryId")
    @NotNull
    private String categoryId;

    @ApiModelProperty(example = "10457", required = true)
    @JsonProperty("projectId")
    private String projectId;

    @ApiModelProperty(example = "10457", required = true)
    @JsonProperty("unitId")
    private String unitId;

    @ApiModelProperty(example = "10457", required = true)
    @JsonProperty("propertyId")
    private String propertyId;

    @ApiModelProperty(example = "10457", required = true)
    @JsonProperty("userId")
    private String userId;
}
