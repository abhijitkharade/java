package com.realestate.squareyards.models.table.cassandra;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table(Constants.USER_LOGIN_INFO_PHONE_NUMBER_VIEW)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserLoginInfoPhoneNumberView {
    @PrimaryKeyColumn(name = Constants.COLUMN_VISITOR_ID, ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String visitorId;

    @Column(Constants.COLUMN_PHONE_NUMBER)
    private String phoneNumber;
}
