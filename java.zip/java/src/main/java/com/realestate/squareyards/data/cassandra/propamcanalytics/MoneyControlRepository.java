package com.realestate.squareyards.data.cassandra.propamcanalytics;

import com.realestate.squareyards.models.table.cassandra.WidgetMaster;
import com.realestate.squareyards.models.table.cassandra.WidgetMasterKey;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import java.util.List;


public interface MoneyControlRepository extends CassandraRepository<WidgetMaster, WidgetMasterKey> {
    @Query( "select * from widget_master where widget=:widget and tab=:tab  and category_name=:categoryName and aggrigation_from=:aggregationFrom  and priority<=:priority ")
    List<WidgetMaster> findTop(String widget,String tab , String  categoryName,String  aggregationFrom,Integer priority);


    @Query("select * from widget_master where city=:city and widget =:widget and tab in ?2 and category_name in ?3 and aggrigation_from in ?4 and priority in ?5 ")
    List<WidgetMaster> findByReq(String city, String widget, List<String> tab, List<String> categoryName, List<String> aggregation, List<Integer> priority);
}
