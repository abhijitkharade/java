package com.realestate.squareyards.utils;

import com.fasterxml.jackson.annotation.JsonFormat;

public class Types {

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    public static enum Statuses {
        ACTIVE,
        DEACTIVE
    }

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    public static enum DEAL_GENIE_STATUS {
        shortlisted,
        not_interested,
        matched
    }

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    public static enum Device {
        ANDROID,
        IOS,
        DESKTOP
    }

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    public static enum BANNER_TYPES {
        push,
        inapp,
        banner,
        STATIC,
        promotional_banner,
        in_listing_banner,
        overlay_banner
    }

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    public static enum CATEGORIES {
        NEW_PROJECTS("New Projects"),
        RESALE("Resale"),
        RENTAL("Rental"),
        AGENTS("Agents");

        private String categoryType;

        public String getCategoryType() {

            return categoryType;
        }

        CATEGORIES(String categoryType) {

            this.categoryType = categoryType;
        }
    }

}

