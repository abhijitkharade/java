package com.realestate.squareyards.service;

import com.realestate.squareyards.data.mysql.realestate.SyFilterDetailsRepository;
import com.realestate.squareyards.models.table.mysql.SyFiltersDetails;
import com.realestate.squareyards.utils.Types;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface SyFilterDetailsService {

    public void saveAll(List<SyFiltersDetails> entity);

    List<SyFiltersDetails> findAllByParentFilterName(String filterName, int categoryId);

    List<SyFiltersDetails> findAllByFilterKey(String filterKey);

    List<SyFiltersDetails> findAllByFilterKey(String filterKey, int categoryId);

    Map<Integer, Map<String, String>> getDisplayLabels();

    List<SyFiltersDetails> findByfilterIds(int categoryId, String cityId, List<String> filterIds, String urlKey);

    List<SyFiltersDetails> findByfilterNames(int categoryId, String cityId, List<String> filterName, String urlKey);

    SyFiltersDetails findFirstByKeyCategoryIdAndKeyFilterName(int categoryId, String filterName);

    List<SyFiltersDetails> findLandmarks(String cityId);

    SyFiltersDetails findByFilterName(String filterName, int categoryId, String filterKey);
}

@Slf4j
@Service
class ISyFilterDetailsService implements SyFilterDetailsService {

    @Autowired
    SyFilterDetailsRepository syFilterDetailsRepository;

    public static final String ERROR_MSG = "  error ";

    @Override
    public List<SyFiltersDetails> findAllByFilterKey(String filterKey) {

        try {
            List<SyFiltersDetails> findAllByFilterKey = syFilterDetailsRepository.findAllByFilterKeyAndStatusAndKeyCityId(filterKey, Types.Statuses.ACTIVE.name(), "0");
            if (findAllByFilterKey != null) {
                return findAllByFilterKey;
            }

        } catch (Exception e) {
            log.error(this.getClass().getName(), ERROR_MSG, e);
        }
        return new ArrayList<>();
    }

    @Override
    public List<SyFiltersDetails> findAllByFilterKey(String filterKey, int categoryId) {

        try {
            List<SyFiltersDetails> findAllByFilterKey = syFilterDetailsRepository.findAllByFilterKeyAndStatusAndKeyCityIdAndKeyCategoryId(filterKey, Types.Statuses.ACTIVE.name(),
                    "0", categoryId);
            if (findAllByFilterKey != null) {
                return findAllByFilterKey;
            }

        } catch (Exception e) {
            log.error(this.getClass().getName(), ERROR_MSG, e);
        }
        return new ArrayList<>();
    }

    @Override
    public List<SyFiltersDetails> findAllByParentFilterName(String filterName, int categoryId) {

        try {
            List<SyFiltersDetails> findAllByFilterKey = syFilterDetailsRepository.findAllByFilterParentNameAndStatusAndKeyCityIdAndKeyCategoryId(filterName,
                    Types.Statuses.ACTIVE.name(), "0", categoryId);
            if (findAllByFilterKey != null) {
                return findAllByFilterKey;
            }

        } catch (Exception e) {
            log.error(this.getClass().getName(), ERROR_MSG, e);
        }
        return new ArrayList<>();
    }

    @Override
    public void saveAll(List<SyFiltersDetails> entity) {

        try {
            syFilterDetailsRepository.saveAll(entity);
        } catch (Exception e) {
            log.error(this.getClass().getName(), ERROR_MSG, e);
        }
    }

    /**
     * @return <category_id, <tattr_filter, label>>
     */
    @Override
    public Map<Integer, Map<String, String>> getDisplayLabels() {

        // label_display_name, category_id, tattr_filter
        Map<Integer, Map<String, String>> returnMap = new HashMap<>();
        List<Object[]> labels = syFilterDetailsRepository.getDisplayLabels();
        for (Object[] obj : labels) {
            if (returnMap.containsKey(obj[1])) {
                returnMap.get(obj[1]).put(obj[2].toString(), obj[0].toString());
            } else {
                Map<String, String> map = new HashMap<>();
                map.put(obj[2].toString(), obj[0].toString());
                returnMap.put((Integer) obj[1], map);
            }
        }
        return returnMap;
    }

    @Override
    public List<SyFiltersDetails> findByfilterIds(int categoryId, String cityId, List<String> filterIds, String urlKey) {

        try {
            return syFilterDetailsRepository.findAllByKeyCategoryIdAndKeyCityIdAndKeyFilterIdInAndUrlKey(categoryId, cityId, filterIds, urlKey);
        } catch (Exception e) {
            log.error(this.getClass().getName(), ERROR_MSG, e);
        }
        return new ArrayList<>();
    }

    @Override
    public List<SyFiltersDetails> findByfilterNames(int categoryId, String cityId, List<String> filterName, String urlKey) {

        try {
            return syFilterDetailsRepository.findAllByKeyCategoryIdAndKeyCityIdAndKeyFilterNameInAndUrlKey(categoryId, cityId, filterName, urlKey);
        } catch (Exception e) {
            log.error(this.getClass().getName(), ERROR_MSG, e);
        }
        return new ArrayList<>();
    }

    @Override
    public SyFiltersDetails findFirstByKeyCategoryIdAndKeyFilterName(int categoryId, String filterName) {

        try {
            return syFilterDetailsRepository.findFirstByKeyCategoryIdAndKeyFilterName(categoryId, filterName);
        } catch (Exception e) {
            log.error(this.getClass().getName(), ERROR_MSG, e);
        }
        return null;
    }

    @Override
    public List<SyFiltersDetails> findLandmarks(String cityId) {

        try {

            List<SyFiltersDetails> findAllByFilterKey = syFilterDetailsRepository.findLandmarks(cityId);
            if (findAllByFilterKey != null) {
                return findAllByFilterKey;
            }

        } catch (Exception e) {
            log.error(this.getClass().getName(), ERROR_MSG, e);
        }
        return new ArrayList<>();
    }

    @Override
    public SyFiltersDetails findByFilterName(String filterName, int categoryId, String filterKey) {

        try {

            return syFilterDetailsRepository.findFirstByKeyFilterNameAndKeyCategoryIdAndFilterKey(filterName, categoryId, filterKey);

        } catch (Exception e) {
            log.error(this.getClass().getName(), ERROR_MSG, e);
        }
        return null;
    }
}
