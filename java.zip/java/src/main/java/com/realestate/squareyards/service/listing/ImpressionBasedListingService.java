package com.realestate.squareyards.service.listing;

import com.google.common.base.Strings;
import com.realestate.squareyards.data.dse.solr.ListingBoostingSolrRepository;
import com.realestate.squareyards.data.elastic.ProjectSrESRepository;
import com.realestate.squareyards.data.elastic.URLElasticRepository;
import com.realestate.squareyards.models.request.ImpressionBasedListingRequest;
import com.realestate.squareyards.models.response.ImpressionBasedResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.nio.charset.Charset;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public interface ImpressionBasedListingService {

    ImpressionBasedResponse getProperties(ImpressionBasedListingRequest request);
}

@Service
@Slf4j
class IImpressionBasedListingService implements ImpressionBasedListingService {

    @Autowired
    private URLElasticRepository urlElasticRepository;

    @Autowired
    private ProjectSrESRepository projectSrESRepository;

    @Autowired
    private ListingBoostingSolrRepository listingBoostingSolrRepository;

    @Value("${domain.name:https://www.squareyards.com/}")
    private String domainName;

    @Value("${url.ignore.filters}")
    private List<String> ignoreFilters;

    @Value("${impression.based.time.out:4}")
    private int timeOut;

    private Map<String, String> filters;

    @Override
    public ImpressionBasedResponse getProperties(ImpressionBasedListingRequest request) {
        long startTime = System.currentTimeMillis();
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Map<String, String> filters = new HashMap<>();
        try {
            Future<ImpressionBasedResponse> future = executorService.submit(() -> getResult(request, startTime, filters));
            return future.get(timeOut, TimeUnit.SECONDS);

        } catch (Exception e) {
            log.error("Error -> ", e);
        } finally {
            executorService.shutdown();
        }
        return new ImpressionBasedResponse(new ArrayList<>(), System.currentTimeMillis() - startTime);
    }

    private ImpressionBasedResponse getResult(ImpressionBasedListingRequest request, long startTime, Map<String, String> filters) {

        extractFilters(request.getListingUrl(), filters);
        isValidPostedByFilter(filters);
        if (!filters.isEmpty()) {
            getCategoryId(filters, request);
            JSONArray array = listingBoostingSolrRepository.findByFilters(filters);
            List<String> propertyIds = new ArrayList<>();

            array.forEach(obj -> {
                JSONObject doc = new JSONObject(obj.toString());
                propertyIds.add(doc.getString("sqy_project_id"));
            });
            log.info("Boosted Ids " + propertyIds);

            if (!propertyIds.isEmpty()) {
                JSONArray docs = projectSrESRepository.findByIds(propertyIds);
                long endTime = System.currentTimeMillis();
                return new ImpressionBasedResponse(docs.toList(), (endTime - startTime));
            }
        }
        return new ImpressionBasedResponse(new ArrayList<>(), (System.currentTimeMillis() - startTime));
    }

    private void isValidPostedByFilter(Map<String, String> filters) {
        if (filters.containsKey("postedBy") && !Arrays.asList(filters.get("postedBy").split(",")).contains("2")) {
            //if postedBy filter not contains agent filter then return empty response
            log.info("Invalid Posted Filter");
            filters.clear();
        }
        filters.remove("postedBy");
    }

    private void extractFilters(String url, Map<String, String> filterMap) {

        Map<String, String> extractedFilters = new HashMap<>();
        if (url.split("\\?", 2).length == 2) {
            String query = url.split("\\?")[1];
            List<NameValuePair> parse = URLEncodedUtils.parse(query, Charset.defaultCharset());

            for (NameValuePair nameValuePair : parse) {
                if (!ignoreFilters.contains(nameValuePair.getName()) && !Strings.isNullOrEmpty(nameValuePair.getValue())) {

                    String filterValue = extractedFilters.getOrDefault(nameValuePair.getName(), "");
                    extractedFilters.put(nameValuePair.getName(),
                            Strings.isNullOrEmpty(filterValue) ?
                                    nameValuePair.getValue() : filterValue + "," + nameValuePair.getValue());
                }
            }
            formatFilterMap(filterMap, extractedFilters, ImpressionBasedUrlFilterMapping.getUrlFilters());
        } else {
            extractedFilters.putAll(urlElasticRepository.getFiltersFromUrl(url.replace(domainName, "")));
            formatFilterMap(filterMap, extractedFilters, ImpressionBasedUrlFilterMapping.getElasticFilters());
        }
        log.info("extracted Filters ->" + filterMap);
    }

    private void formatFilterMap(Map<String, String> filterMap, Map<String, String> extractedFilters, Map<String, String> urlFilters) {
        extractedFilters.keySet().forEach(e -> {
            if (urlFilters.containsKey(e)) {
                filterMap.put(urlFilters.get(e), extractedFilters.get(e));
            }
        });

//        if (urlFilters.keySet().containsAll(extractedFilters.keySet())) {
//            extractedFilters.keySet().forEach(e -> filterMap.put(urlFilters.get(e), extractedFilters.get(e)));
//        } else {
//            log.error("Found Extra Filter Key ", extractedFilters);
//        }
    }

    private void getCategoryId(Map<String, String> extractedFilters, ImpressionBasedListingRequest request) {
        if (extractedFilters.containsKey("listingType")) {
            switch (extractedFilters.get("listingType").toLowerCase()) {
                case "sale":
                    if ("sale".equalsIgnoreCase(request.getListingType())) {
                        extractedFilters.put("category_id", String.valueOf(2));
                        extractedFilters.remove("listingType");
                    }
                    break;
                case "rent":
                    if ("rent".equalsIgnoreCase(request.getListingType())) {
                        extractedFilters.put("category_id", String.valueOf(3));
                        extractedFilters.remove("listingType");
                    }
                    break;
            }
        } else {
            if (request.getListingUrl().contains("resale/") && "sale".equalsIgnoreCase(request.getListingType())) {
                extractedFilters.put("category_id", String.valueOf(2));
            } else if ((request.getListingUrl().contains("rental/") || request.getListingUrl().contains("rent/")) && "rent".equalsIgnoreCase(request.getListingType())) {
                extractedFilters.put("category_id", String.valueOf(3));
            }
        }
        if (!extractedFilters.containsKey("category_id")) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid Listing Type");
        }
    }
}
