package com.realestate.squareyards.controllers;

import com.realestate.squareyards.models.request.notification.BannerInappOpenedRequest;
import com.realestate.squareyards.models.request.notification.BannerInappRequest;
import com.realestate.squareyards.models.request.notification.BannerInappUpdateRequest;
import com.realestate.squareyards.models.request.notification.TokenInsert;
import com.realestate.squareyards.models.response.ResponseBuilderV1;
import com.realestate.squareyards.models.response.notification.BannerResponse;
import com.realestate.squareyards.service.NotificationService;
import com.realestate.squareyards.service.PushSubscriptionService;
import com.realestate.squareyards.utils.Constants;
import com.realestate.squareyards.utils.Routes;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@Api(tags = "Notification")
public class NotificationController {

    @Autowired
    private PushSubscriptionService pushSubscriptionService;

    @Autowired
    private NotificationService notificationService;

    @PostMapping(value = Routes.NOTIFICATION + Routes.TOKEN,
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    ResponseBuilderV1<Boolean> insertToken(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable(name = "version") String version,
                                           @Valid @RequestBody TokenInsert request) {

        ResponseBuilderV1 builder = new ResponseBuilderV1();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setResult(pushSubscriptionService.insertTokenData(request));
        return builder;
    }

    @PostMapping(value = Routes.NOTIFICATION + Routes.NOTIFICATION_MSG,
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    ResponseBuilderV1<BannerResponse> getBannerInappNotification(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable(name = "version") String version,
                                                                 @Valid @RequestBody BannerInappRequest request) {

        ResponseBuilderV1 builder = new ResponseBuilderV1();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setResult(notificationService.readNotificationBannerInapp(request));
        return builder;
    }

    @PostMapping(value = Routes.NOTIFICATION + Routes.UPDATE_NOTIFICATION,
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    ResponseBuilderV1<Boolean> bannerInappNotificationUpdate(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable(name = "version") String version,
                                                             @Valid @RequestBody BannerInappUpdateRequest request) {

        ResponseBuilderV1 builder = new ResponseBuilderV1();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setResult(notificationService.updateNotificationSentBannerInapp(request));
        return builder;

    }

    @PostMapping(value = Routes.NOTIFICATION + Routes.NOTIFICATION_REDIRECT_FLAG,
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    ResponseBuilderV1<Boolean> updateNotificationOpened(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable(name = "version") String version,
                                                        @Valid @RequestBody BannerInappOpenedRequest request) {

        ResponseBuilderV1 builder = new ResponseBuilderV1();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setResult(notificationService.incrementNotificationOpened(request));
        return builder;

    }
}
