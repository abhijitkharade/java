package com.realestate.squareyards.config.solr;

import lombok.extern.slf4j.Slf4j;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.impl.CloudSolrClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.solr.core.SolrTemplate;
import org.springframework.data.solr.repository.config.EnableSolrRepositories;

@Slf4j
@Configuration
@EnableSolrRepositories(basePackages = {"com.realestate.squareyards.data.solr"})
public class SolrConfig {

    @Value("${spring.data.solr.zk-host}")
    private String zkHost;

    @Value("${spring.data.solr.user}")
    private String user;

    @Value("${spring.data.solr.password}")
    private String password;

    @Bean
    public SolrClient solrClient() {

        CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
        credentialsProvider.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials(user, password));
        HttpClient httpSolrClient = HttpClientBuilder.create().setDefaultCredentialsProvider(credentialsProvider).build();
        SolrClient client = new CloudSolrClient.Builder().withZkHost(zkHost).withHttpClient(httpSolrClient).build();
        //SolrClient client = new HttpSolrClient.Builder().withBaseSolrUrl(zkHost).withHttpClient(httpSolrClient).build();
        log.info("Solr connection success..");
        return client;
    }

    @Bean("solrTemplate")
    public SolrTemplate solrTemplate() throws Exception {
        return new SolrTemplate(solrClient());
    }
}
