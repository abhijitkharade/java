package com.realestate.squareyards.models.response.recent_activity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Slf4j
@NoArgsConstructor
public class ClickEnquiredShortlistResponse {

    @ApiModelProperty(example = "true")
    @JsonProperty("isLast")
    Boolean isLast;

    @ApiModelProperty(example = "1")
    @JsonProperty("pageNumber")
    Integer pageNumber;

    @ApiModelProperty(example = "")
    @JsonProperty("clickData")
    List<ActivityResponse> clickData;

    @ApiModelProperty(example = "")
    @JsonProperty("enquiredData")
    List<ActivityResponse> enquiredData;

    @ApiModelProperty(example = "")
    @JsonProperty("shortlistedData")
    List<ActivityResponse> shortlistedData;

    @ApiModelProperty(example = "")
    @JsonProperty("searchData")
    List<SeaarchResponse> searchData;

}
