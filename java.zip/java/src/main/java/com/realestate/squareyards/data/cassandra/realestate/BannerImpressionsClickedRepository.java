package com.realestate.squareyards.data.cassandra.realestate;

import com.realestate.squareyards.models.table.cassandra.BannerImpressionsClicked;
import com.realestate.squareyards.models.table.cassandra.BannerImpressionsClickedKey;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface BannerImpressionsClickedRepository extends CassandraRepository<BannerImpressionsClicked, BannerImpressionsClickedKey> {
}
