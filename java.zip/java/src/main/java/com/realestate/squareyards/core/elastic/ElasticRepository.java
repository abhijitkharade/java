package com.realestate.squareyards.core.elastic;

import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

@NoRepositoryBean
@Slf4j
public abstract class ElasticRepository {

    @Autowired
    @Qualifier("elasticsearchClient")
    protected RestHighLevelClient client;

    protected SearchResponse search(String index, SearchSourceBuilder source) {
        try {
            SearchRequest request = new SearchRequest(index);
            source.timeout(TimeValue.timeValueSeconds(10));
            request.source(source);
            log.info(String.format("Index -> %s : Request -> %s", index, source));
            return client.search(request, RequestOptions.DEFAULT);
        } catch (Exception e) {
            log.error("error in ES ", e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
