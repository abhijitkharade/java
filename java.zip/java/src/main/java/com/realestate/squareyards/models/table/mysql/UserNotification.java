package com.realestate.squareyards.models.table.mysql;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;

@Data
@Entity
@Table(name = Constants.USER_NOTIFICATION_TABLE)
@AllArgsConstructor
@NoArgsConstructor
public class UserNotification {

    @EmbeddedId
    private UserNotificationKey userNotificationKey;

    @Column(name = Constants.COLUMN_EVENT_DATE)
    private String eventDate;

    @Column(name = Constants.COLUMN_GOAL_ID)
    private String goalId;

    @Column(name = Constants.COLUMN_GOAL_UUID)
    private String goalUuid;

    @Column(name = Constants.COLUMN_USER_ID)
    private String userId;

    @Column(name = Constants.COLUMN_MESSAGE)
    private String message;

    @Column(name = Constants.COLUMN_EMAIL_SENT)
    private Boolean emailSent;

    @Column(name = Constants.COLUMN_NOTIFICATION_SENT)
    private Boolean notificationSent;

    @Column(name = Constants.COLUMN_SHORT_MESSAGE)
    private String shortMessage;

    @Column(name = Constants.COLUMN_REDIRECT_URL)
    private String redirectUrl;

    @Column(name = Constants.COLUMN_IMAGEPATH)
    private String imagePath;

    @Column(name = Constants.COLUMN_MODIFIED_TS)
    private Date modifiedTs;

    @Column(name = Constants.COLUMN_CREATED_TS)
    private Date createdTs;

    @Column(name = Constants.COLUMN_TAXONOMY_ID)
    private Integer taxonomyId;

    @Column(name = Constants.COLUMN_NOTIFICATION_TITLE)
    private String notificationTitle;

    @Column(name = Constants.COLUMN_CLICK_COUNT)
    private Integer clickCount;

    @Column(name = Constants.COLUMN_SUBSCRIPTION_TYPE)
    private String subscriptionType;

    @Column(name = Constants.COLUMN_BUTTON)
    private String button;

    @Column(name = Constants.COLUMN_DELIVERY_STATUS)
    private Boolean deliveryStatus;

}
