package com.realestate.squareyards.controllers;

import com.realestate.squareyards.models.request.recent_activity.*;
import com.realestate.squareyards.models.request.similarity.SimilarProductsRequest;
import com.realestate.squareyards.models.request.trending_properties.TrendingPropertiesRequest;
import com.realestate.squareyards.models.request.trending_properties.TrendingPropertiesSubLocationRequest;
import com.realestate.squareyards.models.response.ResponseBuilder;
import com.realestate.squareyards.models.response.ResponseBuilderV1;
import com.realestate.squareyards.models.response.realtime_user_similarity.SimilarProductsResponse;
import com.realestate.squareyards.models.response.recent_activity.ClickEnquiredShortlistResponse;
import com.realestate.squareyards.models.response.recent_activity.CountResponse;
import com.realestate.squareyards.models.response.recent_activity.SeaarchResponse;
import com.realestate.squareyards.models.response.trending_properties.TrendingKeywordsResponse;
import com.realestate.squareyards.models.response.trending_properties.TrendingPropertiesResponse;
import com.realestate.squareyards.service.migration.ActivityDetailsService;
import com.realestate.squareyards.service.migration.RecentActivityService;
import com.realestate.squareyards.service.migration.SimilarityService;
import com.realestate.squareyards.service.migration.TrendingPropertiesService;
import com.realestate.squareyards.utils.Constants;
import com.realestate.squareyards.utils.Routes;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

@RestController
@Api(tags = "Migration Controller")
public class MigrationController {

    public static final String RECENT_ACTIVITY_BASE_URL = Routes.OPEN + "/user";
    public static final String SIMILARITY_BASE_URL = "/details" + Routes.VERSION;
    public static final String TRENDING_PROPERTIES_BASE_URL = Routes.OPEN + "/piwik";

    @Autowired
    private ActivityDetailsService activityDetailsService;

    @Autowired
    private SimilarityService similarityService;

    @Autowired
    private TrendingPropertiesService trendingPropertiesService;

    @Autowired
    private RecentActivityService recentActivityService;

    @PostMapping(value = RECENT_ACTIVITY_BASE_URL + Routes.RECENT_ACTIVITY_COUNT)
    public @ResponseBody
    ResponseBuilderV1<CountResponse> fetchActivityCount(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable(name = "version") String version,
                                                        @Valid @RequestBody RecentActivityCountRequest request) {

        ResponseBuilderV1 builder = new ResponseBuilderV1();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setResult(activityDetailsService.getCount(request));
        return builder;
    }

    @PostMapping(value = RECENT_ACTIVITY_BASE_URL + Routes.CLICK_DATA)
    public @ResponseBody
    ResponseBuilderV1<ClickEnquiredShortlistResponse> fetchClickData(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable(name = "version") String version,
                                                                     @Valid @RequestBody RecentActivityClickRequest request) {

        ResponseBuilderV1 builder = new ResponseBuilderV1();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setResult(activityDetailsService.getClickData(request));
        return builder;
    }

    @PostMapping(value = RECENT_ACTIVITY_BASE_URL + Routes.ENQUIRED_DATA)
    public @ResponseBody
    ResponseBuilderV1<ClickEnquiredShortlistResponse> fetchEnquiredData(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable(name = "version") String version,
                                                                        @Valid @RequestBody RecentActivityClickRequest request) {

        ResponseBuilderV1 builder = new ResponseBuilderV1();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setResult(activityDetailsService.getEnquiryData(request));
        return builder;
    }

    @PostMapping(value = RECENT_ACTIVITY_BASE_URL + Routes.SHORTLISTED_DATA)
    public @ResponseBody
    ResponseBuilderV1<ClickEnquiredShortlistResponse> fetchShortlistedData(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable(name = "version") String version,
                                                                           @Valid @RequestBody RecentActivityClickRequest request) {

        ResponseBuilderV1 builder = new ResponseBuilderV1();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setResult(activityDetailsService.getShortlistedData(request));
        return builder;
    }

    @PostMapping(value = RECENT_ACTIVITY_BASE_URL + Routes.SEARCHED_DATA)
    public @ResponseBody
    ResponseBuilderV1<ClickEnquiredShortlistResponse> fetchSearchedData(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable(name = "version") String version,
                                                                        @Valid @RequestBody RecentActivityClickRequest request) {

        ResponseBuilderV1 builder = new ResponseBuilderV1();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setResult(activityDetailsService.getSearchedData(request));
        return builder;
    }

    @PostMapping(value = RECENT_ACTIVITY_BASE_URL + Routes.TOP_SEARCHED_DATA)
    public @ResponseBody
    ResponseBuilderV1<Map<Object, List<SeaarchResponse>>> fetchTopSearchedData(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable(name = "version") String version,
                                                                               @Valid @RequestBody RecentActivitySearchRequest request) {

        ResponseBuilderV1 builder = new ResponseBuilderV1();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setResult(activityDetailsService.getTopSearchedData(request));
        return builder;
    }

    @PostMapping(value = SIMILARITY_BASE_URL + Routes.SIMILAR_PROJECTS_URL)
    public @ResponseBody
    ResponseBuilder<SimilarProductsResponse> getSimilarProperties(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable(name = "version") String version,
                                                                  @Valid @RequestBody SimilarProductsRequest request) {

        ResponseBuilder builder = new ResponseBuilder();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setObject(similarityService.getSimilarProducts(request));
        return builder;
    }

    @PostMapping(value = TRENDING_PROPERTIES_BASE_URL + Routes.TRENDING_PROPERTIES)
    public @ResponseBody
    ResponseBuilder<TrendingPropertiesResponse> fetchTrendingProperties(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable(name = "version") String version,
                                                                        @Valid @RequestBody TrendingPropertiesRequest request) {
        ResponseBuilder builder = new ResponseBuilder();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setObject(trendingPropertiesService.readTrendingProperties(request));
        return builder;
    }

    @PostMapping(value = SIMILARITY_BASE_URL + Routes.VISITOR_SIMILAR_URL)
    public @ResponseBody
    ResponseBuilder<SimilarProductsResponse> getVisitorSimilarProperties(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable(name = "version") String version,
                                                                         @Valid @RequestBody SimilarProductsRequest request) {

        ResponseBuilder builder = new ResponseBuilder();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setObject(similarityService.getVisitorSimilarity(request));
        return builder;
    }

    @PostMapping(value = TRENDING_PROPERTIES_BASE_URL + Routes.SUB_LOCATION_TRENDING_PROPERTIES)
    public @ResponseBody
    ResponseBuilder<TrendingPropertiesResponse> fetchSubLocationTrendingProperties(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable(name = "version") String version,
                                                                                   @Valid @RequestBody TrendingPropertiesSubLocationRequest request) {

        ResponseBuilder builder = new ResponseBuilder();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setObject(trendingPropertiesService.readSubLocationTrendingProperties(request));
        return builder;
    }

    //    sql based code
    @PostMapping(value = TRENDING_PROPERTIES_BASE_URL + Routes.TRENDING_KEYWORDS)
    public @ResponseBody
    ResponseBuilder<TrendingKeywordsResponse> fetchTrendingKeywords(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable(name = "version") String version,
                                                                    @Valid @RequestBody TrendingPropertiesRequest request) {

        ResponseBuilder builder = new ResponseBuilder();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setObject(trendingPropertiesService.readTrendingKeywords(request));
        return builder;
    }

    //    sql based code
    @PostMapping(value = TRENDING_PROPERTIES_BASE_URL + Routes.RECENT_ACTIVITY)
    public @ResponseBody
    ResponseBuilder<Boolean> fetchRecentActivity(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable(name = "version") String version, @Valid @RequestBody RecentActivityRequest request) {

        ResponseBuilder builder = new ResponseBuilder();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setObject(recentActivityService.readRecentActivity(request));
        return builder;
    }

    //    sql based code
    @PostMapping(value = TRENDING_PROPERTIES_BASE_URL + Routes.PRODUCT_COUNT_DETAILS_URL)
    public @ResponseBody
    ResponseBuilder<Boolean> fetchProductCountDetails(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable(name = "version") String version, @Valid @RequestBody ProductCountRequest request) {

        ResponseBuilder builder = new ResponseBuilder();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setObject(recentActivityService.readProductCount(request));
        return builder;
    }

}

