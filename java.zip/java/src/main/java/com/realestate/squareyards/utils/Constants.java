package com.realestate.squareyards.utils;

public class Constants {

    public static final String CLUSTER_PREFIX = "cluster";
    public static final String ACTIVE = "ACTIVE";
    public static final String TOKEN = "token";
    public static final String UNDERSCORE = "_";
    public static final String REDIRECT_URL = "redirect_url";
    public static final String VERSION_1 = "v1.0";

    //DSE Solr Collection Names
    public static final String LISTING_BOOSTING_COLLECTION = "indexed_data.listing_boosting";

    //Elastic Search Indexes
    public static final String URL_SR_INDEX = "url_sr";
    public static final String PROJECT_SR_INDEX = "project_sr";

    //table names
    public static final String PUSH_SUBSCRIPTION_TABLE = "push_subscription";
    public static final String USER_NOTIFICATION_TABLE = "user_notification";
    public static final String NOTIFICATION_COUNTER_TABLE = "notification_counter";
    public static final String SQY_UNIT_ID_MAPPING_TABLE = "sqy_unit_id_mapping";
    public static final String TEXT_BASED_ITEM_SIMILARITY_FV_TABLE = "text_based_item_similarity_fv";
    public static final String VISITOR_CATEGORY_FV_TAXONOMY_ID_TABLE = "visitor_category_fv_";
    public static final String VISITOR_DATE_VIEW_TABLE = "visitor_data_view";
    public static final String SY_FILTER_DETAILS_TABLE = "sy_filter_details";
    public static final String EVENT_TRACKING_TABLE = "event_tracking";
    public static final String BANNER_IMPRESSIONS_CLICKED_TABLE = "banner_impressions_clicked";
    public static final String RECENT_EVENT_SEARCH_TRACKING_TABLE = "recent_event_search_tracking";
    public static final String VISITED_CITIES_TABLE = "visited_cities";
    public static final String ENQUIRY_DETAILS_TABLE = "enquiry_details";
    public static final String EVENT_CLICK_TRACKING_TABLE = "event_click_tracking";
    public static final String EVENT_SHORTLISTED_TRACKING_TABLE = "event_shortlisted_tracking";
    public static final String EVENT_ENQUIRED_TRACKING_TABLE = "event_enquired_tracking";
    public static final String EVENT_SEARCH_TRACKING_TABLE = "event_search_tracking";
    public static final String TAXONOMY_TABLE = "taxonomy";
    public static final String USER_LOGIN_INFO_PHONE_NUMBER_VIEW = "user_login_info_phone_number";
    public static final String EVENT_COUNTER_TRENDING_PROPERTY_TABLE = "event_counter_trending_property";
    public static final String EVENT_COUNTER_TRENDING_PROPERTY_SUB_LOCATION_TABLE = "event_counter_trending_property_sub_location";
    public static final String USER_LOGIN_INFO_TABLE = "user_login_info";
    public static final String USER_DATA_TABLE = "user_data";
    public static final String SEARCH_TRACKING_TABLE = "search_tracking";
    public static final String EVENT_COUNTER_TIME_INTERVAL_TABLE = "event_counter_time_interval";
    public static final String EVENT_COUNTER_TRENDING_KEYWORDS_TABLE = "event_counter_trending_keywords";

    // Joins names
    public static final String MATOMO_LOG_CONVERSION_JOIN = "matomo_log_conversion";

    //column names

    public static final String COLUMN_SUBSCRIPTION = "subscription";
    public static final String COLUMN_STATUS = "status";
    public static final String COLUMN_VISITOR_ID = "visitor_id";
    public static final String COLUMN_SUBSCRIPTION_TYPE = "subscription_type";
    public static final String COLUMN_USER_NAME = "user_name";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_EVENT_DATE = "event_date";
    public static final String COLUMN_GOAL_ID = "goal_id";
    public static final String COLUMN_GOAL_UUID = "goal_uuid";
    public static final String COLUMN_EMAIL_SENT = "email_sent";
    public static final String COLUMN_NOTIFICATION_SENT = "notification_sent";
    public static final String COLUMN_SHORT_MESSAGE = "short_message";
    public static final String COLUMN_IMAGEPATH = "image_path";
    public static final String COLUMN_REDIRECT_URL = "redirect_url";
    public static final String COLUMN_CREATED_TS = "created_ts";
    public static final String COLUMN_MODIFIED_TS = "modified_ts";
    public static final String COLUMN_NOTIFICATION_TITLE = "notification_title";
    public static final String COLUMN_CLICK_COUNT = "click_count";
    public static final String COLUMN_USER_ID = "user_id";
    public static final String COLUMN_MESSAGE = "message";
    public static final String COLUMN_TAXONOMY_ID = "taxonomy_id";
    public static final String COLUMN_BUTTON = "button";
    public static final String COLUMN_NOTIFICATIONS_SENT = "notifications_sent";
    public static final String COLUMN_NOTIFICATIONS_OPENED = "notifications_opened";
    public static final String COLUMN_DELIVERY_STATUS = "delivery_status";
    public static final String COLUMN_VISIT_ID = "visit_id";
    public static final String COLUMN_ID_SITE = "idsite";
    public static final String COLUMN_IDVISIT = "idvisit";
    public static final String COLUMN_IDGOAL = "idgoal";
    public static final String COLUMN_NOTIFICATION_TEXT = "notification_text";
    public static final String COLUMN_PLACEMENT_TYPE = "placement_type";
    public static final String COLUMN_PLACEHOLDER = "placeholder";
    public static final String COLUMN_PRODUCT_ID = "product_id";
    public static final String COLUMN_GROUP_ID = "group_id";
    public static final String COLUMN_UNIT_ID = "sqy_unit_id";
    public static final String COLUMN_PROJECT_ID = "sqy_project_id";
    public static final String COLUMN_PRODUCT_TYPE = "product_type";
    public static final String COLUMN_VECTOR = "vector";
    public static final String COLUMN_GROUP_ID_CLICK = "group_id_click";
    public static final String COLUMN_PRODUCT_TYPE_VIEW = "product_type_view";
    public static final String COLUMN_USER_TASTE_FV = "user_taste_fv";
    public static final String COLUMN_GROUP_ID_LIST = "group_id_list";
    public static final String COLUMN_CATEGORY_ID = "category_id";
    public static final String COLUMN_FILTER_ID = "filter_id";
    public static final String COLUMN_FILTER_NAME = "filter_name";
    public static final String COLUMN_CITY_ID = "city_id";
    public static final String COLUMN_FILTER_KEY = "filter_key";
    public static final String COLUMN_FILTER_PARENT_ID = "filter_parent_id";
    public static final String COLUMN_FILTER_PARENT_NAME = "filter_parent_Name";
    public static final String COLUMN_FILTER_COUNT = "filter_count";
    public static final String COLUMN_URL_KEY = "url_key";
    public static final String COLUMN_TATTR_FILTER = "tattr_filter";
    public static final String COLUMN_LABEL_DISPLAY_NAME = "label_display_name";
    public static final String COLUMN_VARIANT_ID = "variant_id";
    public static final String COLUMN_EVENT_TYPE = "event_type";
    public static final String COLUMN_CLICK_TYPE = "click_type";
    public static final String COLUMN_EVENT_TS = "event_ts";
    public static final String COLUMN_CATEGORY_NAME = "category_name";
    public static final String COLUMN_SEARCH_ID = "search_id";
    public static final String COLUMN_CITY = "city";
    public static final String COLUMN_SUGGESTED_KEYWORD = "suggested_keyword";
    public static final String COLUMN_CITIES = "cities";
    public static final String COLUMN_PHONE_NUMBER = "phone_number";
    public static final String COLUMN_AGENT_ID = "agent_id";
    public static final String COLUMN_AGENT_NAME = "agent_name";
    public static final String REQUEST_ID = "request_id";
    public static final String COLUMN_ACTION = "action";
    public static final String COLUMN_SEARCH_URL = "search_url";
    public static final String COLUMN_TYPED_KEYWORD = "typed_keyword";
    public static final String COLUMN_PAGE_TYPE = "page_type";
    public static final String COLUMN_EMAIL = "email";
    public static final String COLUMN_COUNT = "count";
    public static final String COLUMN_TIME_INTERVAL = "time_interval";
    public static final String COLUMN_SEARCH_URL_LAST = "search_url_last";
    public static final String COLUMN_WIDGET = "widget";
    public static final String COLUMN_TAB = "tab";
    public static final String COLUMN_AGGREGATION_FROM = "aggrigation_from";
    public static final String COLUMN_PRIORITY = "priority";




    // Solr Constants
    public static final String SOLR_GROUP_ID = "group_id";

    // Other Constants
    public static final String CONTENT_TYPE = "Content-Type";

    public static final String SOLR_ONLINE_COLLECTION = "squareyards_online";

    public static final String UUID_DELIMITER = "-";
    public static final String BANNER_IMPRESSION = "banner_impression";
    public static final String BANNER_CLICKED = "banner_clicked";
    public static final String CLICK = "click";
    public static final String ENQUIRED = "enquired";
    public static final String SHORTLISTED_ADD = "shortlistedAdd";
    public static final String SHORTLISTED_REMOVED = "shortlistedRemoved";

    //    json constants
    public static final String JSON_KEY_PAGE_SIZE = "pageSize";
    public static final String JSON_KEY_CATEGORYNAME = "categoryName";
    public static final String JSON_KEY_EVENT_TS = "eventTs";
    public static final String JSON_KEY_ID = "id";
    public static final String JSON_KEY_SEARCHID = "searchId";
    public static final String JSON_KEY_SY_KEYWORD = "keyword";
    public static final String JSON_KEY_SEARCH_URL = "searchUrl";
    public static final String JSON_KEY_SY_UNIT_ID = "unitId";
    public static final String JSON_KEY_SY_PROJECT_ID = "projectId";
    public static final String JSON_KEY_SY_PROPERTY_ID = "propertyId";
    public static final String JSON_KEY_SY_AGENT_ID = "userId";
    public static final String JSON_KEY_SY_CITY_ID_URL = "cityid";
    public static final String JSON_KEY_SY_CATEGORY_TYPE = "type";

}
