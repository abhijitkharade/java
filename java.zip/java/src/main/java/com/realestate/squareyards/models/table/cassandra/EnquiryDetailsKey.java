package com.realestate.squareyards.models.table.cassandra;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyClass;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;

import java.util.Date;

@PrimaryKeyClass
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EnquiryDetailsKey {

    @PrimaryKeyColumn(name = Constants.COLUMN_PHONE_NUMBER, ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String phoneNumber;

    @PrimaryKeyColumn(name = Constants.COLUMN_VISIT_ID, ordinal = 1, type = PrimaryKeyType.PARTITIONED)
    private String visitId;

    @PrimaryKeyColumn(name = Constants.COLUMN_EVENT_TS, ordinal = 2, type = PrimaryKeyType.PARTITIONED)
    private Date eventTs;

    @PrimaryKeyColumn(name = Constants.COLUMN_ID, ordinal = 3, type = PrimaryKeyType.PARTITIONED)
    private String id;

}
