package com.realestate.squareyards.service.migration;

import com.google.common.base.Strings;
import com.realestate.squareyards.data.cassandra.realestate.EventCounterTrendingKeywordsRepository;
import com.realestate.squareyards.data.cassandra.realestate.EventCounterTrendingPropertyRepository;
import com.realestate.squareyards.data.cassandra.realestate.EventCounterTrendingPropertySubLocationRepository;
import com.realestate.squareyards.data.cassandra.realestate.TaxonomyRepository;
import com.realestate.squareyards.data.mysql.realestate.EventTrackingRepository;
import com.realestate.squareyards.data.mysql.realestate.SearchTrackingRepository;
import com.realestate.squareyards.models.request.trending_properties.TrendingPropertiesRequest;
import com.realestate.squareyards.models.request.trending_properties.TrendingPropertiesSubLocationRequest;
import com.realestate.squareyards.models.response.trending_properties.TrendingKeywordsResponse;
import com.realestate.squareyards.models.response.trending_properties.TrendingPropertiesResponse;
import com.realestate.squareyards.models.table.cassandra.EventCounterTrendingKeywords;
import com.realestate.squareyards.models.table.cassandra.EventCounterTrendingProperty;
import com.realestate.squareyards.models.table.cassandra.EventCounterTrendingPropertySubLocation;
import com.realestate.squareyards.models.table.cassandra.Taxonomy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

public interface TrendingPropertiesService {

    TrendingPropertiesResponse readTrendingProperties(TrendingPropertiesRequest request);

    TrendingPropertiesResponse readSubLocationTrendingProperties(TrendingPropertiesSubLocationRequest request);

    List<TrendingKeywordsResponse> readTrendingKeywords(TrendingPropertiesRequest request);
}

@Service
@Slf4j
class ITrendingPropertiesService implements TrendingPropertiesService {

    @Autowired
    TaxonomyRepository taxonomyRepository;

    @Autowired
    EventCounterTrendingPropertyRepository eventCounterTrendingPropertyRepository;

    @Autowired
    EventCounterTrendingPropertySubLocationRepository eventCounterTrendingPropertySubLocationRepository;

    @Autowired
    EventTrackingRepository eventTrackingRepository;

    @Autowired
    ActivityDetailsService activityDetailsService;

    @Autowired
    SearchTrackingRepository searchTrackingRepository;

    @Autowired
    EventCounterTrendingKeywordsRepository eventCounterTrendingKeywordsRepository;

    @Value("${piwik.trending.properties.limit:10}")
    private Integer TRENDING_PROPERTIES_LIMIT;

    @Value("${piwik.trending_search.interval:10}")
    private Integer TRENDING_INTERVAL;

    @Value("${piwik.search.limit:5}")
    private Integer SEARCH_LIMIT;

    @Value("${piwik.trending.limit:5}")
    private Integer TRENDING_LIMIT;

    private static final String DATE_PATTERN = "yyyyMMdd";
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DATE_PATTERN);

    @Override
    public TrendingPropertiesResponse readTrendingProperties(TrendingPropertiesRequest request) {
        String city = request.getCity();
        String categoryId = request.getCategoryId();

        try {
            Optional<Taxonomy> taxonomyVoOpt = taxonomyRepository.findById(Integer.parseInt(categoryId));
            if (!taxonomyVoOpt.isPresent()) {
                return new TrendingPropertiesResponse();
            }
            Taxonomy taxonomy = taxonomyVoOpt.get();
            String categoryName = taxonomy.getCategoryName();
            if (!Strings.isNullOrEmpty(categoryName)) {
                String date = simpleDateFormat.format(new Date());
                return trendingProperties(eventCounterTrendingPropertyRepository.readTrendingProperties(TRENDING_PROPERTIES_LIMIT, city, categoryName, date), categoryName);

            }
        } catch (Exception e) {
            log.error(this.getClass().getName(), e.toString());
        }

        return new TrendingPropertiesResponse();
    }

    @Override
    public TrendingPropertiesResponse readSubLocationTrendingProperties(TrendingPropertiesSubLocationRequest request) {
        String city = request.getCity();
        String categoryId = request.getCategoryId();
        Integer subLocationId = Integer.parseInt(request.getSubLocation());

        if (!Strings.isNullOrEmpty(city)) {
            try {
                Optional<Taxonomy> taxonomyVoOpt = taxonomyRepository.findById(Integer.parseInt(categoryId));
                if (!taxonomyVoOpt.isPresent()) {
                    return new TrendingPropertiesResponse();
                }
                Taxonomy taxonomy = taxonomyVoOpt.get();
                String categoryName = taxonomy.getCategoryName();
                if (!Strings.isNullOrEmpty(categoryName)) {
                    String date = simpleDateFormat.format(new Date());

                    //return trendingPropertiesBySubLocation(eventCounterTrendingPropertySubLocationRepository.readTrendingPropertiesSubLocation(TRENDING_PROPERTIES_LIMIT, city, categoryName, date, subLocationId),
                    //        categoryName);
                    return trendingPropertiesBySubLocationMysql(eventTrackingRepository.readSubLocationTrendingProperties(TRENDING_PROPERTIES_LIMIT, city, subLocationId, categoryName, TRENDING_INTERVAL), categoryName);
                }
            } catch (Exception e) {
                log.error(this.getClass().getName(), e.toString());
            }
        }

        return new TrendingPropertiesResponse();
    }

    @Override
    public List<TrendingKeywordsResponse> readTrendingKeywords(TrendingPropertiesRequest request) {

        List<TrendingKeywordsResponse> listTrendingKeywords = new ArrayList<>();

        String city = request.getCity();
        String categoryId = request.getCategoryId();
        if (city != null) {
            try {
                Optional<Taxonomy> taxonomyVoOpt = taxonomyRepository.findById(Integer.parseInt(categoryId));
                if (!taxonomyVoOpt.isPresent()) {
                    return listTrendingKeywords;
                }
                Taxonomy taxonomy = taxonomyVoOpt.get();
                String categoryName = taxonomy.getCategoryName();
                String date = simpleDateFormat.format(new Date());
                List<EventCounterTrendingKeywords> trendingKeywords = eventCounterTrendingKeywordsRepository.readTrendingKeywords(TRENDING_LIMIT, city, categoryName, date);
                if (trendingKeywords != null) {
                    for (EventCounterTrendingKeywords records : trendingKeywords) {
                        if (records.getKey().getSuggestedKeywords() != null && records.getKey().getSearchUrlLast() != null &&
                                activityDetailsService.isValidKeyword(records.getKey().getCategoryName(), records.getKey().getSearchUrlLast())) {

                            TrendingKeywordsResponse trendingRecords = new TrendingKeywordsResponse();
                            trendingRecords.setCityid(records.getKey().getCity());
                            trendingRecords.setKeyword(records.getKey().getSuggestedKeywords());
                            trendingRecords.setSearchUrl(records.getKey().getSearchUrlLast());
                            trendingRecords.setType(records.getKey().getCategoryName());

                            listTrendingKeywords.add(trendingRecords);
                        }
                    }
                }
                return listTrendingKeywords;
            } catch (Exception e) {
                log.error("invalid location ", e.toString());
                throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, " Something went wrong", e);

            }
        }
        return Collections.emptyList();
    }

    private TrendingPropertiesResponse trendingProperties(List<EventCounterTrendingProperty> eventTracking, String categoryName) {

        List<String> trendingProperties = new ArrayList<>();
        if (eventTracking != null) {
            List<EventCounterTrendingProperty> sList = new ArrayList<>();
            sList = eventTracking.stream().sorted(Comparator.comparing(EventCounterTrendingProperty::getCount).reversed()).collect(Collectors.toList());
            for (EventCounterTrendingProperty records : sList) {
                trendingProperties.add(records.getKey().getGroupId());
            }
            TrendingPropertiesResponse trendingPropertiesRecords = new TrendingPropertiesResponse(trendingProperties, categoryName);
            return trendingPropertiesRecords;

        }
        return new TrendingPropertiesResponse();
    }

    private TrendingPropertiesResponse trendingPropertiesBySubLocation(List<EventCounterTrendingPropertySubLocation> eventTracking, String categoryName) {

        List<String> trendingProperties = new ArrayList<>();
        if (eventTracking != null) {
            List<EventCounterTrendingPropertySubLocation> sList = new ArrayList<>();
            sList = eventTracking.stream().sorted(Comparator.comparing(EventCounterTrendingPropertySubLocation::getCount).reversed()).collect(Collectors.toList());
            for (EventCounterTrendingPropertySubLocation records : sList) {
                trendingProperties.add(records.getKey().getGroupId());
            }
            TrendingPropertiesResponse trendingPropertiesRecords = new TrendingPropertiesResponse(trendingProperties, categoryName);
            return trendingPropertiesRecords;

        }
        return new TrendingPropertiesResponse();
    }

    private TrendingPropertiesResponse trendingPropertiesBySubLocationMysql(List<Object[]> eventTracking, String categoryName) {

        List<String> trendingProperties = new ArrayList<>();
        if (eventTracking != null) {
            for (Object[] records : eventTracking) {
                trendingProperties.add(records[2].toString());
            }
            TrendingPropertiesResponse trendingPropertiesRecords = new TrendingPropertiesResponse(trendingProperties, categoryName);
            return trendingPropertiesRecords;

        }
        return new TrendingPropertiesResponse();

    }
}
