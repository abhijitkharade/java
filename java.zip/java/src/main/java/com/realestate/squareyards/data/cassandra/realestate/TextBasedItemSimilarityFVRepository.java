package com.realestate.squareyards.data.cassandra.realestate;

import com.realestate.squareyards.models.table.cassandra.TextBasedItemSimilarityFV;
import com.realestate.squareyards.models.table.cassandra.TextBasedItemSimilarityFVKey;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface TextBasedItemSimilarityFVRepository extends CassandraRepository<TextBasedItemSimilarityFV, TextBasedItemSimilarityFVKey> {

}
