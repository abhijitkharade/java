package com.realestate.squareyards.models.table.mysql;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Data
@Entity
@Table(name = Constants.EVENT_COUNTER_TIME_INTERVAL_TABLE)
@AllArgsConstructor
@NoArgsConstructor
public class EventCounterTimeInterval {

    @Id
    @Column(name = Constants.COLUMN_ID)
    private String id;

    @Column(name = Constants.COLUMN_CATEGORY_NAME)
    private String categoryName;

    @Column(name = Constants.COLUMN_EVENT_TYPE)
    private String eventType;

    @Column(name = Constants.COLUMN_PRODUCT_ID)
    private String productId;

    @Column(name = Constants.COLUMN_GROUP_ID)
    private String groupId;

    @Column(name = Constants.COLUMN_COUNT)
    private String count;

    @Column(name = Constants.COLUMN_TIME_INTERVAL)
    private Date timeInterval;

}
