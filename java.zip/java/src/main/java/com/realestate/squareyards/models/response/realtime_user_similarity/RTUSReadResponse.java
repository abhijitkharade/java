package com.realestate.squareyards.models.response.realtime_user_similarity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Slf4j
public class RTUSReadResponse {

    @ApiModelProperty(example = "['For resale/rental']")
    @JsonProperty("similarPropertyIds")
    List<String> propertyId = null;

    @ApiModelProperty(example = "['For New Projects']")
    @JsonProperty("similarProjectIds")
    List<String> projectId = null;

    @ApiModelProperty(example = "RECOMMENDED")
    @JsonProperty("type")
    String type = "";

    public RTUSReadResponse(List<String> projectId, List<String> propertyId, String type) {
        this.projectId = projectId;
        this.propertyId = propertyId;
        this.type = type;
    }

}
