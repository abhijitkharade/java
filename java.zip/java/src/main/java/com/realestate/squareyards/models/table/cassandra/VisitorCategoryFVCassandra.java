package com.realestate.squareyards.models.table.cassandra;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

import java.util.Date;
import java.util.List;

@Table(Constants.VISITOR_CATEGORY_FV_TAXONOMY_ID_TABLE)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class VisitorCategoryFVCassandra {

    @PrimaryKeyColumn(name = Constants.COLUMN_VISITOR_ID, ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String visitorId;

    @Column(Constants.COLUMN_GROUP_ID_CLICK)
    private List<String> groupIdClick;

    @Column(Constants.COLUMN_PRODUCT_TYPE_VIEW)
    private List<String> productTypeView;

    @Column(Constants.COLUMN_CREATED_TS)
    private Date createdTs;

    @Column(Constants.COLUMN_MODIFIED_TS)
    private Date modifiedTs;

    @Column(Constants.COLUMN_STATUS)
    private String status;

    @Column(Constants.COLUMN_USER_TASTE_FV)
    private List<Double> userTasteFv;
}
