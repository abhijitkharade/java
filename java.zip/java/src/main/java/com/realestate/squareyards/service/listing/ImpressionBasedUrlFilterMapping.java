package com.realestate.squareyards.service.listing;

import java.util.HashMap;
import java.util.Map;

public class ImpressionBasedUrlFilterMapping {

    private static Map<String, String> urlFilters = new HashMap<>();
    private static Map<String, String> elasticFilters = new HashMap<>();

    static {
        urlFilters.put("cityId", "cityid");
        urlFilters.put("furnishing", "furnishingstatus");
        urlFilters.put("bedrooms", "unittype");
        urlFilters.put("propertyType", "propertytypeid");
        urlFilters.put("buildingType", "buildingtypeid");
        urlFilters.put("postedBy", "postedBy");
        urlFilters.put("dotcomprojectid", "dotcomprojectid");
        urlFilters.put("projectId", "beatsprojectid");
        urlFilters.put("minPrice", "minPrice");
        urlFilters.put("maxPrice", "maxPrice");
        urlFilters.put("minArea", "minArea");
        urlFilters.put("maxArea", "maxArea");
        urlFilters.put("category_id", "category_id");
        urlFilters.put("locationId", "sublocalityid");
    }

    static {
        elasticFilters.put("cityId", "cityid");
        elasticFilters.put("listingType", "listingType");
        elasticFilters.put("beatsProjectId", "beatsprojectid");
        elasticFilters.put("unitType", "unittype");
        elasticFilters.put("propertyType", "propertytype");
        elasticFilters.put("furnishing", "furnishingstatus");
        elasticFilters.put("minPrice", "minPrice");
        elasticFilters.put("maxPrice", "maxPrice");
        elasticFilters.put("price", "price");
        elasticFilters.put("category_id", "category_id");
        elasticFilters.put("subLocalityId", "sublocalityid");
    }

    public static Map<String, String> getUrlFilters() {
        return urlFilters;
    }

    public static Map<String, String> getElasticFilters() {
        return elasticFilters;
    }
}
