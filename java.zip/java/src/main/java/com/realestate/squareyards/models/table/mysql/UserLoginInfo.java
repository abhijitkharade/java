package com.realestate.squareyards.models.table.mysql;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Data
@Entity
@Table(name = Constants.USER_LOGIN_INFO_TABLE)
@AllArgsConstructor
@NoArgsConstructor
public class UserLoginInfo {

    @Id
    @Column(name = Constants.COLUMN_VISITOR_ID)
    private String visitorId;

    @Column(name = Constants.COLUMN_EMAIL)
    private String email;

    @Column(name = Constants.COLUMN_PHONE_NUMBER)
    private String phoneNumber;

    @Column(name = Constants.COLUMN_USER_NAME)
    private String userName;

    @Column(name = Constants.COLUMN_CITY)
    private String city;

    @Column(name = Constants.COLUMN_CREATED_TS)
    private Date createdTs;

    @Column(name = Constants.COLUMN_MODIFIED_TS)
    private Date modifiedTs;
}
