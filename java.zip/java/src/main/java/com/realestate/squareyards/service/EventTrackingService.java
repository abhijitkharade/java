package com.realestate.squareyards.service;

import com.realestate.squareyards.data.mysql.realestate.EventTrackingRepository;
import com.realestate.squareyards.models.table.mysql.EventTracking;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.util.List;

public interface EventTrackingService {

    List<EventTracking> readTrackingDataVisitorWise(List<String> visitId);

    List<EventTracking> readShortlistedPropertiesActivity(List<String> visitId, String categoryType);

    List<EventTracking> readViewedPropertiesActivity(List<String> visitId, String categoryType);

    List<EventTracking> readEnquiredPropertiesActivity(List<String> visitId, String categoryType);

    List<EventTracking> readNewProjectsShortlistedPropertiesActivity(List<String> visitId, String categoryType);

    List<EventTracking> readNewProjectsViewedPropertiesActivity(List<String> visitId, String categoryType);

    List<EventTracking> readNewProjectsEnquiredPropertiesActivity(List<String> visitId, String categoryType);

    List<EventTracking> readPropertiesActivity(List<String> visitId);

    List<Object[]> readTrendingProperties(String city, String categoryName);

    List<Object[]> readSubLocationTrendingProperties(String city, Integer subLocation, String categoryName);

}

@Slf4j
@Service
class IEventTrackingService implements EventTrackingService {

    @Autowired
    private EventTrackingRepository eventTrackingRepository;

    @Autowired
    private Environment environment;

    @Value("${piwik.tracking.interval:1}")
    private Integer TRACKING_INTERVAL;

    @Value("${piwik.trending.interval:1}")
    private Integer TRENDING_INTERVAL;

    @Value("${piwik.agent.properties.interval:1}")
    private Integer AGENT_PROPERTIES_INTERVAL;

    @Value("${piwik.agent.profile.interval:1}")
    private Integer AGENT_PROFILES_INTERVAL;

    @Value("${piwik.shortlisted.limit:5}")
    private Integer SHORTLISTED_LIMIT;

    @Value("${piwik.shortlisted.activity.limit:5}")
    private Integer SHORTLIST_ACTIVITY_LIMIT;

    @Value("${piwik.viewed.activity.limit:5}")
    private Integer VIEWED_ACTIVITY_LIMIT;

    @Value("${piwik.enquired.activity.limit:5}")
    private Integer ENQUIRED_ACTIVITY_LIMIT;

    @Value("${piwik.trending.properties.interval:10}")
    private Integer TRENDING_PROPERTIES_INTERVAL;

    @Value("${piwik.trending.properties.limit:10}")
    private Integer TRENDING_PROPERTIES_LIMIT;

    @Override
    public List<EventTracking> readTrackingDataVisitorWise(List<String> visitId) {

        return eventTrackingRepository.readTrackingDataVisitorWise(SHORTLISTED_LIMIT, visitId);
    }

    @Override
    public List<EventTracking> readShortlistedPropertiesActivity(List<String> visitId, String categoryType) {

        return eventTrackingRepository.readPropertiesActivity(SHORTLIST_ACTIVITY_LIMIT, visitId, "shortlisted", categoryType);
    }

    @Override
    public List<EventTracking> readViewedPropertiesActivity(List<String> visitId, String categoryType) {

        return eventTrackingRepository.readPropertiesActivity(VIEWED_ACTIVITY_LIMIT, visitId, "click", categoryType);
    }

    @Override
    public List<EventTracking> readEnquiredPropertiesActivity(List<String> visitId, String categoryType) {

        return eventTrackingRepository.readPropertiesActivity(ENQUIRED_ACTIVITY_LIMIT, visitId, "enquired", categoryType);
    }

    @Override
    public List<EventTracking> readNewProjectsShortlistedPropertiesActivity(List<String> visitId, String categoryType) {

        return eventTrackingRepository.readNewProjectPropertiesActivity(SHORTLIST_ACTIVITY_LIMIT, visitId, "shortlisted", categoryType);
    }

    @Override
    public List<EventTracking> readNewProjectsViewedPropertiesActivity(List<String> visitId, String categoryType) {

        return eventTrackingRepository.readNewProjectPropertiesActivity(VIEWED_ACTIVITY_LIMIT, visitId, "click", categoryType);
    }

    @Override
    public List<EventTracking> readNewProjectsEnquiredPropertiesActivity(List<String> visitId, String categoryType) {

        return eventTrackingRepository.readNewProjectPropertiesActivity(ENQUIRED_ACTIVITY_LIMIT, visitId, "enquired", categoryType);
    }

    @Override
    public List<Object[]> readTrendingProperties(String city, String categoryName) {

        return eventTrackingRepository.readTrendingProperties(TRENDING_PROPERTIES_LIMIT, city, categoryName, TRENDING_PROPERTIES_INTERVAL);
    }

    @Override
    public List<EventTracking> readPropertiesActivity(List<String> visitId) {

        return eventTrackingRepository.readAllPropertiesActivity(SHORTLIST_ACTIVITY_LIMIT, visitId);
    }

    @Override
    public List<Object[]> readSubLocationTrendingProperties(String city, Integer subLocation, String categoryName) {

        return eventTrackingRepository.readSubLocationTrendingProperties(TRENDING_PROPERTIES_LIMIT, city, subLocation, categoryName, TRENDING_PROPERTIES_INTERVAL);
    }
}
