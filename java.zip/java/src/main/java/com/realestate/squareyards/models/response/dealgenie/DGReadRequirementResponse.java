package com.realestate.squareyards.models.response.dealgenie;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Strings;
import com.realestate.squareyards.models.table.cassandra.AgentRequirements;
import com.realestate.squareyards.utils.Types;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.*;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Slf4j
public class DGReadRequirementResponse {

    @ApiModelProperty
    List<DGRequirement> requirements;

    @ApiModelProperty(example = "true")
    @JsonProperty("is_last")
    boolean isLast;

    @ApiModelProperty(example = "2")
    @JsonProperty("page_number")
    int pageNumber = 0;

    public DGReadRequirementResponse(List<AgentRequirements> agentRequirements, boolean isLast, int pageNumber) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("IST"));
        requirements = new ArrayList<>();
        agentRequirements.forEach(e -> {
                    DGRequirement response = new DGRequirement();
                    response.agentId = e.getAgentRequirementsKey().getAgentId();
                    response.requirementId = e.getAgentRequirementsKey().getRequirementId();
                    response.status = Types.Statuses.valueOf(e.getStatus());
                    response.filters = getFiltersObject(e.getFilters());
                    response.requirementName = e.getRequirementName();
                    response.categoryId = e.getCategoryId() != null ? e.getCategoryId().toString() : "0";
                    response.newPropertyCount = e.getNewPropertyCount();
                    response.shortlistedCount = e.getShortListedCount();
                    requirements.add(response);
                }
        );
        this.isLast = isLast;
        this.pageNumber = pageNumber;

    }

    @Override
    public String toString() {
        return "DGReadRequirement{" +
                "DGRequirements=" + requirements +
                ", isLast=" + isLast +
                ", pageNumber=" + pageNumber +
                '}';
    }

    @NoArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    class DGRequirement {

        @ApiModelProperty(example = "2")
        @JsonProperty("new_property_count")
        long newPropertyCount = 0;

        @ApiModelProperty(example = "2")
        @JsonProperty("shortlisted_count")
        long shortlistedCount = 0;

        @ApiModelProperty(example = "ID1234")
        @JsonProperty("agent_id")
        String agentId;

        @ApiModelProperty(example = "Name")
        @JsonProperty("requirement_name")
        String requirementName;

        @ApiModelProperty(example = "1")
        @JsonProperty("category_id")
        String categoryId;

        @ApiModelProperty(example = "09-11-2021 16:19:32")
        @JsonProperty("created_ts")
        String createdTs;

        @ApiModelProperty(example = "{'city':['mumbai']}")
        @JsonProperty("filters")
        Map<String, List<Object>> filters;

        @ApiModelProperty(example = "ID1234")
        @JsonProperty("requirement_id")
        String requirementId;

        @ApiModelProperty()
        @JsonProperty("status")
        Types.Statuses status;

    }

    private Map<String, List<Object>> getFiltersObject(Map<String, String> filters) {

        try {
            if (filters != null && !filters.isEmpty()) {
                JSONObject filtersJson = new JSONObject(new ObjectMapper().writeValueAsString(filters));
                Map<String, List<Object>> resultObject = new HashMap<>();

                filters.keySet().forEach(e -> {
                    String filterString = filters.get(e);
                    if (!Strings.isNullOrEmpty(filterString)) {
                        String filterArray = filterString.substring(0, filterString.length());
                        resultObject.put(e, new JSONArray(filterArray).toList());
                    }
                });
                return resultObject;

            }
        } catch (Exception e) {
            log.error("Failed to get filters ", e);
        }
        return Collections.emptyMap();
    }

}
