package com.realestate.squareyards.data.mysql.realestate;

import com.realestate.squareyards.models.table.mysql.EventCounterTimeInterval;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import javax.annotation.Nullable;
import java.util.List;

public interface EventCounterIntervalRepository extends CrudRepository<EventCounterTimeInterval, Integer> {

    @Nullable
    @Query(value = "SELECT  group_id as group_id,event_type as event_type, count(*) as cnt FROM event_tracking WHERE  category_name = ?1 AND group_id = ?2 and event_type in ?3 group by event_type", nativeQuery = true)
    List<Object[]> countByGroupId(String categoryName, String groupId, List<String> events);

    @Nullable
    @Query(value = "SELECT  product_id as product_id,event_type as event_type, count(*) as cnt FROM event_tracking WHERE  category_name = ?1 AND product_id = ?2 and event_type in ?3 group by event_type", nativeQuery = true)
    List<Object[]> countByProductId(String categoryName, String productId, List<String> events);

}
