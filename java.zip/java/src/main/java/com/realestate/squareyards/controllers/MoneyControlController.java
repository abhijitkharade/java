package com.realestate.squareyards.controllers;

import com.realestate.squareyards.models.request.moneycontrol.MoneyControlRequest;
import com.realestate.squareyards.models.response.moneycontrol.MoneyControlResponse;
import com.realestate.squareyards.models.table.cassandra.WidgetMaster;
import com.realestate.squareyards.models.table.cassandra.WidgetMasterKey;
import com.realestate.squareyards.service.MoneyControlService;
import com.realestate.squareyards.utils.Routes;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@Api(tags = "Money Control")
@RequestMapping(Routes.MONEY_CONTROL + Routes.OPEN)
public class MoneyControlController {
    @Autowired
    MoneyControlService moneyControlService;
   /* @PostMapping("/data")
    WidgetMaster findByKey(@RequestBody WidgetMasterKey key){
        return moneyControlService.findByKey(key);
    }
    @PostMapping("/top")
    List findTop(@RequestBody WidgetMasterKey key){
        return moneyControlService.findTop(key);
    }
*/
    @PostMapping(value = Routes.WIDGET + Routes.READ,
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    MoneyControlResponse findAllAggregation(@Valid @RequestBody MoneyControlRequest req){

        return moneyControlService.findAllAggregation(req);
    }
}
