package com.realestate.squareyards.controllers;

import com.realestate.squareyards.models.request.moneycontrol.MoneyControlRequest;
import com.realestate.squareyards.models.response.ResponseBuilderV1;
import com.realestate.squareyards.models.response.moneycontrol.MoneyControlResponse;
import com.realestate.squareyards.models.table.cassandra.WidgetMaster;
import com.realestate.squareyards.models.table.cassandra.WidgetMasterKey;
import com.realestate.squareyards.service.MoneyControlService;
import com.realestate.squareyards.utils.Constants;
import com.realestate.squareyards.utils.Routes;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Api(tags = "Money Control")
@RequestMapping(Routes.MONEY_CONTROL + Routes.OPEN)
public class MoneyControlController {
    @Autowired
    MoneyControlService moneyControlService;
   /* @PostMapping("/data")
    WidgetMaster findByKey(@RequestBody WidgetMasterKey key){
        return moneyControlService.findByKey(key);
    }
    @PostMapping("/top")
    List findTop(@RequestBody WidgetMasterKey key){
        return moneyControlService.findTop(key);
    }
*/
    @PostMapping(value = Routes.WIDGET+ Routes.READ)
    public @ResponseBody
    ResponseBuilderV1<MoneyControlResponse> findAllAggregation(@ApiParam(defaultValue = Constants.VERSION_1) @PathVariable(name = "version") String version,
                                                               @RequestBody MoneyControlRequest req){
        ResponseBuilderV1 builder = new ResponseBuilderV1();
        builder.setCode(HttpStatus.OK.value());
        builder.setStatus(HttpStatus.OK.name());
        builder.setResult(moneyControlService.findAllAggregation(req));
        return builder;
    }
}
