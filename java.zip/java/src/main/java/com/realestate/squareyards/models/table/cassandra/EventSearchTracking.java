package com.realestate.squareyards.models.table.cassandra;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import java.util.Date;

@Table(Constants.EVENT_SEARCH_TRACKING_TABLE)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EventSearchTracking {

    @PrimaryKey
    private EventSearchTrackingKey eventSearchTrackingKey;

    @Column(Constants.COLUMN_CREATED_TS)
    private Date createdTs;

    @Column(Constants.COLUMN_FILTER_ID)
    private String filterId;

    @Column(Constants.COLUMN_SEARCH_URL)
    private String searchUrl;

    @Column(Constants.COLUMN_TYPED_KEYWORD)
    private String typedKeyword;

    @Column(Constants.COLUMN_SUGGESTED_KEYWORD)
    private String suggestedKeyword;

    @Column(Constants.COLUMN_VISIT_ID)
    private String visitId;

    @Column(Constants.COLUMN_PAGE_TYPE)
    private String pageType;

    @Column(Constants.COLUMN_EVENT_TS)
    private Date eventTs;
}
