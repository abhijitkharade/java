package com.realestate.squareyards.models.table.mysql;

import com.realestate.squareyards.models.request.notification.TokenInsert;
import com.realestate.squareyards.utils.Constants;
import com.realestate.squareyards.utils.JsonToMapConverter;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.HashMap;
import java.util.Map;

@Data
@Entity
@Table(name = Constants.PUSH_SUBSCRIPTION_TABLE)
@AllArgsConstructor
@NoArgsConstructor
public class PushSubscription {

    @Id
    private String visitorid;

    @Column(name = Constants.COLUMN_SUBSCRIPTION, columnDefinition = "json")
    @Convert(converter = JsonToMapConverter.class)
    private Map<String, String> subscription = new HashMap<>();

    @Column(name = Constants.COLUMN_STATUS)
    private String status;

    @Column(name = Constants.COLUMN_SUBSCRIPTION_TYPE)
    private String subscriptionType;

    @Column(name = Constants.COLUMN_USER_NAME)
    private String userName;

    public PushSubscription(TokenInsert insert) {

        Map<String, String> token = new HashMap<>();
        token.put(Constants.TOKEN, insert.getToken());
        visitorid = insert.getVisitorId();
        subscription.putAll(token);
        status = insert.getStatus().name();
        subscriptionType = insert.getSubscriptionType().name();
        ;
        userName = insert.getUserName();
    }

}
