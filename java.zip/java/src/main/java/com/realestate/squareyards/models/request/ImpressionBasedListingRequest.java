package com.realestate.squareyards.models.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
public class ImpressionBasedListingRequest {

    @NotNull
    @ApiModelProperty(example = "https://www.squareyards.com/rent/property-for-rent-in-pune", required = true)
    @JsonProperty("listing_url")
    private String listingUrl;

    @ApiModelProperty(example = "ID12346789")
    @JsonProperty("visitor_id")
    private String visitorId;

    @ApiModelProperty(example = "sale/rent/new_project/agent")
    @JsonProperty("listing_type")
    private String listingType;

}
