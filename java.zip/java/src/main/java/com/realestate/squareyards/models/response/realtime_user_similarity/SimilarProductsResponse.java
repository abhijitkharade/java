package com.realestate.squareyards.models.response.realtime_user_similarity;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Slf4j
public class SimilarProductsResponse {

    @ApiModelProperty(example = "['12345','23213','123123']")
    List<String> similarProjectIds;

    @ApiModelProperty(example = "['12345','23213','123123']")
    List<String> similarPropertyIds;

}
