package com.realestate.squareyards.core;

import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.Notification;
import com.realestate.squareyards.models.Entity.FirebaseNote;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public record FirebaseMessagingService(FirebaseMessaging firebaseMessaging) {

    public String sendNotification(FirebaseNote note, String token) throws FirebaseMessagingException {

        Notification notification = Notification
                .builder()
                .setTitle(note.getSubject())
                .setBody(note.getContent())
                .setImage(note.getImage())
                .build();

        Message message = Message
                .builder()
                .setToken(token)
                .setNotification(notification)
                .putAllData(note.getData())
                .build();

        String response = firebaseMessaging.send(message);
        log.info("Notification response for = " + response);
        return response;
    }
}
