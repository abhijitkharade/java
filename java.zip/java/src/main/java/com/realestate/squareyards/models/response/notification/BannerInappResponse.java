package com.realestate.squareyards.models.response.notification;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.realestate.squareyards.models.table.mysql.custom.Notification;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Slf4j
@NoArgsConstructor
public class BannerInappResponse {

    @ApiModelProperty(example = "210")
    @JsonProperty("goalId")
    private String goalId;

    @ApiModelProperty(example = "312")
    @JsonProperty("goalUUID")
    private String goalUUID;

    @ApiModelProperty(example = "https://redesign.squareyards..com")
    @JsonProperty("redirectUrl")
    private String redirectUrl;

    @ApiModelProperty(example = "Hello ")
    @JsonProperty("notificationTitle")
    private String notificationTitle;

    @ApiModelProperty(example = "15323")
    @JsonProperty("visitId")
    private String visitId;

    @ApiModelProperty(example = "Checkout the new properties")
    @JsonProperty("notificationText")
    private String notificationText;

    @ApiModelProperty(example = "https://sqconnect.s3.ap-south-1.amazonaws.com/mailers/images/dummy-banner.jpg")
    @JsonProperty("imagePathDesktop")
    private String imagePathDesktop;

    @ApiModelProperty(example = "https://sqconnect.s3.ap-south-1.amazonaws.com/mailers/images/dummy-banner.jpg")
    @JsonProperty("imagePathMobile")
    private String imagePathMobile;

    @ApiModelProperty(example = "74b82384534d299b")
    @JsonProperty("visitorId")
    private String visitorId;

    @ApiModelProperty(example = "1")
    @JsonProperty("siteId")
    private String siteId;

    @ApiModelProperty(example = "overlay")
    @JsonProperty("placementType")
    private String placementType;

    @ApiModelProperty(example = "left")
    @JsonProperty("placeholder")
    private String placeholder;

    @ApiModelProperty(example = "1")
    private String priority;

    @ApiModelProperty(example = "1755533426829")
    private String id;

    public BannerInappResponse(Notification notification) {

        this.goalId = notification.getIdgoal().toString();
        this.goalUUID = notification.getGoalUUID().toString();
        this.redirectUrl = notification.getRedirectUrl();
        this.notificationTitle = notification.getNotificationTitle();
        this.visitId = notification.getIdvisit().toString();
        this.notificationText = notification.getNotificationText();
        this.siteId = notification.getIdsite().toString();
        this.visitorId = notification.getVisitorId();
        this.placeholder = notification.getPlaceholder();
        this.placementType = notification.getPlacementType();
        this.priority = notification.getPriority();
        this.id = notification.getUniqueid();
        String[] image = notification.getImagePath().split(",");
        if (image.length == 2) {
            this.imagePathDesktop = image[0];
            this.imagePathMobile = image[1];
        } else {
            this.imagePathDesktop = notification.getImagePath();
        }
    }
}
