package com.realestate.squareyards.models.request.similarity;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class RTUSInsert {

    @NotNull
    @ApiModelProperty(example = "d46325a87954cca2", required = true)
    @JsonProperty("visitor_id")
    private String visitorId;

    @NotNull
    @ApiModelProperty(example = "1/2/3/4", required = true)
    @JsonProperty("category_id")
    private String categoryId = "0";

    @NotNull
    @ApiModelProperty(example = "100006", required = true)
    @JsonProperty("project_id")
    private String projectId;

}
