package com.realestate.squareyards.models.table.mysql;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
@Data
@AllArgsConstructor
@NoArgsConstructor
public class VisitorDataViewKey implements Serializable {

    @Column(name = Constants.COLUMN_TAXONOMY_ID)
    private Integer taxonomyId;

    @Column(name = Constants.COLUMN_PRODUCT_TYPE)
    private String productType;

    @Column(name = Constants.COLUMN_VISITOR_ID)
    private String visitorId;

    @Column(name = Constants.COLUMN_EVENT_DATE)
    private Integer eventDate;
}
