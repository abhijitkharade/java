package com.realestate.squareyards.models.request.notification;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class BannerInappRequest {

    @NotNull
    @ApiModelProperty(example = "74b82384534d299b", required = true)
    @JsonProperty("visitorId")
    private String visitorId;
    
}
