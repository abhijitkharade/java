package com.realestate.squareyards.service;

import com.realestate.squareyards.data.mysql.realestate.PushSubscriptionRepository;
import com.realestate.squareyards.models.request.notification.TokenInsert;
import com.realestate.squareyards.models.table.mysql.PushSubscription;
import com.realestate.squareyards.utils.Types;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

public interface PushSubscriptionService {

    Boolean insertTokenData(TokenInsert request);
}

@Slf4j
@Service
class IPushSubscriptionService implements PushSubscriptionService {

    @Autowired
    private PushSubscriptionRepository pushSubscriptionRepository;

    @Override
    public Boolean insertTokenData(TokenInsert request) {

        try {
            PushSubscription pushSub = new PushSubscription(request);
            if (Types.Device.ANDROID.name().equals(pushSub.getSubscriptionType()) || Types.Device.IOS.name().equals(pushSub.getSubscriptionType()) || Types.Device.DESKTOP.name().equals(pushSub.getSubscriptionType())) {
                pushSubscriptionRepository.save(pushSub);
            }
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, " Something went wrong", e);
        }
        return true;
    }
}