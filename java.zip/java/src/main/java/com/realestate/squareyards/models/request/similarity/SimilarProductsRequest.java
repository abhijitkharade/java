package com.realestate.squareyards.models.request.similarity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class SimilarProductsRequest {

    @NotNull
    @ApiModelProperty(example = "1", required = true)
    private int categoryId;

    @ApiModelProperty(example = "18109")
    private String projectId;

    @ApiModelProperty(example = "1813090")
    private String propertyId;
}
