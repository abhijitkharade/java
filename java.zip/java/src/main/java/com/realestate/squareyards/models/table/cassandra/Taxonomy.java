package com.realestate.squareyards.models.table.cassandra;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Data
@Table(Constants.TAXONOMY_TABLE)
@AllArgsConstructor
@NoArgsConstructor
public class Taxonomy {
    @PrimaryKey(Constants.COLUMN_TAXONOMY_ID)
    private Integer taxonomyId;

    @Column(Constants.COLUMN_CATEGORY_ID)
    private Integer categoryId;

    @Column(Constants.COLUMN_CATEGORY_NAME)
    private String categoryName;

}
