package com.realestate.squareyards.data.cassandra.realestate;

import com.realestate.squareyards.models.table.cassandra.AgentRequirements;
import com.realestate.squareyards.models.table.cassandra.AgentRequirementsKey;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.repository.query.Param;

public interface AgentRequirementsRepository extends CassandraRepository<AgentRequirements, AgentRequirementsKey> {

    Slice<AgentRequirements> findByStatusAndAgentRequirementsKeyAgentId(String status, String agentId, Pageable pageable);

    @Query(value = "select * from realestate_squareyards.agent_requirements where agent_id = :agent_id AND requirement_id= :requirement_id AND status= :status")
    AgentRequirements findAgentRequirement(@Param("agent_id") String agentId, @Param("requirement_id") String requirementId, @Param("status") String status);

}
