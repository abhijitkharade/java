package com.realestate.squareyards.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Converter
@Slf4j
public class JsonToListConverter implements AttributeConverter<List<Object>, String> {

    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public String convertToDatabaseColumn(List<Object> attribute) {

        if (attribute == null) {
            return null;
        }
        try {
            return objectMapper.writeValueAsString(attribute);
        } catch (IOException e) {
            log.info(this.getClass().getName(), "json to List error ", e);
            return null;
        }
    }

    @Override
    public List<Object> convertToEntityAttribute(String jsonString) {

        if (jsonString == null) {
            return new ArrayList<>(0);
        }
        try {
            return objectMapper.readValue(jsonString, ArrayList.class);
        } catch (IOException e) {
            log.info(this.getClass().getName(), "json to List error ", e);
        }
        return new ArrayList<>(0);

    }
}
