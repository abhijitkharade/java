package com.realestate.squareyards.data.cassandra.realestate;

import com.realestate.squareyards.models.table.cassandra.UserLoginInfoPhoneNumberView;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import javax.annotation.Nullable;
import java.util.List;

public interface UserLoginInfoPhoneNumberViewRepository extends CassandraRepository<UserLoginInfoPhoneNumberView, String> {

    @Nullable
    @Query(value = "select * from realestate_squareyards.user_login_info_phone_number where phone_number = ?0")
    List<UserLoginInfoPhoneNumberView> findVisitorIdByPhoneNumber(String phoneNumber);
}
