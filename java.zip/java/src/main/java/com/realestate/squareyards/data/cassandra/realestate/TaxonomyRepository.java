package com.realestate.squareyards.data.cassandra.realestate;

import com.realestate.squareyards.models.table.cassandra.Taxonomy;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface TaxonomyRepository extends CassandraRepository<Taxonomy, Integer> {
}
