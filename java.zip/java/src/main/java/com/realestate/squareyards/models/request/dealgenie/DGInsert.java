package com.realestate.squareyards.models.request.dealgenie;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Map;

@Data
public class DGInsert {

    @NotNull
    @ApiModelProperty(example = "agent-123", required = true)
    @JsonProperty("agent_id")
    private String agentId;

    @NotNull
    @ApiModelProperty(example = "1/2/3/4", required = true)
    @JsonProperty("category_id")
    private int categoryId = 0;

    @ApiModelProperty(example = "requirement_name", required = false)
    @JsonProperty("requirement_name")
    private String requirementName;

    @ApiModelProperty(example = "{'city':['mumbai']}", required = false)
    private Map<String, List<String>> filters;

}
