package com.realestate.squareyards.service.migration;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.realestate.squareyards.core.solr.SolrBaseRepository;
import com.realestate.squareyards.data.mysql.realestate.VisitorDataViewRepository;
import com.realestate.squareyards.models.request.similarity.SimilarProductsRequest;
import com.realestate.squareyards.models.response.realtime_user_similarity.SimilarProductsResponse;
import com.realestate.squareyards.models.table.mysql.VisitorDataView;
import com.realestate.squareyards.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.stream.Collectors;

public interface SimilarityService {

    SimilarProductsResponse getSimilarProducts(SimilarProductsRequest request);

    SimilarProductsResponse getVisitorSimilarity(SimilarProductsRequest request);
}

@Service
@Slf4j
class ISimilarityService extends SolrBaseRepository implements SimilarityService {

    private static final Map<Integer, List<String>> productIncludeDocs = new HashMap<>();
    private static final Map<Integer, List<String>> productsExcludeDocs = new HashMap<>();
    private static final Map<Integer, Map<String, Integer>> productsBoostingDocs = new HashMap<>();
    private static final Map<Integer, List<String>> visitorIncludeDocs = new HashMap<>();
    private static final Map<Integer, List<String>> visitorExcludeDocs = new HashMap<>();
    private static final Map<Integer, Map<String, Integer>> visitorBoostingDocs = new HashMap<>();

    @Value("${price.range.percentage:20}")
    private int PRICE_RANGE;

    @Value("${price.range.extended.percentage:20}")
    private int PRICE_RANGE_EXTENDED;

    @Value("${similarity.solr.fields:group_id}")
    private String PRODUCT_SIMILARITY_FL;

    @Value("${visitor.similarity.solr.fields:group_id}")
    private String VISITOR_SIMILARITY_FL;

    @Value("${product.similarity.product.limit:10}")
    private int PRODUCT_SIMILARITY_LIMIT;

    @Value("${visitor.similarity.product.limit:10}")
    private int VISITOR_SIMILARITY_LIMIT;

    private static final String VISITOR_SIMIALRITY_BQ = "attribute_isfocus:1^1000 attribute_isassured:1^700 attribute_hasexclusive:1^300";

    @Autowired
    private VisitorDataViewRepository visitorDataViewRepository;

    @PostConstruct
    public void postConst() {

        Set<Map.Entry<String, String>> entrySet = SimilarityProperties.getProperties().entrySet();
        for (Map.Entry<String, String> entry : entrySet) {
            String key = entry.getKey();
            String value = entry.getValue();
            if (key.startsWith("product.similarity.include.rule.attrs") && !Strings.isNullOrEmpty(value)) {
                String[] split = key.split("\\.");
                Integer taxonomyId = Integer.parseInt(split[split.length - 1]);
                productIncludeDocs.put(taxonomyId, Arrays.asList(value.split("\\|\\|")));
            } else if (key.startsWith("product.similarity.exclude.rule.attrs") && !Strings.isNullOrEmpty(value)) {
                String[] split = key.split("\\.");
                Integer taxonomyId = Integer.parseInt(split[split.length - 1]);
                productsExcludeDocs.put(taxonomyId, Arrays.asList(value.split("\\|\\|")));
            } else if (key.startsWith("product.similarity.boosting.rule.attrs") && !Strings.isNullOrEmpty(value)) {
                String[] split = key.split("\\.");
                Integer taxonomyId = Integer.parseInt(split[split.length - 1]);
                productsBoostingDocs.put(taxonomyId,
                        Arrays.stream(value.split("\\|\\|")).collect(Collectors.toMap(e -> e.split("\\^")[0], e -> Integer.parseInt(e.split("\\^")[1]))));
            } else if (key.startsWith("visitor.similarity.include.rule.attrs") && !Strings.isNullOrEmpty(value)) {
                String[] split = key.split("\\.");
                Integer taxonomyId = Integer.parseInt(split[split.length - 1]);
                visitorIncludeDocs.put(taxonomyId, Arrays.asList(value.split("\\|\\|")));
            } else if (key.startsWith("visitor.similarity.exclude.rule.attrs") && !Strings.isNullOrEmpty(value)) {
                String[] split = key.split("\\.");
                Integer taxonomyId = Integer.parseInt(split[split.length - 1]);
                visitorExcludeDocs.put(taxonomyId, Arrays.asList(value.split("\\|\\|")));
            } else if (key.startsWith("visitor.similarity.boosting.rule.attrs") && !Strings.isNullOrEmpty(value)) {
                String[] split = key.split("\\.");
                Integer taxonomyId = Integer.parseInt(split[split.length - 1]);
                visitorBoostingDocs.put(taxonomyId,
                        Arrays.stream(value.split("\\|\\|")).collect(Collectors.toMap(e -> e.split("\\^")[0], e -> Integer.parseInt(e.split("\\^")[1]))));
            }
        }
    }

    @Override
    public SimilarProductsResponse getSimilarProducts(SimilarProductsRequest request) {

        SimilarProductsResponse response = new SimilarProductsResponse();
        int taxonomyId = request.getCategoryId();
        String sqyId = taxonomyId == 1 ? request.getProjectId() : request.getPropertyId();

        try {
            String groupId = sqyId + "_" + taxonomyId + "_group";
            SolrQuery solrQuery = createSolrQueryProjectSimilarity(taxonomyId, groupId, false);
            QueryResponse filteredGroupIds = search(Constants.SOLR_ONLINE_COLLECTION, solrQuery);
            if (filteredGroupIds == null || filteredGroupIds.getResults().getNumFound() == 0) {
                solrQuery = createSolrQueryProjectSimilarity(taxonomyId, groupId, true);
                filteredGroupIds = search(Constants.SOLR_ONLINE_COLLECTION, solrQuery);
            }
            if (filteredGroupIds != null) {
                List<String> resultIds = filteredGroupIds.getResults().stream().filter(doc -> !groupId.equals(doc.getFieldValue("group_id").toString()))
                        .map(doc -> doc.getFieldValue("group_id").toString().split("_")[taxonomyId == 4 ? 1 : 0]).distinct().limit(PRODUCT_SIMILARITY_LIMIT)
                        .collect(Collectors.toList());

                if (request.getCategoryId() == 1) {
                    response.setSimilarProjectIds(resultIds != null ? resultIds : new ArrayList<>());
                } else {
                    response.setSimilarPropertyIds(resultIds != null ? resultIds : new ArrayList<>());
                }
                return response;
            }
        } catch (Exception e) {
            log.error("error ", e);
        }

        if (request.getCategoryId() == 1) {
            response.setSimilarProjectIds(new ArrayList<>());
        } else {
            response.setSimilarPropertyIds(new ArrayList<>());
        }
        return response;

    }

    private SolrQuery createSolrQueryProjectSimilarity(int taxonomyId, String incGroupId, boolean isExtendPriceRange) {

        String childFilter = "";
        SolrQuery similarDocsQuery = new SolrQuery("*:*");
        similarDocsQuery.set("defType", "edismax");
        similarDocsQuery.addFilterQuery("taxonomy_id: " + taxonomyId);
        similarDocsQuery.addFilterQuery("{!parent which=\"doc_type:parent\"}");
        similarDocsQuery.addField("group_id");
        if (!Strings.isNullOrEmpty(incGroupId)) {
            List<String> filterCriteria = new ArrayList<>();
            SolrQuery incomingDocQuery = new SolrQuery("*");
            incomingDocQuery.addFilterQuery("group_id:" + incGroupId);
            incomingDocQuery.addFilterQuery("{!parent which=\"doc_type:parent\"}");
            incomingDocQuery.addField("*,[child parentFilter=doc_type:parent limit=100]");
            QueryResponse queryResponse = search(Constants.SOLR_ONLINE_COLLECTION, incomingDocQuery);
            SolrDocument incomingDocument = queryResponse.getResults().get(0);
            if (incomingDocument != null) {
                if (productIncludeDocs.containsKey(taxonomyId)) {
                    for (String at : productIncludeDocs.get(taxonomyId)) {
                        if (incomingDocument.containsKey(at)) {
                            if ("price".equalsIgnoreCase(at)) {
                                int priceRange = isExtendPriceRange ? PRICE_RANGE + PRICE_RANGE_EXTENDED : PRICE_RANGE;
                                childFilter = createPriceRangeQuery(similarDocsQuery, incomingDocument, priceRange);
                            } else {
                                Object next = incomingDocument.getFieldValues(at).iterator().next();
                                filterCriteria.add(String.format("%s:\"%s\"", at, next.toString()));
                            }
                        }
                    }
                }
                if (productsExcludeDocs.containsKey(taxonomyId)) {
                    for (String at : productsExcludeDocs.get(taxonomyId)) {
                        if (incomingDocument.containsKey(at)) {
                            Object next = incomingDocument.getFieldValues(at).iterator().next();
                            filterCriteria.add(String.format("-%s:\"%s\"", at, next.toString()));
                        }
                    }
                }
                if (productsBoostingDocs.containsKey(taxonomyId)) {
                    StringBuilder bqQuery = new StringBuilder();
                    for (Map.Entry<String, Integer> at : productsBoostingDocs.get(taxonomyId).entrySet()) {
                        if (incomingDocument.containsKey(at.getKey())) {
                            bqQuery.append(" " + at.getKey() + ":" + incomingDocument.getFieldValues(at.getKey()).iterator().next() + "^=" + at.getValue() + " ");
                        }
                    }
                    if (bqQuery.length() != 0) {
                        similarDocsQuery.add("bq", bqQuery.toString());
                    }
                }
                filterCriteria.forEach(e -> similarDocsQuery.addFilterQuery(e));
            }
        }
        if (taxonomyId != 1) {
            similarDocsQuery.addFilterQuery("attribute_dt_range_expireddate:[NOW TO  *]");
        }
        similarDocsQuery.setRows(PRODUCT_SIMILARITY_LIMIT);
        similarDocsQuery.setFields(PRODUCT_SIMILARITY_FL + ",[child parentFilter=doc_type:parent " + childFilter + "]");
        return similarDocsQuery;
    }

    private String createPriceRangeQuery(SolrQuery similarDocsQuery, SolrDocument incomingDocument, int priceRange) {

        try {
            List<Double> priceList = new ArrayList<>();
            if (incomingDocument.hasChildDocuments()) {
                incomingDocument.getChildDocuments().forEach(variants -> {
                    if (variants.get("retailer_price") != null) {
                        priceList.add(Double.parseDouble(variants.get("retailer_price").toString()));
                    }
                });
                Collections.sort(priceList);

                if (!priceList.isEmpty()) {
                    Double lowPrice = priceList.get(0);
                    Double highPrice = priceList.get(priceList.size() - 1);
                    if (lowPrice.compareTo(1d) > 0 && highPrice.compareTo(1d) > 0) {
                        Double upperPrice = highPrice + highPrice * priceRange / 100;
                        Double lowerPrice = lowPrice - lowPrice * priceRange / 100;
                        similarDocsQuery.addFilterQuery("{!parent which=\"doc_type:parent\"}(retailer_price:[" + lowerPrice + " TO " + upperPrice + "])");
                        log.info("price filter " + lowerPrice + " , " + upperPrice);
                        return "childFilter=\"retailer_price:[" + lowerPrice + " TO " + upperPrice + "]\" ";
                    }
                }
            }
        } catch (Exception e) {
            log.error("Error -> ", e);
        }
        return "";
    }

    @Override
    public SimilarProductsResponse getVisitorSimilarity(SimilarProductsRequest request) {

        Integer taxonomyId = request.getCategoryId();
        String groupId = taxonomyId == 1 ? request.getProjectId() : request.getPropertyId();
        SimilarProductsResponse response = new SimilarProductsResponse();

        try {
            List<VisitorDataView> visitorCategoryFVList = visitorDataViewRepository.findGroupedVisitorClicks(groupId + "_" + taxonomyId + "_group", taxonomyId);
            if (visitorCategoryFVList != null && !visitorCategoryFVList.isEmpty()) {

                Map<String, Integer> groupIdsCount = visitorCategoryFVList.stream().map(VisitorDataView::getGroupIdList).flatMap(Set::stream)
                        .collect(Collectors.toMap(vo -> vo, vo -> 1, (a, b) -> a + b));

                List<String> groupIds = groupIdsCount.entrySet().stream().sorted((ent1, ent2) -> ent2.getValue() - ent1.getValue()).map(Map.Entry::getKey).collect(Collectors.toList());
                SolrQuery query = createSolrQueryVisitorSimilarity(taxonomyId, groupId + "_" + taxonomyId + "_group", groupIds, true);
                QueryResponse queryResponse = search(Constants.SOLR_ONLINE_COLLECTION, query);
                if (queryResponse == null || queryResponse.getResults().getNumFound() == 0) {
                    query = createSolrQueryVisitorSimilarity(taxonomyId, groupId + "_" + taxonomyId + "_group", groupIds, false);
                    queryResponse = search(Constants.SOLR_ONLINE_COLLECTION, query);
                }
                if (queryResponse != null) {
                    List<String> resultIds = queryResponse.getResults().stream()
                            .map(doc -> doc.getFieldValue("group_id").toString().split("_")[taxonomyId == 4 ? 1 : 0]).filter(gid -> !groupId.equals(gid)).distinct()
                            .limit(VISITOR_SIMILARITY_LIMIT).collect(Collectors.toList());

                    if (request.getCategoryId() == 1) {
                        response.setSimilarProjectIds(resultIds != null ? resultIds : new ArrayList<>());
                    } else {
                        response.setSimilarPropertyIds(resultIds != null ? resultIds : new ArrayList<>());
                    }
                    return response;
                }
            }
        } catch (Exception e) {
            log.error("error ", e);
        }

        if (request.getCategoryId() == 1) {
            response.setSimilarProjectIds(new ArrayList<>());
        } else {
            response.setSimilarPropertyIds(new ArrayList<>());
        }
        return response;
    }

    private SolrQuery createSolrQueryVisitorSimilarity(int taxonomyId, String
            incGroupId, List<String> similarGroupList, boolean useEntendedPricePercent) {

        String childFilter = "";
        SolrQuery similarDocsQuery = new SolrQuery("*:*");
        similarDocsQuery.set("defType", "edismax");
        similarDocsQuery.addFilterQuery("taxonomy_id: " + taxonomyId);
        similarDocsQuery.addFilterQuery("{!parent which=\"doc_type:parent\"}");
        similarDocsQuery.addField("group_id");
        StringBuilder query = new StringBuilder("group_id:(");
        if (similarGroupList != null && !similarGroupList.isEmpty()) {
            List<String> partition = Lists.partition(similarGroupList, VISITOR_SIMILARITY_LIMIT * 4).get(0);
            similarDocsQuery.addFilterQuery("group_id:(" + String.join(" OR ", partition) + ")");
            int boostMax = partition.size() * 100;
            for (String gid : partition) {
                query.append("\"" + gid + "\"" + "^=" + boostMax + " ");
                boostMax -= 100;
            }
            query.append(")");
            similarDocsQuery.set("bq", VISITOR_SIMIALRITY_BQ + " " + query);
        }
        if (!Strings.isNullOrEmpty(incGroupId)) {
            List<String> filterCriteria = new ArrayList<>();
            SolrQuery incomingDocQuery = new SolrQuery("*");
            incomingDocQuery.addFilterQuery("group_id:" + incGroupId);
            incomingDocQuery.addFilterQuery("{!parent which=\"doc_type:parent\"}");
            incomingDocQuery.addField("*,[child parentFilter=doc_type:parent limit=100]");
            QueryResponse queryResponse = search(Constants.SOLR_ONLINE_COLLECTION, incomingDocQuery);
            SolrDocument incomingDocument = queryResponse.getResults().get(0);
            if (incomingDocument != null) {
                if (visitorIncludeDocs.containsKey(taxonomyId)) {
                    for (String at : visitorIncludeDocs.get(taxonomyId)) {
                        if (incomingDocument.containsKey(at)) {
                            if ("price".equalsIgnoreCase(at)) {
                                int priceRange = useEntendedPricePercent ? PRICE_RANGE + PRICE_RANGE_EXTENDED : PRICE_RANGE;
                                childFilter = createPriceRangeQuery(similarDocsQuery, incomingDocument, priceRange);
                            } else {
                                Object next = incomingDocument.getFieldValues(at).iterator().next();
                                filterCriteria.add(String.format("%s:\"%s\"", at, next.toString()));
                            }
                        }
                    }
                }
                if (visitorExcludeDocs.containsKey(taxonomyId)) {
                    for (String at : visitorExcludeDocs.get(taxonomyId)) {
                        if (incomingDocument.containsKey(at)) {
                            Object next = incomingDocument.getFieldValues(at).iterator().next();
                            filterCriteria.add(String.format("-%s:\"%s\"", at, next.toString()));
                        }
                    }
                }
                filterCriteria.forEach(e -> similarDocsQuery.addFilterQuery(e));
            }
        }
        similarDocsQuery.setRows(VISITOR_SIMILARITY_LIMIT);
        similarDocsQuery.setFields(VISITOR_SIMILARITY_FL + ",[child parentFilter=doc_type:parent " + childFilter + "]");
        return similarDocsQuery;
    }
}
