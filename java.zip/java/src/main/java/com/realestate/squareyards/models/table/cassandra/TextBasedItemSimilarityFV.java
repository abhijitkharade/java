package com.realestate.squareyards.models.table.cassandra;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import java.util.Date;
import java.util.List;

@Table(Constants.TEXT_BASED_ITEM_SIMILARITY_FV_TABLE)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TextBasedItemSimilarityFV {

    @PrimaryKey
    private TextBasedItemSimilarityFVKey textBasedItemSimilarityFVKey;

    @Column(Constants.COLUMN_CREATED_TS)
    private Date createdTs;

    @Column(Constants.COLUMN_MODIFIED_TS)
    private Date modifiedTs;

    @Column(Constants.COLUMN_STATUS)
    private String status;

    @Column(Constants.COLUMN_VECTOR)
    private List<Double> vector;
}
