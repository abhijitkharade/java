package com.realestate.squareyards.models.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ImpressionBasedResponse {

    @ApiModelProperty(example = "[{'propertyId':'3043508','userName':'Chandhini','requirementType':'Available','listingType':'Sale','buildingType':'Residential'}]")
    private List<Object> hits;

    @ApiModelProperty(example = "100")
    private long responseTime;

}
