package com.realestate.squareyards.models.table.mysql;

import com.realestate.squareyards.utils.Constants;
import com.realestate.squareyards.utils.JsonToSetConverter;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.Set;

@Data
@Entity
@Table(name = Constants.VISITOR_DATE_VIEW_TABLE)
@AllArgsConstructor
@NoArgsConstructor
public class VisitorDataView implements Serializable {

    @EmbeddedId
    private VisitorDataViewKey visitorDataViewKey;

    @Column(name = Constants.COLUMN_GROUP_ID_LIST, columnDefinition = "json")
    @Convert(converter = JsonToSetConverter.class)
    private Set<String> groupIdList;

    @Column(name = Constants.COLUMN_STATUS)
    private String status;

    @Column(name = Constants.COLUMN_MODIFIED_TS)
    private Date modifiedTs;

    @Column(name = Constants.COLUMN_CREATED_TS)
    private Date createdTs;

}
