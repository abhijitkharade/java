package com.realestate.squareyards.models.request.similarity;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Map;

@Data
public class RTUSRead {

    @NotNull
    @ApiModelProperty(example = "d46325a87954cca2", required = true)
    @JsonProperty("visitor_id")
    private String visitorId;

    @NotNull
    @ApiModelProperty(example = "1/2/3/4", required = true)
    @JsonProperty("category_id")
    private int categoryId = 0;

    @ApiModelProperty(example = "{'city':['mumbai']}", required = false)
    @JsonProperty("filters")
    private Map<String, List<Object>> filters;

    @ApiModelProperty(example = "['100','101']", required = false)
    @JsonProperty("visited_property")
    private List<String> visitedProperty;
}
