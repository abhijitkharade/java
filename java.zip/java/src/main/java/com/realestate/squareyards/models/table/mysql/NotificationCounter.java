package com.realestate.squareyards.models.table.mysql;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;

@Data
@Entity
@Table(name = Constants.NOTIFICATION_COUNTER_TABLE)
@AllArgsConstructor
@NoArgsConstructor
public class NotificationCounter {

    @EmbeddedId
    private NotificationCounterKey notificationCounterKey;

    @Column(name = Constants.COLUMN_NOTIFICATIONS_SENT)
    private Long notificationsSent;

    @Column(name = Constants.COLUMN_NOTIFICATIONS_OPENED)
    private Long notificationsOpened;

    @Column(name = Constants.COLUMN_CREATED_TS)
    private Date createdTs;

    @Column(name = Constants.COLUMN_MODIFIED_TS)
    private Date modifiedTs;
}
