package com.realestate.squareyards.models.table.cassandra;

import com.realestate.squareyards.models.request.dealgenie.DGSaveProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import java.util.Date;

@Table("ag_requirement_not_intrested")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AgRequirementNotIntrested {

    @PrimaryKey
    private AgRequirementNotIntrestedKey agRequirementNotIntrestedKey;

    @Column("created_ts")
    private Date createdTs;

    @Column("modified_ts")
    private Date modifiedTs;

    @Column("status")
    private String status;

    public AgRequirementNotIntrested(DGSaveProperty save) {

        agRequirementNotIntrestedKey = new AgRequirementNotIntrestedKey();
        agRequirementNotIntrestedKey.setAgentId(save.getAgentId());
        agRequirementNotIntrestedKey.setRequirementId(save.getRequirementId());
        agRequirementNotIntrestedKey.setNotIntrestedId(save.getPropertyId());
        createdTs = new Date();
        modifiedTs = new Date();
        status = save.getStatus().name();

    }
}
