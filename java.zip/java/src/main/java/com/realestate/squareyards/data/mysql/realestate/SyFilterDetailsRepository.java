package com.realestate.squareyards.data.mysql.realestate;

import com.realestate.squareyards.models.table.mysql.SyFiltersDetails;
import com.realestate.squareyards.models.table.mysql.SyFiltersDetailskey;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface SyFilterDetailsRepository extends CrudRepository<SyFiltersDetails, SyFiltersDetailskey> {

    List<SyFiltersDetails> findAllByFilterKeyAndStatusAndKeyCityId(String filterKey, String status, String cityId);

    List<SyFiltersDetails> findAllByFilterKeyAndStatusAndKeyCityIdAndKeyCategoryId(String filterKey, String status, String cityId, int categoryId);

    List<SyFiltersDetails> findAllByFilterParentNameAndStatusAndKeyCityIdAndKeyCategoryId(String parentFilterName, String status, String cityId, int categoryId);

    @Query(value = "SELECT DISTINCT label_display_name, category_id, tattr_filter FROM realestate_squareyards.sy_filter_details WHERE label_display_name is not null", nativeQuery = true)
    List<Object[]> getDisplayLabels();

    List<SyFiltersDetails> findAllByKeyCategoryIdAndKeyCityIdAndKeyFilterIdInAndUrlKey(int categoryId, String cityId, List<String> filterIds, String urlKey);

    List<SyFiltersDetails> findAllByKeyCategoryIdAndKeyCityIdAndKeyFilterNameInAndUrlKey(int categoryId, String cityId, List<String> filterNames, String urlKey);

    SyFiltersDetails findFirstByKeyCategoryIdAndKeyFilterName(int categoryId, String filterName);

    @Query(value = "SELECT * FROM realestate_squareyards.sy_filter_details where category_id=1 and filter_key='LANDMARK' and status='ACTIVE' and city_id= ?1 order by filter_name limit 200", nativeQuery = true)
    List<SyFiltersDetails> findLandmarks(String cityId);

    SyFiltersDetails findFirstByKeyFilterNameAndKeyCategoryIdAndFilterKey(String finterName, int categoryId, String filterKey);

}
