package com.realestate.squareyards.models.Entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FirebaseNote {
    private String subject;
    private String content;
    private Map<String, String> data = new HashMap<>();
    private String image;
}
