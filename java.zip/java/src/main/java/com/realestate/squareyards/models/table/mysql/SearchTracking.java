package com.realestate.squareyards.models.table.mysql;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Data
@Entity
@Table(name = Constants.SEARCH_TRACKING_TABLE)
@AllArgsConstructor
@NoArgsConstructor
public class SearchTracking implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = Constants.COLUMN_SEARCH_ID)
    private Integer searchId;

    @Column(name = Constants.COLUMN_VISIT_ID)
    private String visitId;

    @Column(name = Constants.COLUMN_TYPED_KEYWORD)
    private String typedKeyword;

    @Column(name = Constants.COLUMN_SUGGESTED_KEYWORD)
    private String suggestedKeyword;

    @Column(name = Constants.COLUMN_CITY)
    private String city;

    @Column(name = Constants.COLUMN_CATEGORY_NAME)
    private String categoryName;

    @Column(name = Constants.COLUMN_SEARCH_URL)
    private String searchUrl;

    @Column(name = Constants.COLUMN_CREATED_TS)
    private Date createdTs;

    @Column(name = Constants.COLUMN_EVENT_TS)
    private Date eventTs;

}
