package com.realestate.squareyards.models.response.recent_activity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Slf4j
@NoArgsConstructor
public class CountResponse {

    @ApiModelProperty(example = "45")
    @JsonProperty("clickCount")
    private Long clickCount;

    @ApiModelProperty(example = "1")
    @JsonProperty("enquiredCount")
    private Long enquiredCount;

    @ApiModelProperty(example = "12")
    @JsonProperty("shortlistedCount")
    private Long shortlistedCount;

    @ApiModelProperty(example = "20")
    @JsonProperty("searchCount")
    private Long searchCount;

    public CountResponse(Long click, Long enquired, Long shortlisted, Long search) {
        this.clickCount = click;
        this.enquiredCount = enquired;
        this.searchCount = search;
        this.shortlistedCount = shortlisted;
    }
}
