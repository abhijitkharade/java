package com.realestate.squareyards.data.cassandra.realestate;

import com.realestate.squareyards.models.table.cassandra.VisitedCities;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;

public interface VisitedCitiesRepository extends CassandraRepository<VisitedCities, String> {

    @Query("select * from realestate_squareyards.visited_cities where visitor_id in ?0")
    public List<VisitedCities> findCitiesByVisitorId(List<String> visitorId);
}
