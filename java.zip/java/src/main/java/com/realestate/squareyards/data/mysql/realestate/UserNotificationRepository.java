package com.realestate.squareyards.data.mysql.realestate;

import com.realestate.squareyards.models.table.mysql.UserNotification;
import com.realestate.squareyards.models.table.mysql.UserNotificationKey;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Nullable;
import java.util.List;

public interface UserNotificationRepository extends CrudRepository<UserNotification, UserNotificationKey> {

    @Nullable
    @Query(value = "select *" + " from (select *, " + "row_number() over (partition by visitor_id order by modified_ts asc ) as rowno "
            + "from user_notification where notification_sent = 0 and delivery_status= 0 and notification_type = ?1 and subscription_type = ?3 limit ?2) o where rowno = 1", nativeQuery = true)
    List<UserNotification> readPushNotification(String notificationType, int limitNumber, String subscriptionType);

    @Modifying
    @Transactional
    @Query(value = "update realestate_squareyards.user_notification un  set notification_sent = 1 where visitor_id= ?1 and id = ?2 ", nativeQuery = true)
    void updateNotificationSentByVisitId(String visitorId, String id);

//    @Modifying
//    @Transactional
//    @Query(value = "UPDATE matomo.matomo_log_conversion SET notification_status = notification_status+1 WHERE idvisit = ?1 AND idgoal = ?3 AND idsite=?2 AND buster = 0", nativeQuery = true)
//    void updateNotificationByVisitorIdFromMatomo(String visitId, String siteId, String goalId);

    @Nullable
    @Query(value = "select * from user_notification where  visitor_id=?1 and id=?2 order by modified_ts desc limit 1", nativeQuery = true)
    UserNotification findByVisitorIdAndGoalIdAndGoalUUID(String visitorId, String id);
}
