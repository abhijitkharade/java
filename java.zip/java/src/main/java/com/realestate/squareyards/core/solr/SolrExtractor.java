package com.realestate.squareyards.core.solr;

import lombok.extern.slf4j.Slf4j;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

public interface SolrExtractor {

    JSONArray extractJsonDoc(QueryResponse response);
}

@Component
@Slf4j
class ISolrExtractor implements SolrExtractor {

    public JSONArray extractJsonDoc(QueryResponse response) {
        JSONArray resultDocs = new JSONArray();
        response.getResults().forEach(entries -> {
            JSONObject doc = new JSONObject();
            entries.forEach((k, v) -> doc.put(k, v));
            resultDocs.put(doc);
        });
        log.info(resultDocs.toString());
        return resultDocs;
    }
}
