package com.realestate.squareyards.data.cassandra.realestate;

import com.realestate.squareyards.models.table.cassandra.EventSearchTracking;
import com.realestate.squareyards.models.table.cassandra.EventSearchTrackingKey;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

import java.util.List;

public interface EventSearchTrackingRepository extends CassandraRepository<EventSearchTracking, EventSearchTrackingKey> {
    List<EventSearchTracking> findByEventSearchTrackingKeyCategoryNameInAndEventSearchTrackingKeyVisitorIdInAndEventSearchTrackingKeyCityIn(List<String> categories,
                                                                                                                                            List<String> visitorId, List<String> city);

    @Query("SELECT * from event_search_tracking where category_name in ?0 and visitor_id in ?1  and city in  ?2 and search_id in ?3")
    Slice<EventSearchTracking> findByUniqueData(List<String> categories, List<String> visitorId, List<String> city, List<String> searchId, Pageable pageable);

}
