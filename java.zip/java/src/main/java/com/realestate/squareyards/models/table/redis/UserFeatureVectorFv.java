package com.realestate.squareyards.models.table.redis;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

import java.io.Serializable;
import java.util.List;

@RedisHash("UserFeatureVectorFv")
@Data
public class UserFeatureVectorFv implements Serializable {
    @Id
    private String visitorId;

    private List<Double> userFeatureVector;

}
