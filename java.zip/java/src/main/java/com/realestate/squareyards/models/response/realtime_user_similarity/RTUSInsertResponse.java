package com.realestate.squareyards.models.response.realtime_user_similarity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Slf4j
public class RTUSInsertResponse {

    @ApiModelProperty(example = "success")
    @JsonProperty("message")
    private String message;

    public RTUSInsertResponse(String message) {
        this.message = message;
    }
}
