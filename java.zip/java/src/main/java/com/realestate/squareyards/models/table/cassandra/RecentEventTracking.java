package com.realestate.squareyards.models.table.cassandra;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import java.util.Date;

@Table("recent_event_tracking")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RecentEventTracking {

    @PrimaryKey
    private RecentEventTrackingKey recentEventTrackingKey;

    @Column(Constants.COLUMN_EVENT_TS)
    private Date eventTs;

    @Column(Constants.COLUMN_ID)
    private String id;

}
