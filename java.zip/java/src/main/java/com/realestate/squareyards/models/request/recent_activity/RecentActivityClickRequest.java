package com.realestate.squareyards.models.request.recent_activity;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class RecentActivityClickRequest {

    @ApiModelProperty(example = "1", required = true)
    @JsonProperty("categoryId")
    private String categoryId;

    @ApiModelProperty(example = "2233445577", required = true)
    @JsonProperty("phoneNumber")
    private String phoneNumber;

    @ApiModelProperty(example = "2233445577", required = true)
    @JsonProperty("visitorId")
    private String visitorId;

    @NotNull
    @ApiModelProperty(example = "5", required = true)
    @JsonProperty("pageSize")
    private Integer pageSize = 5;

    @NotNull
    @ApiModelProperty(example = "1", required = true)
    @JsonProperty("pageNumber")
    private Integer pageNumber;
}
