package com.realestate.squareyards.data.cassandra.realestate;

import com.realestate.squareyards.models.table.cassandra.EventCounterTrendingProperty;
import com.realestate.squareyards.models.table.cassandra.EventCounterTrendingPropertyKey;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;

public interface EventCounterTrendingPropertyRepository extends CassandraRepository<EventCounterTrendingProperty, EventCounterTrendingPropertyKey> {

    @Query("select * from event_counter_trending_property where event_date = ?3 and category_name = ?2 and city= ?1 limit ?0 ")
    List<EventCounterTrendingProperty> readTrendingProperties(Integer limit, String city, String categoryName, String date);

}
