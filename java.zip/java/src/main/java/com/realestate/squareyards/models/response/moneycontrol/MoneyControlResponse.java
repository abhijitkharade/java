package com.realestate.squareyards.models.response.moneycontrol;

import com.realestate.squareyards.models.request.moneycontrol.MoneyControlRequest;
import com.realestate.squareyards.models.table.cassandra.WidgetMaster;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MoneyControlResponse {

    @ApiModelProperty(example = "mumbai")
    private String city;
   @ApiModelProperty(example = "most_expensive_projects")
    private String widget;

    private List<Tab> tabs=new ArrayList<Tab>();


    public MoneyControlResponse(List<WidgetMaster>widgetMasters, MoneyControlRequest req){
        this.city=widgetMasters.get(0).getWidgetMasterKey().getCity();
        this.widget=widgetMasters.get(0).getWidgetMasterKey().getWidget();

        for (String tabName:req.getTabs() ) {
            List<WidgetMaster> tabObj =widgetMasters.stream().filter(e->e.getWidgetMasterKey().getTab().equals(tabName)).collect(Collectors.toList());

            this.tabs.add(new Tab(tabObj,req,tabName));
        }

    }


}
@Data
@NoArgsConstructor
@AllArgsConstructor
class Tab{
    @ApiModelProperty(example = "government_registered_value")
   private String tab;
    private List<Category> categories=new ArrayList<Category>();

    public Tab(List<WidgetMaster> tabObj,MoneyControlRequest req,String tabName){
        try {

            this.tab=tabObj.get(0).getWidgetMasterKey().getTab();
        } catch (Exception e) {
            e.printStackTrace();
            this.tab=tabName;
            return;
        }

        for (String categoryName:req.getCategories() ) {

                List<WidgetMaster> catObj =tabObj.stream().filter(e->e.getWidgetMasterKey().getCategoryName().equals(categoryName)).collect(Collectors.toList());

                this.categories.add(new Category(catObj,req,categoryName));

        }


    }
}

@Data
@NoArgsConstructor
@AllArgsConstructor
class Category{
    @ApiModelProperty(example = "new_sale")
    private  String category;
    private List<AggregationFrom> aggregationFromList=new ArrayList<AggregationFrom>();


        public Category(List<WidgetMaster> catObj,MoneyControlRequest req,String categoryName){

            try {
                this.category=catObj.get(0).getWidgetMasterKey().getCategoryName();
            } catch (Exception e) {
                this.category=categoryName;
                return;
            }

            for (String aggregationFrom:req.getAggregationFromList() ) {
                List<WidgetMaster> aggregationObj =catObj.stream().filter(e->e.getWidgetMasterKey().getAggregationFrom().equals(aggregationFrom)).collect(Collectors.toList());

                    this.aggregationFromList.add(new AggregationFrom(aggregationObj,aggregationFrom));

            }
        }
}

@Data
@NoArgsConstructor
@AllArgsConstructor
class AggregationFrom{
    @ApiModelProperty(example = "3 months")
    private String aggregationFrom;
    private List<Detail> detailList=new ArrayList<Detail>();

    public AggregationFrom(List<WidgetMaster> widgetMaster, String aggregationFrom){

        try {
            this.aggregationFrom=widgetMaster.get(0).getWidgetMasterKey().getAggregationFrom();
        } catch (Exception e) {
            this.aggregationFrom=aggregationFrom;
            return;
        }

        for(WidgetMaster detail:widgetMaster){

            this.detailList.add(new Detail(detail));
        }
    }
}
@Data
@NoArgsConstructor
@AllArgsConstructor
class Detail{
    @ApiModelProperty(example = "RESIDENTIAL")
    private String assetType;

    @ApiModelProperty(example = "70159.6")
    private String avgRate;

    @ApiModelProperty(example = "515.82")
    private String changePercentage;

    @ApiModelProperty(example = "2022-07-29")
    private LocalDate createdTs;

    @ApiModelProperty(example = "Prabhadevi")
    private String location;

    @ApiModelProperty(example = "20")
    private String noOfTransactions;

    @ApiModelProperty(example = "Wadhwa 25 South")
    private String projectName;

    @ApiModelProperty(example = "PRIMARY")
    private String transactionCategory;

    @ApiModelProperty(example = "SALE")
    private String transactionType;

    public Detail(WidgetMaster widgetMaster){
        this.assetType = widgetMaster.getAssetType();
        this.avgRate = widgetMaster.getAvgRate();
        this.changePercentage = widgetMaster.getChangePercentage();
        this.createdTs = widgetMaster.getCreatedTs();
        this.location = widgetMaster.getLocation();
        this.noOfTransactions = widgetMaster.getNoOfTransactions();
        this.projectName = widgetMaster.getProjectName();
        this.transactionCategory = widgetMaster.getTransactionCategory();
        this.transactionType = widgetMaster.getTransactionType();
    }
}