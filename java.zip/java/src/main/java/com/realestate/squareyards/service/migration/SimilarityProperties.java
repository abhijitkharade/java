package com.realestate.squareyards.service.migration;

import java.util.HashMap;
import java.util.Map;

public class SimilarityProperties {

    private SimilarityProperties() {

    }

    static Map<String, String> propertyMap = new HashMap<>();

    static {
        propertyMap.put("product.similarity.include.rule.attrs.1", "attribute_city||price||attribute_flattype||attribute_sublocation");
        propertyMap.put("product.similarity.include.rule.attrs.2", "attribute_cityname||price||attribute_unittype||attribute_sublocalityname");
        propertyMap.put("product.similarity.include.rule.attrs.3", "attribute_cityname||price||attribute_unittype||attribute_sublocalityname");
        propertyMap.put("product.similarity.include.rule.attrs.4", "");

        propertyMap.put("product.similarity.exclude.rule.attrs.1", "");
        propertyMap.put("product.similarity.exclude.rule.attrs.2", "");
        propertyMap.put("product.similarity.exclude.rule.attrs.3", "");
        propertyMap.put("product.similarity.exclude.rule.attrs.4", "");

        propertyMap.put("product.similarity.boosting.rule.attrs.1", "attribute_sublocation^10000");
        propertyMap.put("product.similarity.boosting.rule.attrs.2", "attribute_sublocalityname^10000");
        propertyMap.put("product.similarity.boosting.rule.attrs.3", "attribute_sublocalityname^10000");

        propertyMap.put("visitor.similarity.include.rule.attrs.1", "attribute_city||price");
        propertyMap.put("visitor.similarity.include.rule.attrs.2", "attribute_cityname||price");
        propertyMap.put("visitor.similarity.include.rule.attrs.3", "attribute_cityname||price");
        propertyMap.put("visitor.similarity.include.rule.attrs.4", "");

        propertyMap.put("visitor.similarity.exclude.rule.attrs.1", "");
        propertyMap.put("visitor.similarity.exclude.rule.attrs.2", "");
        propertyMap.put("visitor.similarity.exclude.rule.attrs.3", "");
        propertyMap.put("visitor.similarity.exclude.rule.attrs.4", "");
    }

    public static Map<String, String> getProperties() {
        return propertyMap;
    }

}
