package com.realestate.squareyards.data.mysql.realestate;

import com.realestate.squareyards.models.table.mysql.UserData;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import javax.annotation.Nullable;
import java.util.List;

public interface UserDataRepository extends CrudRepository<UserData, String> {

    @Nullable
    @Query(value = "select visit_id from user_data where visitor_id in ?1", nativeQuery = true)
    List<String> readVisitIds(List<String> visitorId);

}
