package com.realestate.squareyards.data.mysql.realestate;

import com.realestate.squareyards.models.table.mysql.PushSubscription;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface PushSubscriptionRepository extends CrudRepository<PushSubscription, String> {

    @Query(value = "select *  from realestate_squareyards.push_subscription where visitorid in ?1 and subscription_type = ?2  ", nativeQuery = true)
    List<PushSubscription> findByVisitorIdInAndSubscriptionType(List<String> visitorIds, String subscriptionType);

}
