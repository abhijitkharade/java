package com.realestate.squareyards.config.database;

import com.datastax.driver.core.Cluster;
import com.realestate.squareyards.utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.data.cassandra.config.CassandraSessionFactoryBean;
import org.springframework.data.cassandra.config.SchemaAction;
import org.springframework.data.cassandra.core.CassandraTemplate;
import org.springframework.data.cassandra.repository.config.EnableCassandraRepositories;

import javax.annotation.Resource;

@Configuration
@EnableCassandraRepositories(basePackages = "com.realestate.squareyards.data.cassandra.realestate", cassandraTemplateRef = "keyspaceSquareyardsCassandraTemplate")
@DependsOn("cassandraClusterCustom")
public class CassandraConfigRealestateSquareyards {

    @Autowired
    CassandraConfig cassandraConfig;
    @Resource(name = Constants.CLUSTER_PREFIX + "${realestate_squareyards.cluster}")
    Cluster cluster;

    private String keyspace = "realestate_squareyards";

    @Bean("keyspaceSquareyardsSession")
    public CassandraSessionFactoryBean session() {

        CassandraSessionFactoryBean session = new CassandraSessionFactoryBean();
        session.setCluster(cluster);
        session.setKeyspaceName(keyspace);
        session.setConverter(cassandraConfig.converter());
        session.setSchemaAction(SchemaAction.NONE);
        return session;
    }

    @Bean("keyspaceSquareyardsCassandraTemplate")
    public CassandraTemplate cassandraTemplate() {

        return new CassandraTemplate(session().getObject());
    }
}
