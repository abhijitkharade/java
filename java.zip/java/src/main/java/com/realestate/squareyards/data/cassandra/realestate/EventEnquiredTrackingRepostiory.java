package com.realestate.squareyards.data.cassandra.realestate;

import com.realestate.squareyards.models.table.cassandra.EventEnquiredTracking;
import com.realestate.squareyards.models.table.cassandra.EventEnquiredTrackingKey;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

import java.util.List;

public interface EventEnquiredTrackingRepostiory extends CassandraRepository<EventEnquiredTracking, EventEnquiredTrackingKey> {

    @Query("SELECT * from event_enquired_tracking where category_name in ?0 and visitor_id in ?1 and id in ?2")
    Slice<EventEnquiredTracking> findByUniqueData(List<String> categories, List<String> visitorId, List<String> id, Pageable pageable);

}
