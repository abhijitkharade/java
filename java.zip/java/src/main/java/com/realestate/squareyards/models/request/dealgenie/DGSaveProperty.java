package com.realestate.squareyards.models.request.dealgenie;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.realestate.squareyards.utils.Types;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class DGSaveProperty {

    @NotNull
    @ApiModelProperty(example = "agent-123", required = true)
    @JsonProperty("agent_id")
    private String agentId;

    @NotNull
    @ApiModelProperty(example = "ID1234", required = true)
    @JsonProperty("requirement_id")
    private String requirementId;

    @NotNull
    @ApiModelProperty(example = "ID1234", required = true)
    @JsonProperty("property_id")
    private String propertyId;

    @ApiModelProperty(required = false)
    private Types.Statuses status = Types.Statuses.ACTIVE;

    @ApiModelProperty(required = true)
    private Types.DEAL_GENIE_STATUS type;
}
