package com.realestate.squareyards.data.cassandra.realestate;

import com.realestate.squareyards.models.table.cassandra.RecentEventSearchTracking;
import com.realestate.squareyards.models.table.cassandra.RecentEventSearchTrackingKey;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface RecentEventSearchTrackingRepository extends CassandraRepository<RecentEventSearchTracking, RecentEventSearchTrackingKey> {

    long countByRecentEventSearchTrackingKeyCategoryNameInAndRecentEventSearchTrackingKeyVisitorIdInAndRecentEventSearchTrackingKeyCityIn(List<String> categories,
                                                                                                                                          List<String> visitorId, List<String> cities);

    List<RecentEventSearchTracking> findByRecentEventSearchTrackingKeyCategoryNameInAndRecentEventSearchTrackingKeyVisitorIdInAndRecentEventSearchTrackingKeyCityIn(
            List<String> categories, List<String> visitorId, List<String> city);
}
