package com.realestate.squareyards.models.request.moneycontrol;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MoneyControlRequest {
    @NotNull
    @ApiModelProperty(example = "Mumbai", required = true)
    private String city;

    @NotNull
    @ApiModelProperty(example = "most_expensive_projects", required = true)
    private String widget;

    @NotNull
    @ApiModelProperty(example = "['government_registered_value','market_value']", required = true)
    private List<String> tabs;

    @NotNull
    @ApiModelProperty(example = "['new_sale','resale']", required = true)
    private List<String> categories;
    @NotNull
    @ApiModelProperty(example = "['3 months','1 months']", required = true)
    private List<String>aggregationFromList;

    @NotNull
    @ApiModelProperty(example = "5", required = true)
    private Integer priority;
}
