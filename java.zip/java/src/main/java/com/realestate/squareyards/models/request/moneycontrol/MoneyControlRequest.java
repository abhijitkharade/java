package com.realestate.squareyards.models.request.moneycontrol;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MoneyControlRequest {
    private String city;
    private String widget;
    private List<String> tabs;
    private List<String> categories;
    private List<String>aggregationFromList;
    private Integer priority;
}
