package com.realestate.squareyards.models.request.notification;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class BannerInappOpenedRequest {

    @NotNull
    @ApiModelProperty(example = "537AA5BFEB7A8ADC", required = true)
    @JsonProperty("visitorId")
    private String visitorId;

    @ApiModelProperty(example = "99261346566111249 ", required = false)
    @JsonProperty("id")
    private String id;

    @NotNull
    @ApiModelProperty(example = "210", required = true)
    @JsonProperty("goalId")
    private String goalId;

    @NotNull
    @ApiModelProperty(example = "312", required = true)
    @JsonProperty("goalUUID")
    private String goalUUID;

}
