package com.realestate.squareyards.data.mysql.realestate;

import com.realestate.squareyards.models.table.mysql.EnquiryDetailsMysql;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import javax.annotation.Nullable;
import java.util.List;

public interface EnquiryDetailsMysqlRepository extends CrudRepository<EnquiryDetailsMysql, Integer> {

    @Nullable
    @Query(value = "select visitor_id from enquiry_details where phone_number = ?1", nativeQuery = true)
    List<String> findVisitorId(String phoneNumber);

}
