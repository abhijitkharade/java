package com.realestate.squareyards.models.response.dealgenie;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DGInsertResponse {

    @ApiModelProperty(example = "ID1234")
    @JsonProperty("requirement_id")
    private String requirementId;

    public DGInsertResponse() {
        requirementId = "";
    }
}
