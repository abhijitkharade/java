package com.realestate.squareyards.models.request.dealgenie;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.realestate.squareyards.utils.Types;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class DGReadProperties {

    @NotNull
    @ApiModelProperty(example = "agent-123", required = true)
    @JsonProperty("agent_id")
    private String agentId;

    @NotNull
    @ApiModelProperty(example = "ID1234", required = true)
    @JsonProperty("requirement_id")
    private String requirementId;

    @ApiModelProperty(required = true)
    private Types.DEAL_GENIE_STATUS type;

    @ApiModelProperty(example = "1", required = false)
    @JsonProperty("page_number")
    private int pageNumber = 1;

    @ApiModelProperty(example = "10", required = false)
    @JsonProperty("property_count")
    private int propertyCount = 10;
}
