package com.realestate.squareyards.data.cassandra.realestate;

import com.realestate.squareyards.models.table.cassandra.EventCounterTrendingPropertySubLocation;
import com.realestate.squareyards.models.table.cassandra.EventCounterTrendingPropertySubLocationKey;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;

public interface EventCounterTrendingPropertySubLocationRepository extends CassandraRepository<EventCounterTrendingPropertySubLocation, EventCounterTrendingPropertySubLocationKey> {

    @Query("select * from event_counter_trending_property_sub_location where event_date = ?3 and category_name = ?2 and city= ?1 and sub_location_id = ?4 limit ?0 ")
    List<EventCounterTrendingPropertySubLocation> readTrendingPropertiesSubLocation(Integer limit, String city, String categoryName, String date, Integer subLocationId);

}
