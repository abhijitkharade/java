package com.realestate.squareyards.models.table.cassandra;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyClass;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;

@PrimaryKeyClass
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EventClickTrackingKey {

    @PrimaryKeyColumn(name = Constants.COLUMN_CATEGORY_NAME, ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String categoryName;

    @PrimaryKeyColumn(name = Constants.COLUMN_VISITOR_ID, ordinal = 1, type = PrimaryKeyType.PARTITIONED)
    private String visitorId;

    @PrimaryKeyColumn(name = Constants.COLUMN_ID, ordinal = 2, type = PrimaryKeyType.PARTITIONED)
    private String id;
}
