package com.realestate.squareyards.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Converter
public class JsonToMapConverter implements AttributeConverter<Map<String, Object>, String> {

    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public String convertToDatabaseColumn(Map<String, Object> attribute) {

        if (attribute == null) {
            return null;
        }
        try {
            return objectMapper.writeValueAsString(attribute);
        } catch (IOException e) {
            log.info(this.getClass().getName(), "json to map error ", e);
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public Map<String, Object> convertToEntityAttribute(String jsonString) {

        if (jsonString == null) {
            return new HashMap<>();
        }
        try {
            return objectMapper.readValue(jsonString, HashMap.class);
        } catch (IOException e) {
            log.info(this.getClass().getName(), "json to map error ", e);
        }
        return new HashMap<>();

    }
}
