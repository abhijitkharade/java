package com.realestate.squareyards.models.table.cassandra;

import com.realestate.squareyards.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table(Constants.EVENT_COUNTER_TRENDING_KEYWORDS_TABLE)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EventCounterTrendingKeywords {

    @PrimaryKey
    private EventCounterTrendingKeywordsKey key;

    @Column("count")
    private Integer count;
}
