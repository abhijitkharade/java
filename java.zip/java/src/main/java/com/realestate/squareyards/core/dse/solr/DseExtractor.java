package com.realestate.squareyards.core.dse.solr;

import lombok.extern.slf4j.Slf4j;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

public interface DseExtractor {

    JSONArray extractJsonDoc(QueryResponse response);
}

@Component
@Slf4j
class IDseExtractor implements DseExtractor {

    public JSONArray extractJsonDoc(QueryResponse response) {
        JSONArray resultDocs = new JSONArray();
        try {
            if (response != null) {
                response.getResults().forEach(entries -> {
                    JSONObject doc = new JSONObject();
                    entries.forEach((k, v) -> doc.put(k, v));
                    resultDocs.put(doc);
                });
            }
        } catch (Exception e) {
            log.error("Unable to deserialize", e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to deserialize", e);
        }
        return resultDocs;
    }
}
