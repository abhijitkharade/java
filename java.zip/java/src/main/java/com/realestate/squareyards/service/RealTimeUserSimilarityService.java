package com.realestate.squareyards.service;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.realestate.squareyards.core.solr.SolrBaseRepository;
import com.realestate.squareyards.data.cassandra.realestate.TextBasedItemSimilarityFVRepository;
import com.realestate.squareyards.data.cassandra.realestate.VisitorCategoryFVCassandraRepository;
import com.realestate.squareyards.data.mysql.realestate.SqyUnitIdMappingRepository;
import com.realestate.squareyards.data.mysql.realestate.VisitorDataViewRepository;
import com.realestate.squareyards.data.redis.UserFeatureVectorFvRepository;
import com.realestate.squareyards.models.request.similarity.RTUSInsert;
import com.realestate.squareyards.models.request.similarity.RTUSRead;
import com.realestate.squareyards.models.response.realtime_user_similarity.RTUSInsertResponse;
import com.realestate.squareyards.models.response.realtime_user_similarity.RTUSReadResponse;
import com.realestate.squareyards.models.table.cassandra.TextBasedItemSimilarityFV;
import com.realestate.squareyards.models.table.cassandra.TextBasedItemSimilarityFVKey;
import com.realestate.squareyards.models.table.cassandra.VisitorCategoryFVCassandra;
import com.realestate.squareyards.models.table.mysql.SyFiltersDetails;
import com.realestate.squareyards.models.table.mysql.VisitorDataView;
import com.realestate.squareyards.models.table.redis.UserFeatureVectorFv;
import com.realestate.squareyards.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.joda.time.DateTime;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public interface RealTimeUserSimilarityService {

    RTUSInsertResponse updateRedisFv(RTUSInsert request);

    RTUSReadResponse readVisitors(RTUSRead request);
}

@Slf4j
@Service
class IRealTimeUserSimilarityService extends SolrBaseRepository implements RealTimeUserSimilarityService {

    @Autowired
    private SqyUnitIdMappingRepository sqyUnitIdMappingRepository;

    @Autowired
    private TextBasedItemSimilarityFVRepository textBasedItemSimilarityFVRepository;

    @Autowired
    private UserFeatureVectorFvRepository userFeatureVectorFvRepository;

    @Autowired
    private VisitorCategoryFVCassandraRepository visitorCategoryFVCassandraRepository;

    @Autowired
    private VisitorDataViewRepository visitorDataViewRepository;

    @Autowired
    private SyFilterDetailsService syFilterDetailsService;

    @Autowired
    private EventTrackingService eventTrackingService;

    @Autowired
    private Environment environment;

    @Value("${redis.request.timeout:4000}")
    private int SOLR_REDIS_REQUEST_TIMEOUT;

    @Value("${ml.visitor.similarity.url}")
    private String VISITOR_SIMILARITY_URL;

    @Value("${ml.similar.product.count:100}")
    private int SIMILAR_VISITOR_COUNT;

    @Value("${visitor.data.limit:100}")
    private int VISITOR_DATA_LIMIT;

    @Value("${visitor.click.ignore.days:5}")
    private int VISITOR_CLICK_IGNORE_DAYS;

    @Value("${ml.visitor.similarity.limit:10}")
    private int VISITOR_SIMIALRITY_RESPONSE_LIMIT;

    @Value("${ml.visitor.similarity.bq:}")
    private String VISITOR_SIMIALRITY_BQ;

    @Value("${ml.visitor.similarity.solr.fields:group_id}")
    private String VISITOR_SIMILARITY_FL;

    private static Map<String, String> NEW_PROJECT_FILTER_MAPPING = new HashMap<>();
    private static Map<Integer, String> CATEGORY_MAPPING = new HashMap<>();
    private static final Map<String, String> RENT_FILTER_MAPPING = new HashMap<>();

    static {
        CATEGORY_MAPPING.put(1, "New Projects");
        CATEGORY_MAPPING.put(2, "Resale");
        CATEGORY_MAPPING.put(3, "Rental");
    }

    static {
        NEW_PROJECT_FILTER_MAPPING.put("city", "attribute_city");
        NEW_PROJECT_FILTER_MAPPING.put("location", "attribute_location");
        NEW_PROJECT_FILTER_MAPPING.put("bedroom", "attribute_flattype");
        NEW_PROJECT_FILTER_MAPPING.put("property_type", "stem_attribute_categorytype");
        NEW_PROJECT_FILTER_MAPPING.put("unit_type", "attribute_category");
        NEW_PROJECT_FILTER_MAPPING.put("budget", "price");
        NEW_PROJECT_FILTER_MAPPING.put("builder", "brand_name");
        NEW_PROJECT_FILTER_MAPPING.put("roads", "attribute_roads");
        NEW_PROJECT_FILTER_MAPPING.put("project_status", "attribute_status");
    }

    static {
        RENT_FILTER_MAPPING.put("city", "attribute_cityname");
        RENT_FILTER_MAPPING.put("location", "attribute_sublocalityname");
        RENT_FILTER_MAPPING.put("bedroom", "attribute_unittype");
        RENT_FILTER_MAPPING.put("property_type", "attribute_propertytype");
        RENT_FILTER_MAPPING.put("furnishing_status", "attribute_furnishing_status");
        RENT_FILTER_MAPPING.put("budget", "price");
        RENT_FILTER_MAPPING.put("project", "attribute_projectname");
        RENT_FILTER_MAPPING.put("posted_by", "attribute_usertype");
    }

    @Override
    public RTUSInsertResponse updateRedisFv(RTUSInsert request) {

        String visitorId = request.getVisitorId();
        String sqyProjectId = request.getProjectId();
        Integer taxonomyId = Integer.parseInt(request.getCategoryId());

        String productType = (taxonomyId == 1) ? "Flats" : "Others";

        String groupId = sqyUnitIdMappingRepository.findBySqyProjectId(sqyProjectId, taxonomyId);

        if (groupId == null) {
            return new RTUSInsertResponse("id not present");
        }

        try {

            TextBasedItemSimilarityFVKey textBasedItemSimilarityFVKey = new TextBasedItemSimilarityFVKey();
            textBasedItemSimilarityFVKey.setGroupId(groupId);
            textBasedItemSimilarityFVKey.setProductType(productType);
            textBasedItemSimilarityFVKey.setTaxonomyId(taxonomyId);
            Optional<TextBasedItemSimilarityFV> read = textBasedItemSimilarityFVRepository.findById(textBasedItemSimilarityFVKey);

            if (read.isEmpty()) {
                return new RTUSInsertResponse("id not present");
            }
            if (read.get().getVector() != null && !read.get().getVector().isEmpty()) {
                List<Double> featureVector = new ArrayList<>(read.get().getVector());
                runThreadToUpdateUserFeatureVector(visitorId, featureVector, taxonomyId);
            }
        } catch (Exception e) {
            log.error("error ->", e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error ", e);
        }
        return new RTUSInsertResponse("success");
    }

    private void runThreadToUpdateUserFeatureVector(String visitorId, List<Double> featureVector, Integer taxonomyId) {

        ExecutorService service = Executors.newFixedThreadPool(1);
        try {
            service.execute(() -> updateUserFeatureVectorWithTextBased(visitorId, featureVector, taxonomyId));
        } catch (Exception e) {
            log.error("error ->", e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error ", e);
        } finally {
            service.shutdown();
        }

    }

    private void updateUserFeatureVectorWithTextBased(String visitorId, List<Double> featureVector, Integer taxonomyId) {

        List<Double> visitorFeatureVector = new ArrayList<>();

        Optional<UserFeatureVectorFv> userFeatureVector = userFeatureVectorFvRepository.findById(visitorId + "_" + taxonomyId);
        if (userFeatureVector.isPresent()) {
            visitorFeatureVector.addAll(userFeatureVector.get().getUserFeatureVector());
        } else {
            VisitorCategoryFVCassandra visitorCategoryFv = visitorCategoryFVCassandraRepository.getByVisitorId(taxonomyId.toString(), visitorId + "_" + taxonomyId.toString());
            if (visitorCategoryFv != null) {
                visitorFeatureVector.addAll(visitorCategoryFv.getUserTasteFv());
            }
        }

        if (!visitorFeatureVector.isEmpty()) {

            for (int index = 0; index < visitorFeatureVector.size(); index++) {

                Double value = (visitorFeatureVector.get(index) + featureVector.get(index)) / 2;

                visitorFeatureVector.remove(index);
                visitorFeatureVector.add(index, value);
            }
            UserFeatureVectorFv feature = new UserFeatureVectorFv();
            feature.setVisitorId(visitorId + "_" + taxonomyId);
            feature.setUserFeatureVector(visitorFeatureVector);
            userFeatureVectorFvRepository.save(feature);

        } else {
            UserFeatureVectorFv feature = new UserFeatureVectorFv();
            feature.setVisitorId(visitorId + "_" + taxonomyId);
            feature.setUserFeatureVector(featureVector);
            userFeatureVectorFvRepository.save(feature);
        }
    }

    @Override
    public RTUSReadResponse readVisitors(RTUSRead request) {
        List<String> similarIds = new ArrayList<>();
        String type = "";

        String visitorId = request.getVisitorId();
        Integer categoryId = request.getCategoryId();
        JSONObject filterObj = new JSONObject(request.getFilters());
        JSONArray visitedId = new JSONArray(request.getVisitedProperty());

        if (filterObj == null) {
            filterObj = new JSONObject();
        }

        List<Double> userFeatureVector = new ArrayList<>();
        try {
            List<Double> userFv = getVisitorIdDataFromRedis(visitorId, categoryId);
            if (userFv != null && !userFv.isEmpty()) {
                log.info("FV from redis");
                userFeatureVector.addAll(userFv);
            }

            if (userFeatureVector.isEmpty()) {
                VisitorCategoryFVCassandra userFVCassandra = visitorCategoryFVCassandraRepository.getByVisitorId(categoryId.toString(), visitorId + '_' + categoryId.toString());
                if (userFVCassandra != null && userFVCassandra.getUserTasteFv() != null) {
                    log.info("FV from db");
                    userFeatureVector.addAll(userFVCassandra.getUserTasteFv());
                }
                createThreadToInsertFV(userFeatureVector, visitorId, categoryId);
            }

            if (!userFeatureVector.isEmpty()) {
                List<String> similarVisitorIds = getSimilarVisitorId(userFeatureVector, visitorId, categoryId);
                log.info(" similar visitor ids " + similarVisitorIds);

                List<String> visitorSimilarity = getVisitorSimilarity(similarVisitorIds, categoryId);
                log.info(" similar property ids " + visitorSimilarity);

                List<String> visitedProperties = getVisitedProperties(visitorId, categoryId);
                if (!visitedProperties.isEmpty()) {
                    visitorSimilarity.removeAll(visitedProperties);
                }

                if (visitedId != null && visitedId.length() > 0 && !visitorSimilarity.isEmpty()) {
                    log.info("visited Id -> " + visitedId);
                    visitorSimilarity.removeAll(visitedId.toList());
                }

                if (visitorSimilarity != null && !visitorSimilarity.isEmpty()) {
                    type = "RECOMMENDED";
                    similarIds.addAll(getSolrResponse(categoryId, Lists.partition(visitorSimilarity, 1000).get(0), filterObj));
                    log.info(" filtered property ids " + similarIds);
                }
            }
        } catch (Exception e) {
            log.error(" error ", e);
        }
        if (similarIds.isEmpty()) {
            type = "TRENDING_LOCATION";
            List<String> trendingLocationList = new ArrayList<>();
            getTrendingPropertyByLocation(trendingLocationList, filterObj, categoryId);
            getTrendingIds(similarIds, categoryId, filterObj, trendingLocationList);
        }
        if (similarIds.isEmpty()) {
            type = "TRENDING_CITY";
            List<String> trendingCityList = new ArrayList<>();
            getTrendingProperty(trendingCityList, filterObj, categoryId);
            getTrendingIds(similarIds, categoryId, filterObj, trendingCityList);
        }

        if (visitedId != null && visitedId.length() > 0 && !similarIds.isEmpty()) {
            log.info("visited Id -> " + visitedId);
            similarIds.removeAll(visitedId.toList());
        }

        if (categoryId == 1) {
            return new RTUSReadResponse(similarIds, null, similarIds.isEmpty() ? "" : type);
        } else {
            return new RTUSReadResponse(null, similarIds, similarIds.isEmpty() ? "" : type);
        }
    }

    private void getTrendingIds(List<String> similarIds, Integer categoryId, JSONObject filterObj, List<String> trendingLocationList) {
        if (!trendingLocationList.isEmpty()) {
            List<String> groupIdList = trendingLocationList.stream().map(e -> e + "_" + categoryId + "_group").collect(Collectors.toList());
            similarIds.addAll(getSolrResponse(categoryId, Lists.partition(groupIdList, 1000).get(0), filterObj));
        }
    }

    private List<Double> getVisitorIdDataFromRedis(String visitorId, int categoryId) {

        ExecutorService executorService = Executors.newFixedThreadPool(1, new ThreadFactoryBuilder().setNameFormat(this.getClass().getName() + "-%d").build());
        try {
            Future<Optional<UserFeatureVectorFv>> featureResponse = executorService.submit(() -> userFeatureVectorFvRepository.findById(visitorId + "_" + categoryId));
            Optional<UserFeatureVectorFv> userFeatureVectorVo = featureResponse.get(SOLR_REDIS_REQUEST_TIMEOUT, TimeUnit.MILLISECONDS);

            if (userFeatureVectorVo.isPresent() && userFeatureVectorVo.get().getUserFeatureVector() != null && !userFeatureVectorVo.get().getUserFeatureVector().isEmpty()) {
                return userFeatureVectorVo.get().getUserFeatureVector();
            }
        } catch (Exception e) {
            log.error("failed to fetch data from redis " + visitorId + "_" + categoryId, e);
        } finally {
            executorService.shutdown();
        }

        return new ArrayList<>();
    }

    private void createThreadToInsertFV(List<Double> userFVList, String visitorId, int categoryId) {

        if (!userFVList.isEmpty()) {

            ExecutorService executorService = Executors.newFixedThreadPool(1, new ThreadFactoryBuilder().setNameFormat(this.getClass().getName() + "-%d").build());
            try {
                executorService.execute(() -> insertVisitorIdDataTORedis(userFVList, visitorId, categoryId));
            } catch (Exception e) {
                log.error("failed to insert data " + visitorId + "_" + categoryId, e);
            } finally {
                executorService.shutdown();
            }
        }
    }

    private void insertVisitorIdDataTORedis(List<Double> userFVList, String visitorId, int categoryId) {

        UserFeatureVectorFv userFeatureVectorFv = new UserFeatureVectorFv();
        userFeatureVectorFv.setVisitorId(visitorId + "_" + categoryId);
        userFeatureVectorFv.setUserFeatureVector(userFVList);
        userFeatureVectorFvRepository.save(userFeatureVectorFv);
    }

    private List<String> getSimilarVisitorId(List<Double> userFVList, String visitorId, int categoryId) {

        try {

            URL url = new URL(VISITOR_SIMILARITY_URL);

            JSONObject requestParams = new JSONObject();
            requestParams.put("FeatureVector", userFVList);
            requestParams.put("K", SIMILAR_VISITOR_COUNT);
            requestParams.put("UID", visitorId + "_" + categoryId);
            requestParams.put("CategoryId", Integer.toString(categoryId));

            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty(Constants.CONTENT_TYPE, "application/json");
            con.setDoOutput(true);
            con.getOutputStream().write(requestParams.toString().getBytes("UTF8"));
            con.getResponseCode();
            con.setReadTimeout(SOLR_REDIS_REQUEST_TIMEOUT);
            log.info("\nSending 'POST' request to URL : " + url + " with data : " + requestParams.toString() + " response code " + con.getResponseCode());

            try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));) {
                String inputLine;
                StringBuilder response = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                log.info(response.toString());
                con.disconnect();
                JSONObject responseJson = new JSONObject(response.toString());
                if (responseJson.optJSONArray("similar_user_ids") != null) {
                    return responseJson.getJSONArray("similar_user_ids").toList().stream().filter(e -> e.toString().contains("_" + categoryId))
                            .map(e -> e.toString().replace("_" + categoryId, "")).collect(Collectors.toList());
                }
            }
        } catch (Exception e) {
            log.error("Error -->", e);
        }
        return new ArrayList<>();
    }

    public List<String> getVisitorSimilarity(List<String> visitorId, Integer taxonomyId) {

        if (visitorId != null && !visitorId.isEmpty()) {

            List<String> visitorIds = visitorId.stream().map(e -> e.toString() + '_' + taxonomyId.toString()).collect(Collectors.toList());
            List<VisitorCategoryFVCassandra> visitorCategoryFVList = visitorCategoryFVCassandraRepository.getByAllVisitorIds(taxonomyId.toString(), new HashSet<>(visitorIds), VISITOR_DATA_LIMIT);

            if (visitorCategoryFVList != null && !visitorCategoryFVList.isEmpty()) {

                Map<String, Integer> groupIdsCount = visitorCategoryFVList.stream().map(VisitorCategoryFVCassandra::getGroupIdClick).flatMap(List::stream)
                        .collect(Collectors.toMap(vo -> vo, vo -> 1, Integer::sum));

                return groupIdsCount.entrySet().stream().sorted((ent1, ent2) -> ent2.getValue() - ent1.getValue()).map(Map.Entry::getKey).collect(Collectors.toList());
            }
        }
        return new ArrayList<>();
    }

    private List<String> getVisitedProperties(String visitorId, int categoryId) {

        List<String> visitedProperties = new ArrayList<>();
        try {
            List<Integer> eventDate = getEventDate();
            if (!eventDate.isEmpty()) {
                List<VisitorDataView> visitedData = visitorDataViewRepository.findByVisitorIdAndEventDates(visitorId, getEventDate(), categoryId,
                        categoryId == 1 ? "Flats" : "Others", VISITOR_DATA_LIMIT);
                if (visitedData != null) {
                    visitedProperties.addAll(visitedData.stream().map(VisitorDataView::getGroupIdList).flatMap(Set::stream).collect(Collectors.toList()));
                }
            }
            log.info("visited property for visitorId " + visitorId + " -> " + visitedProperties);
        } catch (Exception e) {
            log.error("Error -> ", e);
        }
        return visitedProperties;
    }

    private List<Integer> getEventDate() {

        List<Integer> eventDates = new ArrayList<>();
        try {
            DateFormat df = new SimpleDateFormat("yyyyMMdd");
            int endDate = Integer.parseInt(df.format(new Date()));
            eventDates.add(endDate);
            for (int i = VISITOR_CLICK_IGNORE_DAYS - 1; i > 0; i--) {
                eventDates.add(Integer.parseInt(df.format(new DateTime(new Date()).minusDays(i).toDate())));
            }
        } catch (Exception e) {
            log.error("Error -> ", e);
        }
        return eventDates;
    }

    private List<String> getSolrResponse(int taxonomyId, List<String> similarGroupList, JSONObject filterObj) {

        SolrQuery query = createSolrQueryVisitorSimilarity(taxonomyId, similarGroupList, filterObj);
        QueryResponse queryResponse = search(Constants.SOLR_ONLINE_COLLECTION, query);
        if (queryResponse != null) {
            List<String> filteredGroupIds = queryResponse.getResults().stream()
                    .map(doc -> doc.getFieldValue(Constants.SOLR_GROUP_ID).toString().split("_")[taxonomyId == 4 ? 1 : 0]).distinct().limit(VISITOR_SIMIALRITY_RESPONSE_LIMIT)
                    .collect(Collectors.toList());

            return filteredGroupIds;
        }
        return new ArrayList<>();
    }

    private SolrQuery createSolrQueryVisitorSimilarity(int taxonomyId, List<String> similarGroupList, JSONObject filterObj) {

        String childFilter = "";
        SolrQuery similarDocsQuery = new SolrQuery("*:*");
        similarDocsQuery.set("defType", "edismax");
        similarDocsQuery.addFilterQuery("taxonomy_id: " + taxonomyId);
        similarDocsQuery.addFilterQuery("{!parent which=\"doc_type:parent\"}");
        similarDocsQuery.addField(Constants.SOLR_GROUP_ID);
        addFilters(filterObj, similarDocsQuery, taxonomyId);
        if (taxonomyId != 1) {
            similarDocsQuery.addFilterQuery("attribute_dt_range_expireddate:[NOW TO  *]");
        }
        if (filterObj.has("budget")) {
            childFilter = createPriceRangeQuery(similarDocsQuery, filterObj.optJSONArray("budget"));
        }
        if (filterObj.has("size") && taxonomyId != 1) {
            createAreaSizeQuery(similarDocsQuery, filterObj.optJSONArray("size"));
        }

        StringBuilder query = new StringBuilder("group_id:(");
        if (similarGroupList != null && !similarGroupList.isEmpty()) {
            List<String> partition = Lists.partition(similarGroupList, VISITOR_SIMIALRITY_RESPONSE_LIMIT * 4).get(0);
            similarDocsQuery.addFilterQuery("group_id:(" + String.join(" OR ", partition) + ")");
            int boostMax = partition.size() * 500;
            for (String gid : partition) {
                query.append("\"" + gid + "\"" + "^=" + boostMax + " ");
                boostMax -= 100;
            }
            query.append(")");
            similarDocsQuery.set("bq", VISITOR_SIMIALRITY_BQ + " " + query);
        }

        similarDocsQuery.setRows(VISITOR_SIMIALRITY_RESPONSE_LIMIT);
        similarDocsQuery.setFields(VISITOR_SIMILARITY_FL + ",[child parentFilter=doc_type:parent " + childFilter + "]");
        log.info("filters " + similarDocsQuery);
        return similarDocsQuery;
    }

    private void addFilters(JSONObject filterObj, SolrQuery similarDocsQuery, int categoryId) {

        if (filterObj != null) {
            filterObj.keySet().forEach(e -> {
                JSONArray filterArray = filterObj.getJSONArray(e);
                String filterName = categoryId == 1 ? NEW_PROJECT_FILTER_MAPPING.getOrDefault(e, e) : RENT_FILTER_MAPPING.getOrDefault(e, e);
                if (filterArray != null && filterArray.length() > 0) {
                    if ("attribute_location".equalsIgnoreCase(filterName)) {
                        List<String> filterList = filterArray.toList().stream().map(Object::toString).collect(Collectors.toList());
                        similarDocsQuery.addFilterQuery(String.format("%s:(\"%s\") OR %s:(\"%s\")", filterName, String.join("\" OR \"", filterList), "attribute_sublocation",
                                String.join("\" OR \"", filterList)));
                    } else if (!"price".equalsIgnoreCase(filterName) && !"size".equalsIgnoreCase(filterName)) {
                        List<String> filterList = filterArray.toList().stream().map(Object::toString).collect(Collectors.toList());
                        similarDocsQuery.addFilterQuery(String.format("%s:(\"%s\")", filterName, String.join("\" OR \"", filterList)));
                    }
                }
            });
        }
    }

    private void createAreaSizeQuery(SolrQuery similarDocsQuery, JSONArray sizeArray) {

        try {
            List<Double> sizeList = new ArrayList<Double>();

            if (sizeArray != null) {
                sizeArray.toList().stream().forEach(e -> sizeList.add(Double.parseDouble(e.toString())));
            }
            Collections.sort(sizeList);
            if (!sizeList.isEmpty()) {
                Double lowSize = sizeList.get(0);
                Double highSize = sizeList.get(sizeList.size() - 1);
                if (lowSize.compareTo(1d) > 0 && highSize.compareTo(1d) > 0) {

                    similarDocsQuery.addFilterQuery("attribute_range_atreainsqft:[" + lowSize + " TO " + highSize + "]");
                    log.info("size filter " + lowSize + " , " + highSize);

                }
            }
        } catch (Exception e) {
            log.error("Error -> ", e);
        }
    }

    private String createPriceRangeQuery(SolrQuery similarDocsQuery, JSONArray priceArray) {

        try {
            List<Double> priceList = new ArrayList<Double>();

            if (priceArray != null) {
                priceArray.toList().stream().forEach(e -> priceList.add(Double.parseDouble(e.toString())));
            }
            Collections.sort(priceList);
            if (!priceList.isEmpty()) {
                Double lowPrice = priceList.get(0);
                Double highPrice = priceList.get(priceList.size() - 1);
                if (lowPrice.compareTo(1d) > 0 && highPrice.compareTo(1d) > 0) {

                    similarDocsQuery.addFilterQuery("{!parent which=\"doc_type:parent\"}(retailer_price:[" + lowPrice + " TO " + highPrice + "])");
                    log.info("price filter " + lowPrice + " , " + highPrice);
                    return "childFilter=\"retailer_price:[" + lowPrice + " TO " + highPrice + "]\" ";

                }
            }
        } catch (Exception e) {
            log.error("Error -> ", e);
        }
        return "";
    }

    private void getTrendingPropertyByLocation(List<String> similarIds, JSONObject filters, int categoryId) {

        try {
            boolean isCityFilter = filters.has("city") && filters.optJSONArray("city") != null && filters.getJSONArray("city").length() > 0;
            boolean isLocationFilter = filters.has("location") && filters.optJSONArray("location") != null && filters.getJSONArray("location").length() > 0;
            if (isCityFilter && isLocationFilter) {
                String cityName = filters.getJSONArray("city").iterator().next().toString();
                String subLocation = filters.getJSONArray("location").iterator().next().toString();
                String categoryName = CATEGORY_MAPPING.getOrDefault(categoryId, "");

                SyFiltersDetails cityFilter = syFilterDetailsService.findByFilterName(cityName, categoryId, "CITY");
                SyFiltersDetails locationFilter = syFilterDetailsService.findByFilterName(subLocation, categoryId, categoryId == 1 ? "SUB_LOCATION" : "LOCATION");

                if (!Strings.isNullOrEmpty(categoryName) && cityFilter != null && locationFilter != null) {

                    List<Object[]> readTrendingProperties = eventTrackingService.readSubLocationTrendingProperties(cityFilter.getFilterId(),
                            Integer.parseInt(locationFilter.getFilterId()), categoryName);
                    if (readTrendingProperties != null) {
                        readTrendingProperties.forEach(e -> {
                            if (e[2] != null) {
                                similarIds.add(e[2].toString());
                            }
                        });
                    }
                }
            }
        } catch (Exception e) {
            log.error("Error -> ", e);
        }
    }

    private void getTrendingProperty(List<String> similarIds, JSONObject filters, int categoryId) {

        try {
            if (filters.has("city") && filters.optJSONArray("city") != null && filters.getJSONArray("city").length() > 0) {
                String cityName = filters.getJSONArray("city").iterator().next().toString();
                String categoryName = CATEGORY_MAPPING.getOrDefault(categoryId, "");
                SyFiltersDetails findByFilterName = syFilterDetailsService.findByFilterName(cityName, categoryId, "CITY");

                if (!Strings.isNullOrEmpty(categoryName) && findByFilterName != null && findByFilterName.getFilterId() != null) {
                    List<Object[]> readTrendingProperties = eventTrackingService.readTrendingProperties(findByFilterName.getFilterId(), categoryName);
                    if (readTrendingProperties != null) {
                        readTrendingProperties.forEach(e -> {
                            if (e[2] != null) {
                                similarIds.add(e[2].toString());
                            }
                        });
                    }
                }
            }
        } catch (Exception e) {
            log.error("Error -> ", e);
        }
    }

}